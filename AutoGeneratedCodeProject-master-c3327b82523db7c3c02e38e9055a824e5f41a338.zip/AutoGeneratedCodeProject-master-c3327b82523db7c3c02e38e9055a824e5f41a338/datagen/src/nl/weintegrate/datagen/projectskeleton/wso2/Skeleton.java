package nl.weintegrate.datagen.projectskeleton.wso2;

/*
*	Author: Imtiaz Hassan
*	Usage:  This class is responsible for creating project skeleton for WSO2
*
*	Known Issues: 
*
*	1. Code is not optimized
*	2. Instead of hard coding the file contents, a better approach (to be investigated further) seems to be the usage of default files and using search&replace strategy.
*	3. Re-usable functions can be made (This should only be done once above two points are catered, otherwise it may be a waste of effort 
*	4. Make specific functions for ESB, REG instead of passing isEsb variable as argument
*	5. Make a separate Constant class
*	6. This is a pre-draft version that was implemented only for POC purposes. This class cannot be used for distribution.
*	7. Proper handling of exceptional flows is required.
*
*	Version History: 
*	
*	01.001 (Work-in-progress Implementation)
*/

/* JAVA Packages  */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.Properties;
import java.util.StringTokenizer;

/* Apache Packages  */

import org.apache.commons.io.FileUtils;


/* Class Declarations start*/

public class Skeleton {

	// No need to define instance variables
	
	/**
	* Create.project file for the main project
	* @param aPath 	Base path of the project structure
	* @param aComponentName 	The name of the component/sub-component for which project is to be created 
	*/

	public void createDotProjectFileForMainProject(String aPath, String aComponentName) throws Exception {
		
		String myDotProjectFileContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
											+"<projectDescription>\n"  
												+"<name>"+aComponentName+"</name>\n" 
												+ "<comment></comment>\n"
												+ "<projects>\n"
												+ "</projects>\n"
												+ "<buildSpec>\n"
												+ "</buildSpec>\n"
												+ "<natures>\n"
												+ "</natures>\n"
											+ "</projectDescription>\n";
		
		//File dotProjectFile = new File(path+".project");
		FileWriter myFileWritter = new FileWriter(aPath+File.separator+".project",true);
        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
        myBufferWritter.write(myDotProjectFileContents);
        myBufferWritter.close();

	}

	/**
	* Create.project file for the sub project
	* @param aPath 	Base path of the project structure
	* @param aComponentName 	The name of the component/sub-component for which project is to be created 
	*/
	
	// KNOWN ISSUE : there is no need to define anIsESB argument
	public void createDotProjectFileForSubProject(String aPath, String aComponentName, boolean anIsEsb) throws Exception {
		
		String myDotProjectFileContents ="";
		
		if (anIsEsb) {
			
			myDotProjectFileContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
										+"<projectDescription>\n"  
											+"<name>"+aComponentName+"</name>\n" 
											+ "<comment></comment>\n"
											+ "<projects>\n"
											+ "</projects>\n"
											+ "<buildSpec>\n"
											+ "</buildSpec>\n"
											+ "<natures>\n"
											+ 		"\t<nature>org.wso2.developerstudio.eclipse.esb.project.nature</nature>\n"
											+ "</natures>\n"
										+ "</projectDescription>\n";
			
		} else {
			
			myDotProjectFileContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
					+"<projectDescription>\n"  
						+"<name>"+aComponentName+"</name>\n" 
						+ "<comment></comment>\n"
						+ "<projects>\n"
						+ "</projects>\n"
						+ "<buildSpec>\n"
						+		"\t<buildCommand>\n"
						+			"\t<name>org.eclipse.jdt.core.javabuilder</name>\n"
						+			"\t<arguments>\n"
						+			"\t</arguments>\n"
						+		"\t</buildCommand>\n"
						+ "</buildSpec>\n"
						+ "<natures>\n"
						+ 		"\t<nature>org.wso2.developerstudio.eclipse.general.project.nature</nature>\n"
						+ 		"\t<nature>org.eclipse.jdt.core.javanature</nature>\n"
						+ "</natures>\n"
					+ "</projectDescription>\n";
			
		}
		
		//File dotProjectFile = new File(path+".project");
		FileWriter myFileWritter = new FileWriter(aPath+File.separator+".project",true);
        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
        myBufferWritter.write(myDotProjectFileContents);
        myBufferWritter.close();

	}

	/**
	* Create.project file for Composite archive project
	* @param aPath 	Base path of the project structure
	* @param aComponentName 	The name of the component/sub-component for which project is to be created 
	*/
	
	// To do: change name to createCADotProjectFile
	public void createdotProjectFileForCA(String aPath, String aComponentName) throws Exception {
		
		String myDotProjectFileContents ="";
		myDotProjectFileContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
		+"<projectDescription>\n"  
			+"<name>"+aComponentName+"</name>\n" 
			+ "<comment></comment>\n"
			+ "<projects>\n"
			+ "</projects>\n"
			+ "<buildSpec>\n"
			+ "</buildSpec>\n"
			+ "<natures>\n"
			+ 		"\t<nature>org.wso2.developerstudio.eclipse.distribution.project.nature</nature>\n"
			+ "</natures>\n"
		+ "</projectDescription>\n";
		//File dotProjectFile = new File(path+".project");
		FileWriter myFileWritter = new FileWriter(aPath+File.separator+".project",true);
        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
        myBufferWritter.write(myDotProjectFileContents);
        myBufferWritter.close();

	}

	/**
	* Create.class path file for sub project
	* @param aPath 	Base path of the project structure
	*/
	public void createDotClassPathFileForSubProject(String aPath) throws Exception {
		
		String myDotClassPathFileContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
											+ "\t<classpath>\n"
											+ "\t\t<classpathentry kind=\"con\" path=\"org.eclipse.jdt.launching.JRE_CONTAINER\"/>\n"
											+ "\t\t<classpathentry kind=\"output\" path=\"target\"/>\n"
											+ "\t</classpath>\n";
		
		//File dotProjectFile = new File(path+".project");
		FileWriter myFileWritter = new FileWriter(aPath+File.separator+".classpath",true);
        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
        myBufferWritter.write(myDotClassPathFileContents);
        myBufferWritter.close();

	}
	
	/**
	* Create pom file file
	* @param aPath 	Base path of the project structure
	* @param anArtifactId 	Base path of the project structure
	* @param aGroupId 	Base path of the project structure
	* @param aPomFileName 	Base path of the project structure
	*/

	public void createPomFile(String aPath, String anArtifactId, String aGroupId, String aPomFileName, String aNexusURL) throws Exception {
		
	     String myContent = FileUtils.readFileToString(new File(aPomFileName), "UTF-8");
	     myContent = myContent.replaceAll("REPLACE_GROUP_ID",aGroupId);
	     myContent = myContent.replaceAll("REPLACE_ARTIFACT_ID",anArtifactId);
	     myContent = myContent.replaceAll("NEXUS_URL",aNexusURL);
	     File myTempFile = new File(aPath+File.separator+"pom.xml");
	     FileUtils.writeStringToFile(myTempFile, myContent, "UTF-8");
	}
	public void createSecurityFolder(String aPath) throws Exception {
		
		String mySecurityFolderPath = aPath+File.separator+"security";
		File myDirectory = new File(mySecurityFolderPath);
		myDirectory.mkdirs();
		
		String myContent = FileUtils.readFileToString(new File("client-truststore.jks"), "UTF-8");
	     File myTempFile = new File(aPath+File.separator+"security"+File.separator+"client-truststore.jks");
	     FileUtils.writeStringToFile(myTempFile, myContent, "UTF-8");
	     
	     String myContent2 = FileUtils.readFileToString(new File("wso2carbon.jks"), "UTF-8");
	     File myTempFile2 = new File(aPath+File.separator+"security"+File.separator+"wso2carbon.jks");
	     FileUtils.writeStringToFile(myTempFile2, myContent2, "UTF-8");
	}
	/**
	* Create api file (only required for ESB config project)
	* @param aPath 	Base path of ESB sub-project, api folder 
	* @param aComponentName 	The name of the component/sub-component for which project is to be created 
	*/
	public void createAPI(Properties aPropertiesConfig,String aPath, String aComponentName, String apiResources) throws Exception {
		
		StringTokenizer myTokenizer = new StringTokenizer(apiResources, ",");
		
		String myAPIContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+"<api xmlns=\"http://ws.apache.org/ns/synapse\" name=\""+aComponentName+"API_01\" context=\"/"+aComponentName+"API\">\n";  
		
		while(myTokenizer.hasMoreElements()) {
			
			String token = myTokenizer.nextToken();
			
			switch (token){
				case "Get":
					myAPIContents = myAPIContents+"\t<resource methods=\"GET\" uri-template=\"/"+aPropertiesConfig.getProperty(token+"PerCode.resource")+"/{"+aComponentName+"Code}\" faultSequence=\""+aComponentName+"API_01_"+token+aComponentName+"PerCodeFaultSequence_01\">\n"
					+"	\t\t<inSequence>\n"
					+"	    \t\t\t<sequence key=\""+aComponentName+"API_01_"+token+aComponentName+"PerCodeInSequence_01\"/>\n"
					+"	\t\t</inSequence>\n"
					+"	\t\t\t<outSequence>\n"
					+"	    \t\t<sequence key=\""+aComponentName+"API_01_"+token+aComponentName+"PerCodeOutSequence_01\"/>\n"
					+"	\t\t\t</outSequence>\n"
					+"\t</resource>\n";
					myAPIContents = myAPIContents+"\t<resource methods=\"GET\" url-mapping=\"/"+aPropertiesConfig.getProperty(token+".resource")+"\" faultSequence=\""+aComponentName+"API_01_"+token+aComponentName+"FaultSequence_01\">\n"; 
					break;
				case "Create":
					myAPIContents = myAPIContents+"\t<resource methods=\"POST\" url-mapping=\"/"+aPropertiesConfig.getProperty(token+".resource")+"\" faultSequence=\""+aComponentName+"API_01_"+token+aComponentName+"FaultSequence_01\">\n"; 
					break;
				case "Update":
					myAPIContents = myAPIContents+"\t<resource methods=\"PUT\" url-mapping=\"/"+aPropertiesConfig.getProperty(token+".resource")+"\" faultSequence=\""+aComponentName+"API_01_"+token+aComponentName+"FaultSequence_01\">\n"; 
					break;
				case "Delete":
					myAPIContents = myAPIContents+"\t<resource methods=\"DELETE\" uri-template=\"/"+aPropertiesConfig.getProperty(token+".resource")+"/{"+aComponentName+"Code}\" faultSequence=\""+aComponentName+"API_01_"+token+aComponentName+"FaultSequence_01\">\n"; 
					break;
				default:
					myAPIContents = myAPIContents+"\t<resource methods=\"GET POST\" url-mapping=\"/"+aPropertiesConfig.getProperty(token+".resource")+"\" faultSequence=\""+aComponentName+"API_01_"+token+aComponentName+"FaultSequence_01\">\n"; 
			}
			
			myAPIContents = myAPIContents
					+"  \t\t<inSequence>\n"
					+"		\t\t\t<sequence key=\""+aComponentName+"API_01_"+token+aComponentName+"InSequence_01\"/>\n"
					+"	\t\t</inSequence>\n"
					+"	\t\t<outSequence>\n"
					+"	    \t\t\t<sequence key=\""+aComponentName+"API_01_"+token+aComponentName+"OutSequence_01\"/>\n"
					+"	\t\t</outSequence>\n"
					+"\t</resource>\n";
		}
		
		myAPIContents = myAPIContents+"</api>\n";
		
	FileWriter myFileWritter = new FileWriter(aPath+File.separator+aComponentName+"API_01.xml",true);
        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
        myBufferWritter.write(myAPIContents);
        myBufferWritter.close();

	}
	
	/* Create fault sequence (only required for ESB config project)
	* @param aPath 	Base path of ESB sub-project, sequences folder
	* @param aComponentName 	The name of the component/sub-component for which project is to be created 
	*/
	public void createAPIFaultSequence(String aPath, String Operation, String aComponentName, String aPostName) throws Exception {
		
		String myFaultSequenceContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
			+"<sequence xmlns=\"http://ws.apache.org/ns/synapse\" name=\""+aComponentName+"API_01_"+Operation+aComponentName+aPostName+"FaultSequence_01\">\n"  
				+"\t<call-template target=\"gov:com/commons/util/v1/templates/LoggerTemplate.xml\" description=\"Log-INFO\">\n"
					+"\t\t<with-param name=\"SequenceName\" value=\""+aComponentName+"API_01_"+aComponentName+"API_01_Convert"+Operation+aComponentName+aPostName+"FaultSequence_01\"/>\n"
					+"\t\t<with-param name=\"Message\" value=\"Error occurred in "+Operation+aComponentName+aPostName+".\"/>\n"
					+"\t\t<with-param name=\"LogLevel\" value=\"INFO\"/>\n"
				+"\t</call-template>\n"
				+"\t<switch source=\"get-property('ERROR_MESSAGE')\">\n"	
				+"\t\t<case regex=\"Unable to perform XSLT transformation using.*\">\n"
				+"\t\t\t<property name=\"UserMessage\" value=\"An internal error has occurred while transforming the message.\" scope=\"default\" type=\"STRING\" description=\"UserMessage\"/>\n"
				+"\t\t</case>\n"
				+"\t\t<case regex=\"Unexpected error during sending message out.*\">\n"
				+"\t\t\t<property name=\"UserMessage\" value=\"Service is unavailable at this time. Please try again later.\" scope=\"default\" type=\"STRING\" description=\"UserMessage\"/>\n"
				+"\t\t</case>\n"
				+"\t\t<case regex=\"Error connecting to the back end.*\">\n"
				+"\t\t\t<property name=\"UserMessage\" value=\"Service is unavailable at this time. Please try again later.\" scope=\"default\" type=\"STRING\" description=\"UserMessage\"/>\n"
				+"\t\t</case>\n"
				+"\t\t<default>\n"
				+"\t\t\t<property name=\"UserMessage\" value=\"An unexpected error has occurred.\" scope=\"default\" type=\"STRING\" description=\"UserMessage\"/>\n"
				+"\t\t</default>\n"
				+"\t</switch>\n"
				+"\t<clone xmlns=\"http://ws.apache.org/ns/synapse\">\n"
				+"\t\t<target>\n"
				+"\t\t\t<sequence>\n"
				+"\t\t\t\t<payloadFactory media-type=\"xml\">\n"
				+"\t\t\t\t\t<format>\n"
				+"\t\t\t\t\t\t<ns8:"+Operation+aComponentName+aPostName+"Response xmlns:ns8=\"TODO:\" xmlns:ns4=\"http://www.ciber.nl/uiab/cdm/xsd/actionstatus_01\" xmlns=\"\">\n"
				+"\t\t\t\t\t\t\t<ns8:ActionStatus>\n"
				+"\t\t\t\t\t\t\t\t<ns4:Status>FAIL</ns4:Status>\n"
				+"\t\t\t\t\t\t\t\t<ns4:ErrorCode>$1</ns4:ErrorCode>\n"
				+"\t\t\t\t\t\t\t\t<ns4:Message>$2</ns4:Message>\n"
				+"\t\t\t\t\t\t\t</ns8:ActionStatus>\n"
				+"\t\t\t\t\t\t</ns8:"+Operation+aComponentName+aPostName+"Response>\n"
				+"\t\t\t\t\t</format>\n"
				+"\t\t\t\t\t<args>\n"
				+"\t\t\t\t\t\t<arg xmlns:ns=\"http://org.apache.synapse/xsd\" evaluator=\"xml\" expression=\"get-property('ERROR_CODE')\"/>\n"
				+"\t\t\t\t\t\t<arg xmlns:ns=\"http://org.apache.synapse/xsd\" evaluator=\"xml\" expression=\"get-property('UserMessage')\"/>\n"
				+"\t\t\t\t\t</args>\n"
				+"\t\t\t\t</payloadFactory>\n"
				+"\t\t\t\t<switch xmlns:ns=\"http://org.apache.synapse/xsd\" source=\"get-property('ResponseType')\">\n"
				+"\t\t\t\t\t<case regex=\"application/xml\">\n"
				+"\t\t\t\t\t\t<header name=\"Accept\" scope=\"transport\" value=\"application/xml\"/>\n"
				+"\t\t\t\t\t\t<property name=\"ContentType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"ContentType\"/>\n"
				+"\t\t\t\t\t\t<property name=\"messageType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"messageType\"/>\n"
				+"\t\t\t\t\t</case>\n"
		        +"\t\t\t\t\t<case regex=\"application/json\">\n"
		        +"\t\t\t\t\t\t<header name=\"Accept\" scope=\"transport\" value=\"application/json\"/>\n"
		        +"\t\t\t\t\t\t<property name=\"ContentType\" value=\"application/json\" scope=\"axis2\" type=\"STRING\" description=\"ContentType\"/>\n"
		        +"\t\t\t\t\t\t<property name=\"messageType\" value=\"application/json\" scope=\"axis2\" type=\"STRING\" description=\"messageType\"/>\n"
		        +"\t\t\t\t\t</case>\n"
		        +"\t\t\t\t\t<default>\n"
		        +"\t\t\t\t\t\t<header name=\"Accept\" scope=\"transport\" value=\"application/xml\"/>\n"
				+"\t\t\t\t\t\t<property name=\"ContentType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"ContentType\"/>\n"
				+"\t\t\t\t\t\t<property name=\"messageType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"messageType\"/>\n"
				+"\t\t\t\t\t</default>\n"
		        +"\t\t\t\t</switch>\n"
				+"\t\t\t\t<property name=\"NO_ENTITY_BODY\" scope=\"axis2\" action=\"remove\"/>\n"
				+"\t\t\t\t<property name=\"HTTP_SC\" value=\"500\" scope=\"axis2\"/>\n"
				+"\t\t\t\t<respond/>\n"
				+"\t\t\t</sequence>\n"
				+"\t\t</target>\n"
				+"\t\t<target>\n"
				+"\t\t\t<sequence>\n"
				+"\t\t\t\t<payloadFactory media-type=\"xml\" description=\"ErrorMessage\">\n"
				+"\t\t\t\t\t<format>\n"
		        +"\t\t\t\t\t\t<err:Error xmlns:err=\"http://ws.apache.org/ns/synapse\">\n"
		        +"\t\t\t\t\t\t\t<Header>\n"
		        +"\t\t\t\t\t\t\t\t<CMMHeader>\n"
		        +"\t\t\t\t\t\t\t\t\t<MessageTimeStamp>$5</MessageTimeStamp>\n"
		        +"\t\t\t\t\t\t\t\t\t<MessageId>$6</MessageId>\n"
		        +"\t\t\t\t\t\t\t\t\t<ComponentId>"+aComponentName+"API</ComponentId>\n"
		        +"\t\t\t\t\t\t\t\t\t<From>$1</From>\n"
		        +"\t\t\t\t\t\t\t\t\t<To>$2</To>\n"
		        +"\t\t\t\t\t\t\t\t\t<Operation>"+Operation+aComponentName+aPostName+"</Operation>\n"
		        +"\t\t\t\t\t\t\t\t\t<Domain>UiaB</Domain>\n"
		        +"\t\t\t\t\t\t\t\t</CMMHeader>\n"
		        +"\t\t\t\t\t\t\t</Header>\n"
		        +"\t\t\t\t\t\t\t<ErrorCode>$7</ErrorCode>\n"
		        +"\t\t\t\t\t\t\t<ErrorMessage>$3</ErrorMessage>\n"
		        +"\t\t\t\t\t\t\t<ErrorDetail>$6</ErrorDetail>\n"
		        +"\t\t\t\t\t\t\t<ErrorException>$4</ErrorException>\n"
		        +"\t\t\t\t\t\t</err:Error>\n"
		        +"\t\t\t\t\t</format>\n"
		        +"\t\t\t\t\t<args>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('MessageFrom')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('MessageDestination')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('ERROR_MESSAGE')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('ERROR_EXCEPTION')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('MessageTime')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('ERROR_DETAIL')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('ERROR_CODE')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('MessageId')\"/>\n"
		        +"\t\t\t\t\t</args>\n"
		        +"\t\t\t\t</payloadFactory>\n"
		        +"\t\t\t\t<log level=\"full\" category=\"ERROR\" separator=\"---=== Fault Sequence "+Operation+aComponentName+aPostName+" ===---\"/>\n"
				+"\t\t\t\t<property name=\"OUT_ONLY\" scope=\"default\" type=\"STRING\" value=\"true\"/>\n"
		        +"\t\t\t\t<call>\n"
				+"\t\t\t\t\t<endpoint key=\"gov:nl/ciber/uiab/"+aComponentName.toLowerCase()+"/service/v1/endpoint/"+aComponentName+"ErrorQueueEndpoint.xml\"/>\n"
				+"\t\t\t\t</call>\n"
				+"\t\t\t</sequence>\n"
				+"\t\t</target>\n"
				+"\t</clone>\n"
			+ "</sequence>\n";
		
	FileWriter myFileWritter = new FileWriter(aPath+File.separator+aComponentName+"API_01_"+Operation+aComponentName+aPostName+"FaultSequence_01.xml",true);
        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
        myBufferWritter.write(myFaultSequenceContents);
        myBufferWritter.close();

	}
	/* Create fault sequence (only required for ESB config project)
	* @param aPath 	Base path of ESB sub-project, sequences folder
	* @param aComponentName 	The name of the component/sub-component for which project is to be created 
	*/
	public void createAPITransformSequence(String aPath, String Operation, String aComponentName, String aPostName, String MessageType) throws Exception {
		
		String myTransformSequenceContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
		if(MessageType == "Request")
		{
			myTransformSequenceContents = myTransformSequenceContents
					+"<sequence xmlns=\"http://ws.apache.org/ns/synapse\" name=\""+aComponentName+"API_01_Convert"+Operation+aComponentName+aPostName+"CDMRequestToMeveoRequest_01\">\n"
					+"\t<call-template target=\"gov:com/commons/util/v1/templates/LoggerTemplate.xml\" description=\"Log-INFO\">\n"
					+"\t\t<with-param name=\"SequenceName\" value=\""+aComponentName+"API_01_Convert"+Operation+aComponentName+aPostName+"CDMRequestToMeveoRequest_01\"/>\n"
					+"\t\t<with-param name=\"Message\" value=\"Going to convert "+Operation+aComponentName+aPostName+" CDM request to Meveo request.\"/>\n"
					+"\t\t<with-param name=\"LogLevel\" value=\"INFO\"/>\n"
					+"\t</call-template>\n"
					+"\t<xslt key=\"gov:nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/xslt/"+Operation+aComponentName+aPostName+"CDMRequestToMeveoRequest.xslt\" description=\"CDMToMeveoRequest\">\n"
					+"\t\t<resource location=\""+Operation+aComponentName+aPostName+"CDMRequestToMeveoRequest.xslt\" key=\"gov:nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/xslt/"+Operation+aComponentName+aPostName+"CDMRequestToMeveoRequest.xslt\"/>\n"
					+"\t</xslt>\n"
					+"\t<call-template target=\"gov:com/commons/util/v1/templates/LoggerTemplate.xml\" description=\"Log-INFO\">\n"
					+"\t\t<with-param name=\"SequenceName\" value=\""+aComponentName+"API_01_Convert"+Operation+aComponentName+aPostName+"CDMRequestToMeveoRequest_01\"/>\n"
					+"\t\t<with-param name=\"Message\" value=\"Converted "+Operation+aComponentName+aPostName+" CDM request to Meveo request successfully.\"/>\n"
					+"\t\t<with-param name=\"LogLevel\" value=\"INFO\"/>\n"
					+"\t\t</call-template>\n"
					+"</sequence>\n";
			
			FileWriter myFileWritter = new FileWriter(aPath+File.separator+aComponentName+"API_01_Convert"+Operation+aComponentName+aPostName+"CDMRequestToMeveoRequest_01.xml",true);
	        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
	        myBufferWritter.write(myTransformSequenceContents);
	        myBufferWritter.close();
		}
		else
		{
			myTransformSequenceContents = myTransformSequenceContents
					+"<sequence xmlns=\"http://ws.apache.org/ns/synapse\" name=\""+aComponentName+"API_01_Convert"+Operation+aComponentName+aPostName+"MeveoResponseToCDMResponse_01\">\n"
					+"\t<call-template target=\"gov:com/commons/util/v1/templates/LoggerTemplate.xml\" description=\"Log-INFO\">\n"
					+"\t\t<with-param name=\"SequenceName\" value=\""+aComponentName+"API_01_Convert"+Operation+aComponentName+aPostName+"MeveoResponseToCDMResponse_01\"/>\n"
					+"\t\t<with-param name=\"Message\" value=\"Going to convert "+Operation+aComponentName+aPostName+" Meveo response to CDM response.\"/>\n"
					+"\t\t<with-param name=\"LogLevel\" value=\"INFO\"/>\n"
					+"\t</call-template>\n"
					+"\t<xslt key=\"gov:nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/xslt/"+Operation+aComponentName+aPostName+"MeveoResponseToCDMResponse.xslt\" description=\"MeveoResponseToCDMResponse\">\n"
					+"\t\t<resource location=\""+Operation+aComponentName+aPostName+"MeveoResponseToCDMResponse.xslt\" key=\"gov:nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/xslt/"+Operation+aComponentName+aPostName+"MeveoResponseToCDMResponse.xslt\"/>\n"
					+"\t</xslt>\n"
					+"\t<call-template target=\"gov:com/commons/util/v1/templates/LoggerTemplate.xml\" description=\"Log-INFO\">\n"
					+"\t\t<with-param name=\"SequenceName\" value=\""+aComponentName+"API_01_Convert"+Operation+aComponentName+aPostName+"MeveoResponseToCDMResponse_01\"/>\n"
					+"\t\t<with-param name=\"Message\" value=\"Converted Meveo response to "+Operation+aComponentName+aPostName+" CDM response successfully.\"/>\n"
					+"\t\t<with-param name=\"LogLevel\" value=\"INFO\"/>\n"
					+"\t\t</call-template>\n"
					+"</sequence>\n";
			
			FileWriter myFileWritter = new FileWriter(aPath+File.separator+aComponentName+"API_01_Convert"+Operation+aComponentName+aPostName+"MeveoResponseToCDMResponse_01.xml",true);
	        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
	        myBufferWritter.write(myTransformSequenceContents);
	        myBufferWritter.close();
		}
	} 
	/* Create fault sequence (only required for ESB config project)
	* @param aPath 	Base path of ESB sub-project, sequences folder
	* @param aComponentName 	The name of the component/sub-component for which project is to be created 
	*/
	public void createAPIValidateSequence(String aPath, String Operation, String aComponentName, String aPostName, String MessageType) throws Exception {
		
		String myValidateSequenceContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
			+"<sequence xmlns=\"http://ws.apache.org/ns/synapse\" name=\""+aComponentName+"API_01_Validate"+Operation+aComponentName+aPostName+"CDM"+MessageType+"_01\">\n"  
			+"\t<call-template target=\"gov:com/commons/util/v1/templates/LoggerTemplate.xml\" description=\"Log-INFO\">\n"
			+"\t\t<with-param name=\"SequenceName\" value=\""+aComponentName+"API_01_Validate"+Operation+aComponentName+aPostName+"CDM"+MessageType+"_01\"/>\n"
			+"\t\t<with-param name=\"Message\" value=\"Going to Validate "+Operation+aComponentName+aPostName+" CDM "+MessageType+"\"/>\n"
			+"\t\t<with-param name=\"LogLevel\" value=\"INFO\"/>\n"
			+"\t</call-template>\n";
		
		if ((Operation.equals("Create") | Operation.equals("Update")) & MessageType.equals("Request"))
		{
			myValidateSequenceContents= myValidateSequenceContents 
					+"\t<filter description=\"\" regex=\"application/json\" source=\"get-property('ReponseType')\">\n"
				    +"\t\t<then>\n"
				    +"\t\t\t<xslt description=\"JSONXMLToCDM\" key=\"gov:nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/xslt/"+Operation+aComponentName+"JSONXMLToCDMRequest.xslt\">\n"
				    +"\t\t\t\t<resource key=\"gov:nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/xslt/"+Operation+aComponentName+"JSONXMLToCDMRequest.xslt\" location=\""+Operation+aComponentName+"JSONXMLToCDMRequest.xslt\"/>\n"
				    +"\t\t\t</xslt>\n"
				    +"\t\t</then>\n"
				    +"\t\t<else/>\n"
				    +"\t</filter>\n";
		}
				
		myValidateSequenceContents= myValidateSequenceContents
			+"\t<validate xmlns:tns=\"TODO:\" source=\"//TODO:\">\n"
			+"\t\t<schema key=\"XSD_PATH_TODO:\"/>\n"
			+"\t\t<resource location=\"REQUIRED_XSD_NAME.xsd\" key=\"REQUIRED_XSD_PATH_TODO:\"/>\n"
			+"\t\t<on-fail>\n"
				+"\t\t\t<call-template target=\"gov:com/commons/util/v1/templates/LoggerTemplate.xml\" description=\"Log-INFO\">\n"
				+"\t\t\t\t<with-param name=\"SequenceName\" value=\""+aComponentName+"API_01_Validate"+Operation+aComponentName+aPostName+"CDM"+MessageType+"_01\"/>\n"
				+"\t\t\t\t<with-param name=\"Message\" value=\"Error occurred while validating "+MessageType+".\"/>\n"
				+"\t\t\t\t<with-param name=\"LogLevel\" value=\"ERROR\"/>\n"
				+"\t\t\t</call-template>\n"
				+"\t<clone xmlns=\"http://ws.apache.org/ns/synapse\">\n"
				+"\t\t<target>\n"
				+"\t\t\t<sequence>\n"
				+"\t\t\t\t<payloadFactory media-type=\"xml\">\n"
				+"\t\t\t\t\t<format>\n"
				+"\t\t\t\t\t\t<ns8:"+Operation+aComponentName+aPostName+"Response xmlns:ns8=\"TODO:\" xmlns:ns4=\"http://www.ciber.nl/uiab/cdm/xsd/actionstatus_01\" xmlns=\"\">\n"
				+"\t\t\t\t\t\t\t<ns8:ActionStatus>\n"
				+"\t\t\t\t\t\t\t\t<ns4:Status>FAIL</ns4:Status>\n"
				+"\t\t\t\t\t\t\t\t<ns4:ErrorCode>$1</ns4:ErrorCode>\n"
				+"\t\t\t\t\t\t\t\t<ns4:Message>Invalid "+MessageType+"</ns4:Message>\n"
				+"\t\t\t\t\t\t\t</ns8:ActionStatus>\n"
				+"\t\t\t\t\t\t</ns8:"+Operation+aComponentName+aPostName+"Response>\n"
				+"\t\t\t\t\t</format>\n"
				+"\t\t\t\t\t<args>\n"
				+"\t\t\t\t\t\t<arg xmlns:ns=\"http://org.apache.synapse/xsd\" evaluator=\"xml\" expression=\"get-property('ERROR_CODE')\"/>\n"
				+"\t\t\t\t\t</args>\n"
				+"\t\t\t\t</payloadFactory>\n"
				+"\t\t\t\t<switch xmlns:ns=\"http://org.apache.synapse/xsd\" source=\"get-property('ResponseType')\">\n"
				+"\t\t\t\t\t<case regex=\"application/xml\">\n"
				+"\t\t\t\t\t\t<header name=\"Accept\" scope=\"transport\" value=\"application/xml\"/>\n"
				+"\t\t\t\t\t\t<property name=\"ContentType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"ContentType\"/>\n"
				+"\t\t\t\t\t\t<property name=\"messageType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"messageType\"/>\n"
				+"\t\t\t\t\t</case>\n"
		        +"\t\t\t\t\t<case regex=\"application/json\">\n"
		        +"\t\t\t\t\t\t<header name=\"Accept\" scope=\"transport\" value=\"application/json\"/>\n"
		        +"\t\t\t\t\t\t<property name=\"ContentType\" value=\"application/json\" scope=\"axis2\" type=\"STRING\" description=\"ContentType\"/>\n"
		        +"\t\t\t\t\t\t<property name=\"messageType\" value=\"application/json\" scope=\"axis2\" type=\"STRING\" description=\"messageType\"/>\n"
		        +"\t\t\t\t\t</case>\n"
		        +"\t\t\t\t\t<default>\n"
		        +"\t\t\t\t\t\t<header name=\"Accept\" scope=\"transport\" value=\"application/xml\"/>\n"
				+"\t\t\t\t\t\t<property name=\"ContentType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"ContentType\"/>\n"
				+"\t\t\t\t\t\t<property name=\"messageType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"messageType\"/>\n"
				+"\t\t\t\t\t</default>\n"
		        +"\t\t\t\t</switch>\n"
				+"\t\t\t\t<property name=\"NO_ENTITY_BODY\" scope=\"axis2\" action=\"remove\"/>\n"
				+"\t\t\t\t<property name=\"HTTP_SC\" value=\"400\" scope=\"axis2\"/>\n"
				+"\t\t\t\t<respond/>\n"
				+"\t\t\t</sequence>\n"
				+"\t\t</target>\n"
				+"\t\t<target>\n"
				+"\t\t\t<sequence>\n"
				+"\t\t\t\t<payloadFactory media-type=\"xml\" description=\"ErrorMessage\">\n"
				+"\t\t\t\t\t<format>\n"
		        +"\t\t\t\t\t\t<err:Error xmlns:err=\"http://ws.apache.org/ns/synapse\">\n"
		        +"\t\t\t\t\t\t\t<Header>\n"
		        +"\t\t\t\t\t\t\t\t<CMMHeader>\n"
		        +"\t\t\t\t\t\t\t\t\t<MessageTimeStamp>$5</MessageTimeStamp>\n"
		        +"\t\t\t\t\t\t\t\t\t<MessageId>$6</MessageId>\n"
		        +"\t\t\t\t\t\t\t\t\t<ComponentId>"+aComponentName+"API</ComponentId>\n"
		        +"\t\t\t\t\t\t\t\t\t<From>$1</From>\n"
		        +"\t\t\t\t\t\t\t\t\t<To>$2</To>\n"
		        +"\t\t\t\t\t\t\t\t\t<Operation>"+Operation+aComponentName+aPostName+"</Operation>\n"
		        +"\t\t\t\t\t\t\t\t\t<Domain>UiaB</Domain>\n"
		        +"\t\t\t\t\t\t\t\t</CMMHeader>\n"
		        +"\t\t\t\t\t\t\t</Header>\n"
		        +"\t\t\t\t\t\t\t<ErrorCode>$7</ErrorCode>\n"
		        +"\t\t\t\t\t\t\t<ErrorMessage>$3</ErrorMessage>\n"
		        +"\t\t\t\t\t\t\t<ErrorDetail>$6</ErrorDetail>\n"
		        +"\t\t\t\t\t\t\t<ErrorException>$4</ErrorException>\n"
		        +"\t\t\t\t\t\t</err:Error>\n"
		        +"\t\t\t\t\t</format>\n"
		        +"\t\t\t\t\t<args>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('MessageFrom')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('MessageDestination')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('ERROR_MESSAGE')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('ERROR_EXCEPTION')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('MessageTime')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('ERROR_DETAIL')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('ERROR_CODE')\"/>\n"
		        +"\t\t\t\t\t\t<arg evaluator=\"xml\" expression=\"get-property('MessageId')\"/>\n"
		        +"\t\t\t\t\t</args>\n"
		        +"\t\t\t\t</payloadFactory>\n"
		        +"\t\t\t\t<log level=\"full\" category=\"ERROR\" separator=\"---=== Validation Error "+Operation+aComponentName+aPostName+" ===---\"/>\n"
		        +"\t\t\t\t<property name=\"OUT_ONLY\" scope=\"default\" type=\"STRING\" value=\"true\"/>\n"
		        +"\t\t\t\t<call>\n"
				+"\t\t\t\t\t<endpoint key=\"gov:nl/ciber/uiab/"+aComponentName.toLowerCase()+"/service/v1/endpoint/"+aComponentName+"ErrorQueueEndpoint.xml\"/>\n"
				+"\t\t\t\t</call>\n"
				+"\t\t\t</sequence>\n"
				+"\t\t</target>\n"
				+"\t</clone>\n"
				+"\t\t</on-fail>\n"
			+"\t</validate>\n"
			+"\t<call-template target=\"gov:com/commons/util/v1/templates/LoggerTemplate.xml\" description=\"Log-INFO\">\n"
			+"\t\t<with-param name=\"SequenceName\" value=\""+aComponentName+"API_01_Validate"+Operation+aComponentName+aPostName+"CDM"+MessageType+"_01\"/>\n"
			+"\t\t<with-param name=\"Message\" value=\""+Operation+aComponentName+aPostName+" CDM "+MessageType+" validated successfully.\"/>\n"
			+"\t\t<with-param name=\"LogLevel\" value=\"INFO\"/>\n"
			+"\t</call-template>\n"
			+"</sequence>\n";
		
		
	FileWriter myFileWritter = new FileWriter(aPath+File.separator+aComponentName+"API_01_Validate"+Operation+aComponentName+aPostName+"CDM"+MessageType+"_01.xml",true);
        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
        myBufferWritter.write(myValidateSequenceContents);
        myBufferWritter.close();

	} 
	/* Create sequence (only required for ESB config project)
	* @param aPath 	Base path of ESB sub-project, sequences folder
	* @param aComponentName 	The name of the component/sub-component for which project is to be created 
	*/
	public void createAPISequence(String aPath, String Operation, String aComponentName, String aPostName,String sequenceType) throws Exception {
		String mySequenceContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+"<sequence xmlns=\"http://ws.apache.org/ns/synapse\" name=\""+aComponentName+"API_01_"+Operation+aComponentName+aPostName+sequenceType+"Sequence_01\">\n"  
				+"\t<log level=\"full\" separator=\"---=== "+aComponentName+"API_01_"+Operation+aComponentName+aPostName+sequenceType+"Sequence_01 ===---\"/>\n";
				
		if (sequenceType == "In"){
			mySequenceContents = mySequenceContents 
					+"\t<property name=\"RequestOperationName\" value=\""+Operation+aComponentName+aPostName+"\" scope=\"default\" type=\"STRING\" description=\"OperationName\"/>"
					+"\t<property name=\"MessageFrom\" value=\"Client\" scope=\"default\" type=\"STRING\" description=\"MessageFrom\"/>"
					+"\t<property name=\"MessageDestination\" value=\"Meveo\" scope=\"default\" type=\"STRING\" description=\"MessageDestination\"/>"
					+"\t<property xmlns:ns=\"http://org.apache.synapse/xsd\" name=\"ResponseType\" expression=\"get-property('transport', 'Accept')\" scope=\"default\" type=\"STRING\" description=\"ResponseType\"/>\n"
					+"\t<property name=\"ContentType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"ContentType\"/>\n"
					+"\t<property name=\"messageType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"messageType\"/>\n"
					+"\t<sequence key=\""+aComponentName+"API_01_Validate"+Operation+aComponentName+aPostName+"CDMRequest_01\"/>\n"
					+"\t<sequence key=\""+aComponentName+"API_01_Convert"+Operation+aComponentName+aPostName+"CDMRequestToMeveoRequest_01\"/>\n";
			mySequenceContents = mySequenceContents + "<sequence key=\""+aComponentName+"API_01_"+"SendRequestToMeveo_01\"/>";
		}
		else
		{	
			mySequenceContents = mySequenceContents 
					+"\t<property name=\"MessageFrom\" value=\"Meveo\" scope=\"default\" type=\"STRING\" description=\"SequenceType\"/>"
					+"\t<property name=\"MessageDestination\" value=\"Client\" scope=\"default\" type=\"STRING\" description=\"SequenceType\"/>"
					+"\t<sequence key=\""+aComponentName+"API_01_Convert"+Operation+aComponentName+aPostName+"MeveoResponseToCDMResponse_01\"/>\n"
					+"\t<sequence key=\""+aComponentName+"API_01_Validate"+Operation+aComponentName+aPostName+"CDMResponse_01\"/>\n"
					+"\t<switch xmlns:ns=\"http://org.apache.synapse/xsd\" source=\"get-property('ResponseType')\">\n"
							+"\t\t<case regex=\"application/xml\">\n"
							+"\t\t\t<header name=\"Accept\" scope=\"transport\" value=\"application/xml\"/>\n"
							+"\t\t\t<property name=\"ContentType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"ContentType\"/>\n"
							+"\t\t\t<property name=\"messageType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"messageType\"/>\n"
							+"\t\t</case>\n"
					        +"\t\t<case regex=\"application/json\">\n"
					        +"\t\t\t<header name=\"Accept\" scope=\"transport\" value=\"application/json\"/>\n"
					        +"\t\t\t<property name=\"ContentType\" value=\"application/json\" scope=\"axis2\" type=\"STRING\" description=\"ContentType\"/>\n"
					        +"\t\t\t<property name=\"messageType\" value=\"application/json\" scope=\"axis2\" type=\"STRING\" description=\"messageType\"/>\n"
					        +"\t\t</case>\n"
					        +"\t\t<default>\n"
					        +"\t\t\t<header name=\"Accept\" scope=\"transport\" value=\"application/xml\"/>\n"
							+"\t\t\t<property name=\"ContentType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"ContentType\"/>\n"
							+"\t\t\t<property name=\"messageType\" value=\"application/xml\" scope=\"axis2\" type=\"STRING\" description=\"messageType\"/>\n"
							+"\t\t</default>\n"
					        +"\t</switch>\n"
					+"\t<respond/>\n";
		}
		
		mySequenceContents = mySequenceContents + "</sequence>\n";
		
		FileWriter myFileWritter = new FileWriter(aPath+File.separator+aComponentName+"API_01_"+Operation+aComponentName+aPostName+sequenceType+"Sequence_01.xml",true);
        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
        myBufferWritter.write(mySequenceContents);
        myBufferWritter.close();
	} 
	public void createAPISendSequence(String aPath, String aComponentName, String apiResources) throws Exception {
		
		StringTokenizer myTokenizer = new StringTokenizer(apiResources, ",");
		
		String mySequenceContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+"<sequence xmlns=\"http://ws.apache.org/ns/synapse\" name=\""+aComponentName+"API_01_"+"SendRequestToMeveo_01\">\n"  
				+"\t<call-template target=\"gov:com/commons/util/v1/templates/LoggerTemplate.xml\" description=\"\">\n"
				+ "\t\t<with-param name=\"SequenceName\" value=\""+aComponentName+"API_01_"+"SendRequestToMeveo_01\"/>\n"
				+ "\t\t<with-param name=\"Message\" value=\"Going to send Request to Meveo.\"/>\n"
				+ "\t\t<with-param name=\"LogLevel\" value=\"INFO\"/>\n"
				+ "\t</call-template>\n"
				+ "\t<property xmlns:ns=\"http://org.apache.synapse/xsd\" name=\"Authorization\" expression=\"AUTHORIZATION\" scope=\"transport\" type=\"STRING\"/>\n"
				+"\t<switch source=\"get-property('RequestOperationName')\">\n";
		
		while(myTokenizer.hasMoreElements()) {
					
				String token = myTokenizer.nextToken();
				
				if (token.equals("Get"))
					{
						mySequenceContents = mySequenceContents+"\t\t<case regex=\"Get"+aComponentName+"PerCode\">\n"
						+ "\t\t\t<send>\n"
						+ "\t\t\t<header name=\"Action\" scope=\"default\" value=\"GET_"+aComponentName.toUpperCase()+"_PERCODE_HEADER\"/>\n"
						+ "\t\t\t\t<endpoint key=\"gov:nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/endpoint/"+token+aComponentName+"PerCodeMeveoEndpoint.xml\"/>\n"
						+ "\t\t\t</send>\n"
						+"\t\t</case>\n";
					}
				mySequenceContents = mySequenceContents+"\t\t<case regex=\""+token+aComponentName+"\">\n"
						+ "\t\t\t<send>\n"
						+ "\t\t\t<header name=\"Action\" scope=\"default\" value=\""+token.toUpperCase()+"_"+aComponentName.toUpperCase()+"_HEADER\"/>\n"
						+ "\t\t\t\t<endpoint key=\"gov:nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/endpoint/"+token+aComponentName+"MeveoEndpoint.xml\"/>\n"
						+ "\t\t\t</send>\n"
						+"\t\t</case>\n";;
		}
		mySequenceContents = mySequenceContents
		        +"\t\t<default>\n"
		        +"\t\t\t<log level=\"full\" category=\"WARN\" separator=\"---=== Invalid Request ===---\"/>\n" 
				+"\t\t\t<drop/>\n"
		        +"\t\t</default>\n"
		        +"\t</switch>\n";
		        
		mySequenceContents = mySequenceContents + "</sequence>\n";
		
		FileWriter myFileWritter = new FileWriter(aPath+File.separator+aComponentName+"API_01_"+"SendRequestToMeveo_01.xml",true);
        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
        myBufferWritter.write(mySequenceContents);
        myBufferWritter.close();
	} 

	public void createAPISequences(String aPath, String aComponentName, String apiResources) throws Exception {
		
		StringTokenizer myTokenizer = new StringTokenizer(apiResources, ",");
		
		while(myTokenizer.hasMoreElements()) {
			
			String token = myTokenizer.nextToken();
			if (token.equals("Get"))
			{
				createAPIFaultSequence(aPath, token, aComponentName,"PerCode");
				createAPISequence(aPath, token, aComponentName,"PerCode", "In");
				createAPITransformSequence(aPath, token, aComponentName, "PerCode", "Request");
				createAPIValidateSequence(aPath, token, aComponentName, "PerCode", "Request");
				
				createAPISequence(aPath, token, aComponentName,"PerCode", "Out");
				createAPITransformSequence(aPath, token, aComponentName, "PerCode", "Response");
				createAPIValidateSequence(aPath, token, aComponentName, "PerCode", "Response");
			}
			
			createAPIFaultSequence(aPath, token, aComponentName,"");
			createAPISequence(aPath, token, aComponentName,"", "In");
			createAPITransformSequence(aPath, token, aComponentName, "", "Request");
			createAPIValidateSequence(aPath, token, aComponentName, "", "Request");
			
			createAPISequence(aPath, token, aComponentName,"", "Out");
			createAPITransformSequence(aPath, token, aComponentName, "", "Response");
			createAPIValidateSequence(aPath, token, aComponentName, "", "Response");
		}
		
		
		createAPISendSequence(aPath,aComponentName, apiResources);
	} 
	public void createAPIEndPoints(String aPath, String aComponentName, String apiResources) throws Exception {
		
		StringTokenizer myTokenizer = new StringTokenizer(apiResources, ",");
		
		String CommonCode= "\t<timeout>\n"
							+"\t\t<duration>30000</duration>\n"
							+"\t\t<responseAction>fault</responseAction>\n"
							+"\t</timeout>\n"
							+"\t<markForSuspension>\n"
							+"\t\t<errorCodes>101504,101505,101500,101501,101506,101507,101508</errorCodes>\n"
							+"\t\t<retriesBeforeSuspension>60</retriesBeforeSuspension>\n"
							+"\t\t<retryDelay>300000</retryDelay>\n"
							+"\t</markForSuspension>\n"
							+"\t<suspendOnFailure>\n"
							+"\t\t<initialDuration>1000</initialDuration>\n"
							+"\t\t<maximumDuration>64000</maximumDuration>\n"
							+"\t\t<progressionFactor>2.0</progressionFactor>\n"
							+"\t</suspendOnFailure>\n";
		
		while(myTokenizer.hasMoreElements()) {
			
			String token = myTokenizer.nextToken();
			if (token.equals("Get"))
			{
				
				String myEndPointContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
						+"<endpoint xmlns=\"http://ws.apache.org/ns/synapse\" name=\""+token+aComponentName+"PerCodeMeveoEndpoint\">\n"  
						+"\t<address format=\"soap11\" uri=\"SERVICE_GET_"+aComponentName.toUpperCase()+"_PER_CODE_URI\">\n"
						+ CommonCode
						+"\t</address>\n"
						+"</endpoint>\n";
				
				FileWriter myFileWritter = new FileWriter(aPath+File.separator+token+aComponentName+"PerCodeMeveoEndpoint.xml",true);
		        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
		        myBufferWritter.write(myEndPointContents);
		        myBufferWritter.close();
			
			}
			String myEndPointContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
					+"<endpoint xmlns=\"http://ws.apache.org/ns/synapse\" name=\""+token+aComponentName+"MeveoEndpoint\">\n"  
					+"\t<address format=\"soap11\" uri=\"SERVICE_"+token.toUpperCase()+"_"+aComponentName.toUpperCase()+"_URI\">\n"
					+ CommonCode
					+"\t</address>\n"
					+"</endpoint>\n";
			
			FileWriter myFileWritter = new FileWriter(aPath+File.separator+token+aComponentName+"MeveoEndpoint.xml",true);
	        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
	        myBufferWritter.write(myEndPointContents);
	        myBufferWritter.close();
		}
		
		String myErrorEndPointContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+"<endpoint xmlns=\"http://ws.apache.org/ns/synapse\" name=\""+aComponentName+"ErrorQueueEndpoint\">\n"  
				+"\t<address format=\"pox\" statistics=\"disable\" trace=\"disable\" uri=\"jms:/UiaB."+aComponentName+".Error.Queue.01?transport.jms.ConnectionFactoryJNDIName=QueueConnectionFactory&amp;java.naming.factory.initial=org.apache.activemq.jndi.ActiveMQInitialContextFactory&amp;java.naming.provider.url=ACTIVE_MQ_URL&amp;transport.jms.DestinationType=queue\">\n"
				+ CommonCode
				+"\t</address>\n"
				+"</endpoint>\n";
		
		FileWriter myFileWritter2 = new FileWriter(aPath+File.separator+aComponentName+"ErrorQueueEndpoint.xml",true);
        BufferedWriter myBufferWritter2 = new BufferedWriter(myFileWritter2);
        myBufferWritter2.write(myErrorEndPointContents);
        myBufferWritter2.close();
	} 
	public void createAPIXSLTs(String aPath, String aComponentName, String apiResources) throws Exception {
		
		StringTokenizer myTokenizer = new StringTokenizer(apiResources, ",");
		
		String myXSLTContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+"<xsl:stylesheet />\n";
		
		while(myTokenizer.hasMoreElements()) {
			
			String token = myTokenizer.nextToken();
			if (token.equals("Get"))
			{
				FileWriter myFileWritter = new FileWriter(aPath+File.separator+token+aComponentName+"PerCodeCDMRequestToMeveoRequest.xslt",true);
		        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
		        myBufferWritter.write(myXSLTContents);
		        myFileWritter.close();
		        //myBufferWritter.close();
		        
		        FileWriter myFileWritter2 = new FileWriter(aPath+File.separator+token+aComponentName+"PerCodeMeveoResponseToCDMResponse.xslt",true);
		        BufferedWriter myBufferWritter2 = new BufferedWriter(myFileWritter2);
		        myBufferWritter2.write(myXSLTContents);
		        myFileWritter2.close();
		        //myBufferWritter2.close();
		        
			}
			if (token.equals("Create") | token.equals("Update"))
			{
				FileWriter myFileWritter = new FileWriter(aPath+File.separator+token+aComponentName+"JSONXMLToCDMRequest.xslt",true);
		        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
		        myBufferWritter.write(myXSLTContents);
		        myFileWritter.close();
		        //myBufferWritter.close();
		    }
			
			FileWriter myFileWritter = new FileWriter(aPath+File.separator+token+aComponentName+"CDMRequestToMeveoRequest.xslt",true);
	        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter); 
	        myBufferWritter.write(myXSLTContents);
	        myFileWritter.close();
	        //myBufferWritter.close();
	        
	        FileWriter myFileWritter2 = new FileWriter(aPath+File.separator+token+aComponentName+"MeveoResponseToCDMResponse.xslt",true);
	        BufferedWriter myBufferWritter2 = new BufferedWriter(myFileWritter2);
	        myBufferWritter2.write(myXSLTContents);
	        myFileWritter2.close();
	        //myBufferWritter2.close();
		}
	} 
	public void createAdapterRegistryResources(String aPath, String aComponentName, String apiResources) throws Exception {
		
		createAPIEndPoints(aPath,aComponentName,apiResources);
		createAPIXSLTs(aPath,aComponentName,apiResources);
	} 
	
	/**
	* Create src folder (only required for ESB config project)
	* @param aPath 	Base path of the project structure
	*/
	
	public void createSourceFolderStructureForESB (String aPath) {
		
		String mySynapseFolderPath = aPath+File.separator+"src"+File.separator+"main"+File.separator+"synapse-config";
		File myDirectory = new File(mySynapseFolderPath);
		myDirectory.mkdirs();
		
		myDirectory = new File(mySynapseFolderPath+File.separator+"api");
		myDirectory.mkdir();
		
		myDirectory = new File(mySynapseFolderPath+File.separator+"endpoints");
		myDirectory.mkdir();

		myDirectory = new File(mySynapseFolderPath+File.separator+"local-entries");
		myDirectory.mkdir();
		
		myDirectory = new File(mySynapseFolderPath+File.separator+"message-processors");
		myDirectory.mkdir();
		
		myDirectory = new File(mySynapseFolderPath+File.separator+"message-stores");
		myDirectory.mkdir();
		
		myDirectory = new File(mySynapseFolderPath+File.separator+"proxy-services");
		myDirectory.mkdir();
		
		myDirectory = new File(mySynapseFolderPath+File.separator+"sequences");
		myDirectory.mkdir();
		
		myDirectory = new File(mySynapseFolderPath+File.separator+"tasks");
		myDirectory.mkdir();
		
		myDirectory = new File(mySynapseFolderPath+File.separator+"templates");
		myDirectory.mkdir();
		
		String myGraphicalSynapseFolderPath = aPath+File.separator+"src"+File.separator+"main"+File.separator+"graphical-synapse-config";
		myDirectory = new File(myGraphicalSynapseFolderPath);
		myDirectory.mkdirs();
		
		myDirectory = new File(myGraphicalSynapseFolderPath+File.separator+"api");
		myDirectory.mkdir();

		myDirectory = new File(myGraphicalSynapseFolderPath+File.separator+"complex_endpoints");
		myDirectory.mkdir();
		
		myDirectory = new File(myGraphicalSynapseFolderPath+File.separator+"endpoints");
		myDirectory.mkdir();

		myDirectory = new File(myGraphicalSynapseFolderPath+File.separator+"local-entries");
		myDirectory.mkdir();
		
		myDirectory = new File(myGraphicalSynapseFolderPath+File.separator+"message-processors");
		myDirectory.mkdir();
		
		myDirectory = new File(myGraphicalSynapseFolderPath+File.separator+"message-stores");
		myDirectory.mkdir();
		
		myDirectory = new File(myGraphicalSynapseFolderPath+File.separator+"proxy-services");
		myDirectory.mkdir();
		
		myDirectory = new File(myGraphicalSynapseFolderPath+File.separator+"sequences");
		myDirectory.mkdir();
		
		myDirectory = new File(myGraphicalSynapseFolderPath+File.separator+"tasks");
		myDirectory.mkdir();
		
		myDirectory = new File(myGraphicalSynapseFolderPath+File.separator+"templates");
		myDirectory.mkdir();

	}
	
	public void createAdapterESBArtifactFile(String aPath, String aComponentName, String apiResources, String myGroupId) throws Exception {
		
		StringTokenizer myTokenizer = new StringTokenizer(apiResources, ",");
		
		String myArtifactFileContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<artifacts>\n"
				+ "\t<artifact name=\""+aComponentName+"API_01\" groupId=\""+myGroupId+".api\" version=\"1.0.0\" type=\"synapse/api\" serverRole=\"EnterpriseServiceBus\">\n"
				+ "\t\t<file>src/main/synapse-config/api/"+aComponentName+"API_01.xml</file>\n"
				+ "\t</artifact>\n";
		
		while(myTokenizer.hasMoreElements()) {
			String token = myTokenizer.nextToken();
			if (token.equals("Get"))
			{
				myArtifactFileContents = myArtifactFileContents
						+"\t<artifact name=\""+aComponentName+"API_01_"+token+aComponentName+"PerCodeInSequence_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
			        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_"+token+aComponentName+"PerCodeInSequence_01.xml</file>\n"
		        		+"\t</artifact>\n"
		        		+"\t<artifact name=\""+aComponentName+"API_01_Validate"+token+aComponentName+"PerCodeCDMRequest_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
			        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_Validate"+token+aComponentName+"PerCodeCDMRequest_01.xml</file>\n"
		        		+"\t</artifact>\n"
		        		+"\t<artifact name=\""+aComponentName+"API_01_Convert"+token+aComponentName+"PerCodeCDMRequestToMeveoRequest_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
			        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_Convert"+token+aComponentName+"PerCodeCDMRequestToMeveoRequest_01.xml</file>\n"
		        		+"\t</artifact>\n"
		        		+"\t<artifact name=\""+aComponentName+"API_01_"+token+aComponentName+"PerCodeOutSequence_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
			        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_"+token+aComponentName+"PerCodeOutSequence_01.xml</file>\n"
		        		+"\t</artifact>\n"
		        		+"\t<artifact name=\""+aComponentName+"API_01_Validate"+token+aComponentName+"PerCodeCDMResponse_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
			        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_Validate"+token+aComponentName+"PerCodeCDMResponse_01.xml</file>\n"
		        		+"\t</artifact>\n"
		        		+"\t<artifact name=\""+aComponentName+"API_01_Convert"+token+aComponentName+"PerCodeMeveoResponseToCDMResponse_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
			        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_Convert"+token+aComponentName+"PerCodeMeveoResponseToCDMResponse_01.xml</file>\n"
		        		+"\t</artifact>\n"
		        		+"\t<artifact name=\""+aComponentName+"API_01_"+token+aComponentName+"PerCodeFaultSequence_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
			        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_"+token+aComponentName+"PerCodeFaultSequence_01.xml</file>\n"
		        		+"\t</artifact>\n";
				
			}
			myArtifactFileContents = myArtifactFileContents
				+"\t<artifact name=\""+aComponentName+"API_01_"+token+aComponentName+"InSequence_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
	        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_"+token+aComponentName+"InSequence_01.xml</file>\n"
        		+"\t</artifact>\n"
        		+"\t<artifact name=\""+aComponentName+"API_01_Validate"+token+aComponentName+"CDMRequest_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
	        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_Validate"+token+aComponentName+"CDMRequest_01.xml</file>\n"
        		+"\t</artifact>\n"
        		+"\t<artifact name=\""+aComponentName+"API_01_Convert"+token+aComponentName+"CDMRequestToMeveoRequest_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
	        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_Convert"+token+aComponentName+"CDMRequestToMeveoRequest_01.xml</file>\n"
        		+"\t</artifact>\n"
        		+"\t<artifact name=\""+aComponentName+"API_01_"+token+aComponentName+"OutSequence_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
	        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_"+token+aComponentName+"OutSequence_01.xml</file>\n"
        		+"\t</artifact>\n"
        		+"\t<artifact name=\""+aComponentName+"API_01_Validate"+token+aComponentName+"CDMResponse_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
	        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_Validate"+token+aComponentName+"CDMResponse_01.xml</file>\n"
        		+"\t</artifact>\n"
        		+"\t<artifact name=\""+aComponentName+"API_01_Convert"+token+aComponentName+"MeveoResponseToCDMResponse_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
	        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_Convert"+token+aComponentName+"MeveoResponseToCDMResponse_01.xml</file>\n"
        		+"\t</artifact>\n"
        		+"\t<artifact name=\""+aComponentName+"API_01_"+token+aComponentName+"FaultSequence_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
	        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_"+token+aComponentName+"FaultSequence_01.xml</file>\n"
        		+"\t</artifact>\n";
		}
		
		myArtifactFileContents = myArtifactFileContents
				+"\t<artifact name=\""+aComponentName+"API_01_"+"SendRequestToMeveo_01"+"\" groupId=\""+myGroupId+".sequence\" version=\"1.0.0\" type=\"synapse/sequence\" serverRole=\"EnterpriseServiceBus\">\n"
	        	+"\t\t<file>src/main/synapse-config/sequences/"+aComponentName+"API_01_"+"SendRequestToMeveo_01.xml</file>\n"
        		+"\t</artifact>\n";
		
		myArtifactFileContents = myArtifactFileContents	+ "</artifacts>\n";
		
		FileWriter myFileWritter = new FileWriter(aPath+File.separator+"artifact.xml",true);
        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
        myBufferWritter.write(myArtifactFileContents);
        myBufferWritter.close();

	}
	public void createAdapterREGArtifactFile(String aPath, String aComponentName, String myGroupId, String apiResources) throws Exception {
		
		StringTokenizer myTokenizer = new StringTokenizer(apiResources, ",");
		
		String myArtifactFileContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<artifacts>\n";
		myArtifactFileContents = myArtifactFileContents
				+ "\t<artifact name=\""+aComponentName+"ErrorQueueEndpoint\" groupId=\""+myGroupId+".resource\" version=\"1.0.0\" type=\"registry/resource\" serverRole=\"EnterpriseServiceBus\">\n"
						+ "\t\t<item>\n"
						+ "\t\t\t<file>"+aComponentName+"ErrorQueueEndpoint.xml</file>\n"
						+ "\t\t\t<path>/_system/governance/nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/endpoint</path>\n"
						+ "\t\t\t<mediaType>application/vnd.wso2.esb.endpoint</mediaType>\n"
						+ "\t\t</item>\n"
				+ "\t</artifact>\n";
		
		while(myTokenizer.hasMoreElements()) {
			String token = myTokenizer.nextToken();
			if (token.equals("Get"))
			{
				myArtifactFileContents = myArtifactFileContents
						+ "\t<artifact name=\""+token+aComponentName+"PerCodeMeveoEndpoint\" groupId=\""+myGroupId+".resource\" version=\"1.0.0\" type=\"registry/resource\" serverRole=\"EnterpriseServiceBus\">\n"
								+ "\t\t<item>\n"
								+ "\t\t\t<file>"+token+aComponentName+"PerCodeMeveoEndpoint.xml</file>\n"
								+ "\t\t\t<path>/_system/governance/nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/endpoint</path>\n"
								+ "\t\t\t<mediaType>application/vnd.wso2.esb.endpoint</mediaType>\n"
								+ "\t\t</item>\n"
						+ "\t</artifact>\n";
				myArtifactFileContents = myArtifactFileContents
						+ "\t<artifact name=\""+token+aComponentName+"PerCodeCDMRequestToMeveoRequest\" groupId=\""+myGroupId+".resource\" version=\"1.0.0\" type=\"registry/resource\" serverRole=\"EnterpriseServiceBus\">\n"
								+ "\t\t<item>\n"
								+ "\t\t\t<file>"+token+aComponentName+"PerCodeCDMRequestToMeveoRequest.xslt</file>\n"
								+ "\t\t\t<path>/_system/governance/nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/xslt</path>\n"
								+ "\t\t\t<mediaType>application/xslt+xml</mediaType>\n"
								+ "\t\t</item>\n"
						+ "\t</artifact>\n"
						+ "\t<artifact name=\""+token+aComponentName+"PerCodeMeveoResponseToCDMResponse\" groupId=\""+myGroupId+".resource\" version=\"1.0.0\" type=\"registry/resource\" serverRole=\"EnterpriseServiceBus\">\n"
							+ "\t\t<item>\n"
							+ "\t\t\t<file>"+token+aComponentName+"PerCodeMeveoResponseToCDMResponse.xslt</file>\n"
							+ "\t\t\t<path>/_system/governance/nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/xslt</path>\n"
							+ "\t\t\t<mediaType>application/xslt+xml</mediaType>\n"
							+ "\t\t</item>\n"
						+ "\t</artifact>\n";
			}
			if (token.equals("Create") | token.equals("Update"))
			{
				myArtifactFileContents = myArtifactFileContents
						+ "\t<artifact name=\""+token+aComponentName+"JSONXMLToCDMRequest\" groupId=\""+myGroupId+".resource\" version=\"1.0.0\" type=\"registry/resource\" serverRole=\"EnterpriseServiceBus\">\n"
							+ "\t\t<item>\n"
							+ "\t\t\t<file>"+token+aComponentName+"JSONXMLToCDMRequest.xslt</file>\n"
							+ "\t\t\t<path>/_system/governance/nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/xslt</path>\n"
							+ "\t\t\t<mediaType>application/xslt+xml</mediaType>\n"
							+ "\t\t</item>\n"
						+ "\t</artifact>\n";
			}
			myArtifactFileContents = myArtifactFileContents
					+ "\t<artifact name=\""+token+aComponentName+"MeveoEndpoint\" groupId=\""+myGroupId+".resource\" version=\"1.0.0\" type=\"registry/resource\" serverRole=\"EnterpriseServiceBus\">\n"
					+ "\t\t<item>\n"
					+ "\t\t\t<file>"+token+aComponentName+"MeveoEndpoint.xml</file>\n"
					+ "\t\t\t<path>/_system/governance/nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/endpoint</path>\n"
					+ "\t\t\t<mediaType>application/vnd.wso2.esb.endpoint</mediaType>\n"
					+ "\t\t</item>\n"
			+ "\t</artifact>\n";
			myArtifactFileContents = myArtifactFileContents
					+ "\t<artifact name=\""+token+aComponentName+"CDMRequestToMeveoRequest\" groupId=\""+myGroupId+".resource\" version=\"1.0.0\" type=\"registry/resource\" serverRole=\"EnterpriseServiceBus\">\n"
							+ "\t\t<item>\n"
							+ "\t\t\t<file>"+token+aComponentName+"CDMRequestToMeveoRequest.xslt</file>\n"
							+ "\t\t\t<path>/_system/governance/nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/xslt</path>\n"
							+ "\t\t\t<mediaType>application/xslt+xml</mediaType>\n"
							+ "\t\t</item>\n"
					+ "\t</artifact>\n"
					+ "\t<artifact name=\""+token+aComponentName+"MeveoResponseToCDMResponse\" groupId=\""+myGroupId+".resource\" version=\"1.0.0\" type=\"registry/resource\" serverRole=\"EnterpriseServiceBus\">\n"
						+ "\t\t<item>\n"
						+ "\t\t\t<file>"+token+aComponentName+"MeveoResponseToCDMResponse.xslt</file>\n"
						+ "\t\t\t<path>/_system/governance/nl/ciber/uiab/service/"+aComponentName.toLowerCase()+"/v1/xslt</path>\n"
						+ "\t\t\t<mediaType>application/xslt+xml</mediaType>\n"
						+ "\t\t</item>\n"
					+ "\t</artifact>\n";
		}
		
		myArtifactFileContents = myArtifactFileContents + "</artifacts>\n";
		
		FileWriter myFileWritter = new FileWriter(aPath+File.separator+"artifact.xml",true);
        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
        myBufferWritter.write(myArtifactFileContents);
        myBufferWritter.close();

	}
	public void createSuperPomFile(String aPath,String myServiceName, String myGroupId)throws Exception 
	{
		String mySuperPomFileContents =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
		+"<project xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd\""
		+" xmlns=\"http://maven.apache.org/POM/4.0.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n"
		+"\t\t<modelVersion>4.0.0</modelVersion>\n"
			+"\t\t<groupId>"+myGroupId+"</groupId>\n"
			+"\t\t<artifactId>"+myServiceName+"API-super</artifactId>\n"
			+"\t\t<version>1.0.0-SNAPSHOT</version>\n"
			+"\t\t<packaging>pom</packaging>\n"
			+"\t\t<name>"+myServiceName+"API-super</name>\n"
			+"\t\t<description>Super pom for the "+myServiceName+"API</description>\n"
			+"\t\t<modules>\n"
				+"\t\t\t<module>"+myServiceName+"APIREG</module>\n"
				+"\t\t\t<module>"+myServiceName+"APIESB</module>\n"
				+"\t\t\t<module>"+myServiceName+"APICA</module>\n"
			+"\t\t</modules>\n"
			+"</project>\n";
		
		FileWriter myFileWritter = new FileWriter(aPath+File.separator+"pom.xml",true);
        BufferedWriter myBufferWritter = new BufferedWriter(myFileWritter);
        myBufferWritter.write(mySuperPomFileContents);
        myBufferWritter.close();
	}
	/**
	* Create project structure for adapters
	* @param aPropertiesConfig 	The configurations
	*/
	
	// KNOWN ISSUE: Optimize this implementation
	
	public void makeAdapterProjectStructure(Properties aPropertiesConfig) throws Exception {
		
		String myServiceName = aPropertiesConfig.getProperty("service.name");
		String myComponentBasePath = aPropertiesConfig.getProperty("directory")+File.separator+myServiceName+"API";
		String myGroupIdPrefix = aPropertiesConfig.getProperty("group.id.prefix");
		String myGroupIdPostFix = aPropertiesConfig.getProperty("group.id.postfix");
		String mySubProjectName = "";
		String myGroupId = "";
		
			myComponentBasePath = aPropertiesConfig.getProperty("directory")+File.separator+myServiceName+"API";
			mySubProjectName = myServiceName+"API"; 
			
			myGroupId = myGroupIdPrefix+".api."+myServiceName.toLowerCase()+"."+myGroupIdPostFix;
			
			File myDirectory = new File(myComponentBasePath);
			myDirectory.mkdir();
			createDotProjectFileForMainProject(myComponentBasePath, mySubProjectName);

			// SUB PROJECTS
			mySubProjectName = myServiceName+"API"+"CA";
			myDirectory = new File(myComponentBasePath+File.separator+mySubProjectName);
			myDirectory.mkdir();
			createdotProjectFileForCA(myComponentBasePath+File.separator+mySubProjectName, mySubProjectName);
			createPomFile(myComponentBasePath+File.separator+mySubProjectName, mySubProjectName, myGroupId,"pom_ca.xml",aPropertiesConfig.getProperty("nexus.url"));
			createSecurityFolder(myComponentBasePath+File.separator+mySubProjectName);
			
			mySubProjectName = myServiceName+"API"+"ESB";
			myDirectory = new File(myComponentBasePath+File.separator+mySubProjectName);
			myDirectory.mkdir();
			createDotProjectFileForSubProject(myComponentBasePath+File.separator+mySubProjectName, mySubProjectName,true);
			createSourceFolderStructureForESB(myComponentBasePath+File.separator+mySubProjectName);
			createPomFile(myComponentBasePath+File.separator+mySubProjectName, mySubProjectName, myGroupId,"pom_esb.xml","");
			
			createAPI(aPropertiesConfig,myComponentBasePath+File.separator+mySubProjectName+"/src/main/synapse-config/api",myServiceName,aPropertiesConfig.getProperty("operations"));
			createAPISequences(myComponentBasePath+File.separator+mySubProjectName+"/src/main/synapse-config/sequences",myServiceName,aPropertiesConfig.getProperty("operations"));
			createAdapterESBArtifactFile(myComponentBasePath+File.separator+mySubProjectName,myServiceName,aPropertiesConfig.getProperty("operations"),myGroupId);
			
			mySubProjectName = myServiceName+"API"+"REG";
			myDirectory = new File(myComponentBasePath+File.separator+mySubProjectName);
			myDirectory.mkdir();
			createDotProjectFileForSubProject(myComponentBasePath+File.separator+mySubProjectName, mySubProjectName,false);
			
			createAdapterRegistryResources(myComponentBasePath+File.separator+mySubProjectName,myServiceName,aPropertiesConfig.getProperty("operations"));
			createAdapterREGArtifactFile(myComponentBasePath+File.separator+mySubProjectName,myServiceName,myGroupId,aPropertiesConfig.getProperty("operations"));
			createDotClassPathFileForSubProject(myComponentBasePath+File.separator+mySubProjectName);
			createPomFile(myComponentBasePath+File.separator+mySubProjectName, mySubProjectName, myGroupId,"pom_reg.xml","");
			
			createSuperPomFile(myComponentBasePath,myServiceName, myGroupId);
		
	}	
	
	/**
	* Driver Program
	* @param aPropertiesConfig 	The configurations
	*/
	
	// KNOWN ISSUE: Optimize this implementation
	
	public static void main(String[] args) {
		
		try {
			
			// <-------------------- SKELETON ---------->
			InputStream stream = new FileInputStream("wso2-project-structure.properties");
			Properties properties = new Properties();
			properties.load(stream);
			Skeleton skeleton = new Skeleton();
			
			System.out.println(properties.getProperty("service.name"));
			System.out.println(properties.getProperty("connecting.applications"));
			System.out.println(properties.getProperty("directory"));
			
			skeleton.makeAdapterProjectStructure(properties);
			} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
