#!/bin/bash

#*********************************************************
#
#	This is the library of functions 
#	used for Active Spaces Components Scripts
# 	
#	Version: 1.0	(Initial Implementation)
# 	Author: Waqas Ali
#	
#	Known Issues / Assumptions: 
#	===========================
#	
#	1. TODO: Interpretation of errors from the error log
#
#**********************************************************

# List of functions in this library

# startASAgent
# stopASAgent
# startASMM
# stopASMM

#**********************************************************

# Include configurations

. ./as_configurations_v1.0.sh

# Paramters List: $1 = MetaspaceName , $2 = Discovery URL, $3 = Listen URL, $4 = Remote Listen URL, $5 = PID File Name, $6 = Service Name

startASAgent() {

		nohup $AS_HOME/bin/as-agent -metaspace $1 -discovery $2 -listen $3 -remote_listen $4 -debug 3 -log $AS_AGENT_STARTUP_LOG_PATH >> $AS_AGENT_STARTUP_LOG_PATH 2>> $AS_AGENT_STARTUP_ERROR_LOG_PATH &

	echo $! > $5
	echo "$6 started ..."

}

# Paramters List: None

startASMM() {

	nohup $JAVA_HOME/java -jar $ASMM_JAR_FILE >> $ASMM_STARTUP_LOG_PATH 2>> $ASMM_STARTUP_ERROR_LOG_PATH &
	echo $! > $ASMM_PID_FILE
    	echo "$ASMM_SERVICE_NAME started ..."
}

# Paramters List: $1 = PID File Name, $2 = Service Name

stopASAgent() {

	PID=$(cat $1);
	echo "$2 stopping ..."
        kill $PID;
        echo "$2 stopped ..."
        rm $1
}

# Paramters List: None

stopASMM() {

	PID=$(cat $ASMM_PID_FILE);
	echo "$ASMM_SERVICE_NAME stopping ..."
        kill $PID;
        echo "$ASMM_SERVICE_NAME stopped ..."
        rm $ASMM_PID_FILE
        rm -fr /tmp/jett* 
}

# Paramters List: $1 = MetaspaceName , $2 = Discovery URL, $3 = Listen URL, $4 = Remote Listen URL, $5 = PID File Name, $6 = Service Name $7 = Policy File Name, $8 = Identity 
startASAgentWithSecurity() {

                nohup $AS_HOME/bin/as-agent -metaspace $1 -listen $3 -remote_listen $4 -security_policy $7 -identity_password $8 -debug 3 -log $AS_AGENT_STARTUP_LOG_PATH >> $AS_AGENT_STARTUP_LOG_PATH 2>> $AS_AGENT_STARTUP_ERROR_LOG_PATH &

        echo $! > $5
        echo "$6 started ..."

}

