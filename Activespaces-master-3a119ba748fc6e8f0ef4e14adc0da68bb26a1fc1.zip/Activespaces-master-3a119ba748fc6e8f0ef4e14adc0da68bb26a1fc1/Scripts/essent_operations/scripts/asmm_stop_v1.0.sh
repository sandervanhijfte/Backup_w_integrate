#!/bin/bash

#***********************************************************************************
#
#	This script stops asmm
# 	
#	Version: 1.0	(Initial Implementation)
# 	Author: Imtiaz Hassan
#	
#	Known Issues/Assumptions: 
#	===========================
#
#	1. Start & Stop scripts are kept separate because otherwise it is confusing for 
#	   script users (if one generic script is made) and is error prone
#	2. Default log directory of asmm is used right now
#	3. ASMM command line arguments are not used. Default configurations are used
#	4. No additional logging is required because pid file will be used together with 
#	   GUI to verify and/or troubleshoot if asmm has been stopped properly
#	5. TODO: Interpretation of errors from the error log
#
#**********************************************************************************
#		Program Logic
#**********************************************************************************

# Import the configurations/environment variables

. ./as_functions_v1.0.sh

# Stop the ASMM, if already running

if [ -f $ASMM_PID_FILE ]; then
	stopASMM
else
        echo "$ASMM_SERVICE_NAME is not running ..."
fi

