#!/bin/bash

#***********************************************************************************
#
#	This script stops AS Agent for ms_mvs Metaspace
# 	
#	Version: 1.0	(Initial Implementation)
# 	Author: Imtiaz Hassan
#	
#	Known Issues/Assumptions: 
#	===========================
#
#	1. Start & Stop scripts are kept separate because otherwise it is confusing for 
#	   script users (if one generic script is made) and is error prone
#	2. No additional logging is required because pid file will be used together with 
#	   asmm to verify and/or troubleshoot if as-agent has been stopped properly
#	3. TODO: Interpretation of errors from the error log
#
#**********************************************************************************
#		Program Logic
#**********************************************************************************

# Import the configurations/environment variables

. ./as_functions_v1.0.sh

# Stop the AS-Agent, if already running

if [ -f $AS_AGENT_MS_ESSENT_SR_PID_FILE ]; then
	stopASAgent $AS_AGENT_MS_ESSENT_SR_PID_FILE $AS_AGENT_MS_ESSENT_SR_SERVICE_NAME
else
        echo "$AS_AGENT_MS_ESSENT_SR_SERVICE_NAME is not running ..."
fi

