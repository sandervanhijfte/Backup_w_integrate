#!/bin/bash

#***********************************************************************************
#
#	This script starts ASMM
# 	
#	Version: 1.0	(Initial Implementation)
# 	Author: Waqas Ali
#	
#	Known Issues/Assumptions: 
#	===========================
#
#	1. Start & Stop scripts are kept separate because otherwise it is confusing for 
#	   script users (if one generic script is made) and is error prone
#	2. Default log directory of asmm is used right now
#	3. ASMM command line arguments are not used. Default configurations are used
#	4. No additional logging is required because pid file will be used together with 
#	   GUI to verify and/or troubleshoot if asmm has been started properly
#	5. TODO: Interpretation of errors from the error log
#
#**********************************************************************************
#		Program Logic
#**********************************************************************************

# Import the configurations/environment variables

. ./as_functions_v1.0.sh

# Start the ASMM, if not already running

echo "Starting $ASMM_SERVICE_NAME ..."
if [ ! -f $ASMM_PID_FILE ]; then
	startASMM
else
    echo "$ASMM_SERVICE_NAME is already running ..."
fi


