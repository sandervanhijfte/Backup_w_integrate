#!/bin/bash

#*************************************************************************************
#
#	This file contains all the configurations / environment variables
#	used for Active Spaces components start/stop
# 	
#	Version: 1.0	(Initial Implementation)
# 	Author: Waqas Ali
#	
#	Known Issues / assumptions: 
#	=============================
#	
#	1. The location of the log/pid files needs to be confirmed.
#
#***************************************************************************************

#MISC

AS_HOME=/app/tibco/as/2.2
AS_AGENT_STARTUP_LOG_PATH=/var/app/tibco/tibco_data/logs/asagent_operations.log
AS_AGENT_STARTUP_ERROR_LOG_PATH=/var/app/tibco/tibco_data/logs/asagent_operations_error.log
ASMM_STARTUP_LOG_PATH=/var/app/tibco/tibco_data/logs/asmm_operations.log
ASMM_STARTUP_ERROR_LOG_PATH=/var/app/tibco/tibco_data/logs/asmm_operations_error.log

# ASMM Configurations

ASMM_SERVICE_NAME=ASMM
ASMM_PID_FILE=/var/app/tibco/tibco_data/pid/asmm.pid
ASMM_JAR_FILE=$AS_HOME/asmm/asmm.jar

# AS Agent for ms_sw Metaspace Configurations

AS_AGENT_MS_ESSENT_SW_SERVICE_NAME="essent_cloud_dev.asagent_ms_essent_sw_01"
AS_AGENT_MS_ESSENT_SW_PID_FILE="/var/app/tibco/tibco_data/pid/asagent_ms_essent_sw.pid"
AS_AGENT_MS_ESSENT_SW_DISCOVERY_URL="tcp://0.0.0.0:7000"
AS_AGENT_MS_ESSENT_SW_LISTEN_URL="tcp://0.0.0.0:7000"
AS_AGENT_MS_ESSENT_SW_REMOTE_LISTEN_URL="tcp://0.0.0.0:7001"
AS_AGENT_MS_ESSENT_SW_METASPACE_NAME=ms_essent_sw

# AS Agent for ms_essent_sr Metaspace Configurations

AS_AGENT_MS_ESSENT_SR_SERVICE_NAME="essent_cloud_dev.asagent_ms_essent_sr_01"
AS_AGENT_MS_ESSENT_SR_PID_FILE="/var/app/tibco/tibco_data/pid/asagent_ms_essent_sr.pid"
AS_AGENT_MS_ESSENT_SR_DISCOVERY_URL="tcp://0.0.0.0:8000"
AS_AGENT_MS_ESSENT_SR_LISTEN_URL="tcp://0.0.0.0:8000"
AS_AGENT_MS_ESSENT_SR_REMOTE_LISTEN_URL="tcp://0.0.0.0:8001"
AS_AGENT_MS_ESSENT_SR_METASPACE_NAME=ms_essent_sr

# AS Agent for ms_essent_businesspartner Metaspace Configurations

AS_AGENT_MS_ESSENT_BUSINESSPARTNER_SERVICE_NAME="essent_cloud_dev.asagent_ms_essent_businesspartner_01"
AS_AGENT_MS_ESSENT_BUSINESSPARTNER_PID_FILE="/var/app/tibco/tibco_data/pid/asagent_ms_essent_businesspartner.pid"
AS_AGENT_MS_ESSENT_BUSINESSPARTNER_DISCOVERY_URL="tcp://0.0.0.0:9000"
AS_AGENT_MS_ESSENT_BUSINESSPARTNER_LISTEN_URL="tcp://0.0.0.0:9000"
AS_AGENT_MS_ESSENT_BUSINESSPARTNER_REMOTE_LISTEN_URL="tcp://0.0.0.0:9001"
AS_AGENT_MS_ESSENT_BUSINESSPARTNER_METASPACE_NAME=ms_essent_businesspartner


# Setting environment variables

# JAVA
export JAVA_HOME=/home/asadm/jdk1.8.0_102/bin
export JRE_HOME=/home/asadm/jdk1.8.0_102/jre/bin
export PATH=$PATH:$HOME/bin:$JAVA_HOME/bin:$JRE_HOME/bin

# AS
export AS_HOME=/app/tibco/as/2.2
export LD_LIBRARY_PATH=$AS_HOME/lib
export PATH=$PATH:$AS_HOME/bin

