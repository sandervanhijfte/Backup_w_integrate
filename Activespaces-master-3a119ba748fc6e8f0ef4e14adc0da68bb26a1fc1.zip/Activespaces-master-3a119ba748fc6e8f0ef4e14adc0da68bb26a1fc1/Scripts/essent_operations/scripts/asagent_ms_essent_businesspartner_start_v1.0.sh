#!/bin/bash

#***********************************************************************************
#
#	This script starts AS Agent for ms_crm Metaspace
# 	
#	Version: 1.0	(Initial Implementation)
# 	Author: Imtiaz Hassan
#	
#	Known Issues/Assumptions: 
#	===========================
#
#	1. Start & Stop scripts are kept separate because otherwise it is confusing for 
#	   script users (if one generic script is made) and is error prone
#	2. No additional logging is required because pid file will be used together with 
#	   asmm to verify and/or troubleshoot if as-agent has been started properly
#	3. TODO: Interpretation of errors from the error log
#
#**********************************************************************************
#		Program Logic
#**********************************************************************************

# Import the configurations/environment variables

. ./as_functions_v1.0.sh

# Start the AS-AGENT, if not already running

echo "Starting $AS_AGENT_MS_ESSENT_BUSINESSPARTNER_SERVICE_NAME ..."

if [ ! -f $AS_AGENT_MS_ESSENT_BUSINESSPARTNER_PID_FILE ]; then
	startASAgent $AS_AGENT_MS_ESSENT_BUSINESSPARTNER_METASPACE_NAME $AS_AGENT_MS_ESSENT_BUSINESSPARTNER_DISCOVERY_URL $AS_AGENT_MS_ESSENT_BUSINESSPARTNER_LISTEN_URL $AS_AGENT_MS_ESSENT_BUSINESSPARTNER_REMOTE_LISTEN_URL $AS_AGENT_MS_ESSENT_BUSINESSPARTNER_PID_FILE $AS_AGENT_MS_ESSENT_BUSINESSPARTNER_SERVICE_NAME
else
	echo "$AS_AGENT_MS_ESSENT_BUSINESSPARTNER_SERVICE_NAME is already running ..."
fi


