/*
    Author: Yasir Janjua
    Last update date: 23 April 2018
    Version: 1.0.1

    This script builds the Delivery Table and is !!!!ONLY TO BE USED!!!!! when a new instance is created.
    The Delivery table holds the deliveries of the GGMD KPI Monitor.
*/

/*
    First the table is dropped before creation. !!!!!DON'T!!!!!! run this script unless you need to rebuild the database.
*/

DROP TABLE delivery;
CREATE TABLE delivery (
    ContractId VARCHAR(50),
    DeliveryDate DATE NOT NULL,
    ActivityName VARCHAR(100),
    ActivityShortName VARCHAR(50),
    ActivityDescription VARCHAR(500),
    ActivityDeliveryReportingCode VARCHAR(50),
    ActivityDeliveryInvoiceCode VARCHAR(50),
    ActivityDeliverySalaryCode VARCHAR(50),
    ActivityDeliveryServiceCode VARCHAR(50),
    ProductCode VARCHAR(50),
    ProductName VARCHAR(100),
    ProductDescription VARCHAR(500),
    OrganizationId VARCHAR(50),
    OrganizationName VARCHAR(100),
    EmployeeId VARCHAR(50) NOT NULL,
    EmployeeLastName VARCHAR(100),
    EmployeeInitials VARCHAR(50),
    EmployeeInfix VARCHAR(50),
    EmployeeNumberOfHoursWorked DECIMAL(6,2),
    EmployeeNumberOfHoursVacation DECIMAL(6,2),
    DeliveredByOtherEmployees VARCHAR(50),
    CustomerIdentifier VARCHAR(50) NOT NULL,
    CustomerLastName VARCHAR(100),
    CustomerInitials VARCHAR(50),
    CustomerInfix VARCHAR(50),
    CustomerYearOfBirth INTEGER,
    CustomerMonthOfBirth INTEGER,
    CustomerZipCode VARCHAR(50),
    IsCustomerAbsent VARCHAR(50),
    IsCustomerAbsencePlanned VARCHAR(50),
    CustomerReportCode VARCHAR(50),
    IsCustomerReportSet VARCHAR(50),
    CustomerReportDate DATE,
    CustomerReportRun VARCHAR(50),
    CustomerDeclarationCode VARCHAR(50),
    IsCustomerDeclarationSet VARCHAR(50),
    CustomerDeclarationDate DATE,
    CustomerDeclarationRun VARCHAR(50),
    BillableTime INTEGER NOT NULL,
    TotalDeliveredPerDeliveryPeriod INTEGER,
    VolumeAssignedByContract INTEGER,
    DifferenceBetweenDeliveredAndAssigned INTEGER,
    DeliveryPeriod	VARCHAR(50),
    CustomerRegion VARCHAR(100),
    ActivityId VARCHAR(45),
    ActivityDefaultDeclarationCode VARCHAR(50),
    EmployeeFirstName VARCHAR(45),
    EmployeeDepartment VARCHAR(45),
    EmployeePersonalPerformanceIndicator DECIMAL(6,2),
    EmployeeDesignation VARCHAR(45),
    DateActivityLogged DATE,
    EmployeeThatLoggedTheActivity VARCHAR(100),
    DateThatActivityLogChanged DATE,
    EmployeeThatChangedTheActivityLog VARCHAR(100),
    IsDeliveryDiscarded VARCHAR(50),
    ReasonForDiscardingDelivery VARCHAR(100),
    CONSTRAINT PK_Delivery PRIMARY KEY (DeliveryDate, EmployeeId, CustomerIdentifier)
);