package nl.ggmd.file.splitter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Scanner;

import org.apache.synapse.MessageContext; 
import org.apache.synapse.mediators.AbstractMediator;


public class FileSplitter extends AbstractMediator { 
	private int sizeOfFile = 0;
	private static String filePath=null;
	private String outputDirectoryPath=null;
	
	public boolean mediate(MessageContext context) { 
		try {
		sizeOfFile = (int)context.getProperty("SizeOfFile");
		filePath = (String)context.getProperty("FilePath");
		outputDirectoryPath = (String)context.getProperty("OutputDirectoryPath");
		String fileName =null;
		File dir = new File(filePath);
		File [] files = dir.listFiles(new FilenameFilter() {
		    @Override
		    public boolean accept(File dir, String name) {
		        return name.startsWith("GGMD deliveries");
		    }
		});

		for (File xmlfile : files) {
			fileName = xmlfile.getAbsolutePath();
		}
		FileReader fileReader = new FileReader(fileName);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		bufferedReader.readLine();
		String line="";
		int fileSize = 0;
		BufferedWriter fos = new BufferedWriter(new FileWriter(outputDirectoryPath+new Date().getTime()+".csv",true));
		while((line = bufferedReader.readLine()) != null) {
		    if(fileSize + line.getBytes().length > sizeOfFile * 1024 * 1024){
		        fos.flush();
		        fos.close();
		        fos = new BufferedWriter(new FileWriter(outputDirectoryPath+new Date().getTime()+".csv",true));
		        fos.write(line+"\n");
		        fileSize = line.getBytes().length;
		    }else{
		        fos.write(line+"\n");
		        fileSize += line.getBytes().length;
		    }
		}  
		fos.flush();
		fos.close();
		bufferedReader.close();
		log.info("Total files generated: " +Files.list(Paths.get(outputDirectoryPath)).count());
		log.info("Going Remove file");
		File file = new File(fileName);
		if(file.delete()){
			log.info(file.getName() + " is deleted.");
		}else{
			log.info("Delete operation is failed.");
		}
	}catch (Exception e){
		e.printStackTrace();
		log.error(e);
	}
		return true;
	}
	}

