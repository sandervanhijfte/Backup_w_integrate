20-02-2019
Author Sander van Hijfte
This component is the WSO2 data service that enables all crud for delivery data except for the GGMDKPI monitor
