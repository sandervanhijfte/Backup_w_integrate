/*
 *	@Author: Waqas Ali Razzzaq
 *
 *  @Usage:
 *			1. Convert Alert Json message to Alert DTO
 *	@Known Issues:
 *
 *
 *	@VersionHistory:
 *			01.001 (Initial Implementation)
 *		    01.002 setAlertDTO function added to make it reusable
 *
 */

package nl.weintegrate.wealert.app.messaging;

/* Android Imports */

import android.content.Context;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import nl.weintegrate.wealert.app.dto.AlertDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.IAlertDAO;
import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

/* WeIntegrate Imports */

/* Class Declarations start*/
public class AlertProcessor implements IAlertProcessor {

    /***************************************************************
     VARIABLES
     ****************************************************************/

    private static final String CLASS_NAME = "AlertProcessor";

    /***************************************************************
     PUBLIC - METHOD
     ****************************************************************/

    @Override
    public void processAlert(JSONObject aJsonObject,Context aContext) throws WeAlertException {
        try {
            setAlertDTO(aJsonObject);
            DAOFactory mySQLLiteDaoFactory;
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(aContext);
            IAlertDAO myAlertDao = mySQLLiteDaoFactory.getAlertDAO();
            myAlertDao.insertAlert(setAlertDTO(aJsonObject));
        } catch (JSONException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,exception);
            throw myWeAlertException;
        } catch (ParseException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,exception);
            throw myWeAlertException;
        }
    }

    /***************************************************************
     PRIVATE - METHOD
     ****************************************************************/
    /*
    * Usage:
    *       Setting Alert DTO from received Json message
    *
    * Params:
    *       aJsonObject: Json message payload
    * */
    private AlertDTO setAlertDTO (JSONObject aJsonObject) throws WeAlertException, JSONException, ParseException {
        AlertDTO myAlertDTO = new AlertDTO();
        try {
            SimpleDateFormat myDateFormatter = new SimpleDateFormat(Constant.ALERT_TIMESTAMP_FORMAT);
            Date myTimeStamp = myDateFormatter.parse(aJsonObject.getJSONObject("Alert").get("TimeStamp").toString());
            myAlertDTO.setTheAlertId(aJsonObject.getJSONObject("Alert").get("AlertId").toString());
            myAlertDTO.setTheTimestamp(myTimeStamp);
            myAlertDTO.setTheSeverity(aJsonObject.getJSONObject("Alert").get("Severity").toString());
            myAlertDTO.setTheAlertType(aJsonObject.getJSONObject("Alert").get("AlertType").toString());
            myAlertDTO.setTheAlertTitle(aJsonObject.getJSONObject("Alert").get("AlertTitle").toString());
            myAlertDTO.setTheAlertMessage(aJsonObject.getJSONObject("Alert").get("AlertMessage").toString());
            myAlertDTO.setTheHost(aJsonObject.getJSONObject("Alert").get("HostName").toString());
            myAlertDTO.setTheEnvironmentName(aJsonObject.getJSONObject("Alert").get("EnvironmentName").toString());
            myAlertDTO.setTheComponentName(aJsonObject.getJSONObject("Alert").get("ComponentName").toString());
        }catch (Exception exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,exception);
            throw myWeAlertException;
        }
        return myAlertDTO;
    }
} // End Of Class
