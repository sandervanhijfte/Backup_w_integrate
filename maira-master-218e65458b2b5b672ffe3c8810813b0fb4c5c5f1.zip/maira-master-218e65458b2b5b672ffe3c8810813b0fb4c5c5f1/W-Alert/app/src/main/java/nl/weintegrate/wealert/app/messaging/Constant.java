/*
 *	@Author: Waqas Ali Razzzaq
 *
 *  @Usage:
 *			1. Constants deceleration used by messaging package
 *
 *	@Known Issues:
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *
 *
 */
package nl.weintegrate.wealert.app.messaging;

public class Constant {

    public static final int KEEP_ALIVE_INTERVAL =120;
    public static final int HTTP_STATUS_CODE = 200;
    public static final String EVENT_SUBSCRIPTION_RESPONSE = "GetEventSubscriptionResponse";
    public static final String EVENT_SUBSCRIPTION = "EventSubscription";
    public static final String EVENT_SUBSCRIPTION_DETAIL = "SubscriptionDetail";
    public static final String BROKER_URL = "BrokerUrl";
    public static final String USER_NAME = "UserName";
    public static final String PASSWORD = "Password";
    public static final String TOPIC_NAME = "TopicName";
    public static final String SINGLE_SUBSCRIPTION = "SingleTopic";
    public static final String MULTIPLE_SUBSCRIPTION = "MultipleTopic";
    //public static final String EVENT_SUBSCRIPTION_API = "http://213.187.243.177:8293/eventsubscriptionmanagement_01/eventsubscriptions/";
    public static final String EVENT_SUBSCRIPTION_API = "http://213.187.243.177:8283/eventsubscriptionmanagement_01/eventsubscriptions/";
}
