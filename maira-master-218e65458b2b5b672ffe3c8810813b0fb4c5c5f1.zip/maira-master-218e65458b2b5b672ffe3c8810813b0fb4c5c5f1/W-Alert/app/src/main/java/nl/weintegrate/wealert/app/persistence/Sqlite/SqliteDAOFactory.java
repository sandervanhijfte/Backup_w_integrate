package nl.weintegrate.wealert.app.persistence.Sqlite;
/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. Implements functions of DAOFactory
 *
 *	@KnownIssues:
 *          1. ://TODO Setting the context for Sqlite Database(to be reviewed by Imtiaz)
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *			01.002 Added implementation for createConnection function
 */

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.IAlertDAO;
import nl.weintegrate.wealert.app.persistence.ISubscriptionDAO;
import nl.weintegrate.wealert.app.persistence.IUserDAO;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;


public class SqliteDAOFactory extends DAOFactory {
    private static final String CLASS_NAME = "SqliteDAOFactory";
	private SqliteDB theSqliteDB;
    private SQLiteDatabase theDB;
	private Context theCurrentContext;

	@Override
	public IAlertDAO getAlertDAO() throws WeAlertException {
		// TODO Auto-generated method stub
		return new SqliteAlertDAO(theSqliteDB, theCurrentContext);
	}
	
	@Override
	public IUserDAO getUserDAO() throws WeAlertException {
		// TODO Auto-generated method stub
		return new SqliteUserDAO(theSqliteDB);
	}

	@Override
	public ISubscriptionDAO getSubscriptionDAO() throws WeAlertException {
		return new SqliteSubscriptionDAO(theSqliteDB);
	}

	@Override
	public void createConnection(String aConnnectionUri) {
		
		// If SQLite DB is not already opened then we open it.
		this.theDB = theSqliteDB.OpenDatabase();

	}

	@Override
	public void destroyConnection() {
		theSqliteDB.CloseDatabase();
		
	}
	/*
	*
	*   @Usage:
	*       1. Sets the current context for the database management
	*
	 */
    @Override
    public void setContext(Context aCurrentContext) throws WeAlertException {
		try {
			this.theSqliteDB = new SqliteDB(aCurrentContext);
			this.theCurrentContext = aCurrentContext;
		}
		catch (Exception e)
		{
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "An exception occurred while setting the context");
            throw myWeAlertException;
		}
    }


}
