package nl.weintegrate.wealert.app.persistence;
/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. Interface for all functions used for managing users database

 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *
 */

import nl.weintegrate.wealert.app.dto.UserDTO;
import nl.weintegrate.wealert.app.utils.WeAlertException;

public interface IUserDAO {
	
	public void insertUserProfile (UserDTO aUserDto) throws WeAlertException;
	public UserDTO getUserProfile () throws WeAlertException;
    public void deleteUserPassword () throws WeAlertException;
    public void insertUserPassword (String aUserPassword) throws WeAlertException;
    public void deleteUserProfile () throws WeAlertException;
    public int getUserCount() throws WeAlertException;
}
