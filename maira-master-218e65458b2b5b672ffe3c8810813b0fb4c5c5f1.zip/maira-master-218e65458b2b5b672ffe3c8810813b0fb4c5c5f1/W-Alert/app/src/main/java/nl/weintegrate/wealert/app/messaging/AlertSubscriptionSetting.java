/*
 *	@Author: Waqas Ali Razzzaq
 *
 *  @Usage:
 *			1. Fetch the Subscription details from server
 *
 *	@Known Issues:
 *              1. make separate class for server call
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *		    01.002 delete subscription function added
 *
 *
 */
package nl.weintegrate.wealert.app.messaging;

/* Android Imports */

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.UUID;

import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.dto.SubscriptionDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.ISubscriptionDAO;
import nl.weintegrate.wealert.app.ui.AlertListActivity;
import nl.weintegrate.wealert.app.ui.LoginActivity;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

/* WeIntegrate Imports */

/* Class Declarations start*/
public class AlertSubscriptionSetting extends AsyncTask {

    /***************************************************************
     VARIABLES
     ****************************************************************/

    private final String CLASS_NAME = "AlertSubscriptionSetting";
    private String theTopicName = null;
    private ArrayList<String> theTopicNameList = null;
    private String theBrokerUrl = null;
    private String theSubscriptionId = null;
    private String theSubscriptionName = null;
    private String theUserId = null;
    private String theUserName = null;
    private String thePassword = null;
    private String theEncryptionKey= null;
    private String theOrganizationId = null;
    private Context theContext;

    public AlertSubscriptionSetting(Context aContext) {
        this.theContext = aContext;
    }
    /***************************************************************
     PUBLIC - METHOD
     ****************************************************************/
    public void getSubscriptionDetail(String aUserId, String aOrganizationId) {
        theUserId = aUserId;
        theOrganizationId = aOrganizationId;
        this.execute();
        }

    /***************************************************************
     PRIVATE - METHOD
     ****************************************************************/

    /*
    * Usage:
    *       Function for making the GetSubscription Json Request
    * Params:
    *       aOrganizationId: ClientId
    * */

    private String makeGetEventSubscriptionJSONRequest(String aOrganizationId) {

        String myGetEventSubscriptionRequest = "{\"GetEventSubscriptionRequest\": {\n" +
                "   \"Header\": {\"CMMHeader\": {\"CorrelationId\": \"" + UUID.randomUUID().toString() + "\"}},\n" +
                "   \"ClientContext\": {\"OrganizationId\": \"" + aOrganizationId + "\"}}";

        return myGetEventSubscriptionRequest;
    }
    /*
    * Usage:
    *       Function for sending the GetSubscription Json Request to server
    * Params:
    *       aUsername: UserName of current logged in user
    *       aOrganizationId: Client id of current logged in user
    * */
    private JSONObject sendGetEventSubscriptionRequest(String aUsername, String aOrganizationId) throws WeAlertException, JSONException {

        StringBuilder myResponseBuffer = null;
        InputStream myInputStreamWriter;
        DataOutputStream myStreamWriter;
        BufferedReader myResponseReader;
        String myResponseLine;
        String myGetEventSubscriptionPayload;
        HttpURLConnection myConnection = null;

        try {
            myGetEventSubscriptionPayload = makeGetEventSubscriptionJSONRequest(aOrganizationId);
            URL myUrl = new URL(Constant.EVENT_SUBSCRIPTION_API + aUsername);
            myConnection = (HttpURLConnection) myUrl.openConnection();
            setHttpRequestProperties(myConnection);
            myStreamWriter = new DataOutputStream(myConnection.getOutputStream());
            myStreamWriter.writeBytes(myGetEventSubscriptionPayload);
            myStreamWriter.flush();
            myStreamWriter.close();
            if (myConnection.getResponseCode() == Constant.HTTP_STATUS_CODE) {

                myInputStreamWriter = myConnection.getInputStream();
                myResponseReader = new BufferedReader(new InputStreamReader(myInputStreamWriter));
                myResponseBuffer = new StringBuilder();
                while ((myResponseLine = myResponseReader.readLine()) != null) {
                    myResponseBuffer.append(myResponseLine);
                    myResponseBuffer.append('\r');
                }
                myResponseReader.close();
                myInputStreamWriter.close();
            }
        } catch (Exception exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Error while making GetEventSubscription call");
            throw myWeAlertException;
        } finally {
            if (myConnection != null) {
                myConnection.disconnect();
            }
        }
        return new JSONObject(myResponseBuffer.toString());
    }
    /*
    * Usage:
    *       Function to get Subscription Detail from JsonObject
    * Params:
    *       aJsonObject: Json request payload for get event subscription
    * */

    private String setSubscriptionDetail(JSONObject aJsonObject) throws JSONException {
        if (aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).optJSONArray(Constant.EVENT_SUBSCRIPTION_DETAIL) == null) {

            theBrokerUrl = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONObject(Constant.EVENT_SUBSCRIPTION_DETAIL).get(Constant.BROKER_URL).toString();
            theSubscriptionId= aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).get("SubscriptionId").toString();
            theSubscriptionName= aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).get("SubscriptionName").toString();
            theUserName = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONObject(Constant.EVENT_SUBSCRIPTION_DETAIL).get(Constant.USER_NAME).toString();
            thePassword = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONObject(Constant.EVENT_SUBSCRIPTION_DETAIL).get(Constant.PASSWORD).toString();
            theEncryptionKey = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).get("EventEncryptionKey").toString();
            theTopicName = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONObject(Constant.EVENT_SUBSCRIPTION_DETAIL).get(Constant.TOPIC_NAME).toString();
             return Constant.SINGLE_SUBSCRIPTION;
        } else {
            theTopicNameList= new ArrayList<>();
            theSubscriptionId= aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).get("SubscriptionId").toString();
            theSubscriptionName= aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).get("SubscriptionName").toString();
            theBrokerUrl = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONArray(Constant.EVENT_SUBSCRIPTION_DETAIL).getJSONObject(0).get(Constant.BROKER_URL).toString();
            theUserName = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONArray(Constant.EVENT_SUBSCRIPTION_DETAIL).getJSONObject(0).get(Constant.USER_NAME).toString();
            thePassword = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONArray(Constant.EVENT_SUBSCRIPTION_DETAIL).getJSONObject(0).get(Constant.PASSWORD).toString();
            theEncryptionKey = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).get("EventEncryptionKey").toString();
            theTopicNameList = parseJsonResponse(aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONArray(Constant.EVENT_SUBSCRIPTION_DETAIL));
        }
        return Constant.MULTIPLE_SUBSCRIPTION;
    }

    /*
    * Usage:
    *       Utility function for setting the http properties
    * Params:
    *       aHttpConnection: http connection object
    * */

    private void setHttpRequestProperties(HttpURLConnection aHttpConnection) throws WeAlertException {
        try {
            aHttpConnection.setRequestMethod("POST");
            aHttpConnection.setRequestProperty("Content-Type", "application/json");
            aHttpConnection.setRequestProperty("Accept", "application/json");
            aHttpConnection.setUseCaches(false);
            aHttpConnection.setDoInput(true);
            aHttpConnection.setDoOutput(true);
        } catch (ProtocolException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Error while setting HTTP request properties.");
            throw myWeAlertException;
        }
    }

    /***************************************************************
     PROTECTED - METHOD
     ****************************************************************/
    @Override
    protected Object doInBackground(Object[] params) {
        JSONObject myJsonObject;
        String myResponse = null;
        try {
            myJsonObject = sendGetEventSubscriptionRequest(theUserId, theOrganizationId);
            if (myJsonObject .getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).optJSONObject(Constant.EVENT_SUBSCRIPTION) != null) {

               myResponse = setSubscriptionDetail(myJsonObject);
            }
            else {
                showAlertDialog();
            }
        } catch (Exception exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,myWeAlertException.getMessage());
        }
        return myResponse;
    }

    @Override
    protected void onPostExecute(Object aObject) {
        WeAlertLogger myWeAlertLogger = new WeAlertLogger();
        SubscriptionDTO mySubscription = new SubscriptionDTO();
        DAOFactory mySQLLiteDaoFactory;
        if(aObject.toString() == Constant.MULTIPLE_SUBSCRIPTION) {

            try {
                mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
                mySQLLiteDaoFactory.setContext(theContext);
                ISubscriptionDAO mySubscriptionDao = mySQLLiteDaoFactory.getSubscriptionDAO();
                for (int topicIndex = 0; topicIndex < theTopicNameList.size(); topicIndex++) {
                    mySubscription.setBrokerUrl(theBrokerUrl);
                    mySubscription.setSubscriptionId(theSubscriptionId);
                    mySubscription.setSubscriptionName(theSubscriptionName);
                    mySubscription.setTopicName(theTopicNameList.get(topicIndex));
                    mySubscription.setUserName(theUserName);
                    mySubscription.setPassword(thePassword);
                    mySubscription.setEncryptionKey(theEncryptionKey);
                    if (mySubscriptionDao.insertSubscriptionDetail(mySubscription)) {

                        myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Subscription saved to Database.");
                    }
                    else {
                        myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Subscription not saved to Database.");
                    }
                }
            } catch (WeAlertException exception) {
                WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
                myWeAlertLogger.logMessage(Thread.currentThread().getId(),"AlertService",myWeAlertException.getMessage());
            }
        } else if (aObject.toString()==Constant.SINGLE_SUBSCRIPTION) {

            try {
                mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
                mySQLLiteDaoFactory.setContext(theContext);
                ISubscriptionDAO mySubscriptionDao = mySQLLiteDaoFactory.getSubscriptionDAO();
                    mySubscription.setBrokerUrl(theBrokerUrl);
                    mySubscription.setSubscriptionId(theSubscriptionId);
                    mySubscription.setSubscriptionName(theSubscriptionName);
                    mySubscription.setTopicName(theTopicName);
                    mySubscription.setUserName(theUserName);
                    mySubscription.setPassword(thePassword);
                    mySubscription.setEncryptionKey(theEncryptionKey);
                    if (mySubscriptionDao.insertSubscriptionDetail(mySubscription)) {

                        myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Subscription saved to Database.");
                    }
                    else {
                        myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Subscription not saved to Database.");
                    }
            } catch (WeAlertException exception) {
                WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
                myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,myWeAlertException.getMessage());
            }
        }
        else {
            showAlertDialog();
        }
    }
    /*
    * Usage:
    *       Function to getTopicList from JsonArray
    * Params:
    *       aSubscriptionDetail: subscription detail json array
    * */

    private ArrayList<String> parseJsonResponse(JSONArray aSubscriptionDetail) throws JSONException {
        ArrayList<String> myTopicNameList = new ArrayList<>();
        if (aSubscriptionDetail != null) {
            for (int loop = 0; loop < aSubscriptionDetail.length(); loop++) {
                myTopicNameList.add(aSubscriptionDetail.getJSONObject(loop).getString(Constant.TOPIC_NAME));
            }
        }
        return myTopicNameList;
    }

    private void showAlertDialog() {
        AlertDialog.Builder myDeleteConfirmationDialog = new AlertDialog.Builder(new LoginActivity(), R.style.Mytheme);
        myDeleteConfirmationDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent myIntentToStartAlertListActivity = new Intent(new LoginActivity(), AlertListActivity.class);

                myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                theContext.startActivity(myIntentToStartAlertListActivity);
            }
        });

        AlertDialog myDeleteDialog = myDeleteConfirmationDialog.create();
        myDeleteDialog.setTitle("Alert");
        myDeleteDialog.setMessage("No Subscription Found");
        myDeleteDialog.show();
        myDeleteDialog.getButton(AlertDialog.BUTTON_POSITIVE).setBackgroundColor(theContext.getResources().getColor(R.color.colorPrimaryDark));
    }
        /*
        * Usage:
        *       Function to delete Subscription details
        * Params:
        *       aContext: the current application context
        * */
    public void deleteSubscription(Context aContext) {
    DAOFactory mySQLLiteDaoFactory;
    try {
        mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
        mySQLLiteDaoFactory.setContext(aContext);
        ISubscriptionDAO mySubscriptionDao = mySQLLiteDaoFactory.getSubscriptionDAO();
        mySubscriptionDao.deleteSubscriptionDetail();
    } catch (WeAlertException exception) {
        WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
        WeAlertLogger myWeAlertLogger = new WeAlertLogger();
        myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,myWeAlertException.getMessage());
    }
}
}//End f Class

