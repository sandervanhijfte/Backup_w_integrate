package nl.weintegrate.wealert.app.ui;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.util.regex.Pattern;
import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.api.IdentityAndAccessManagement;
import nl.weintegrate.wealert.app.dto.UserDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.IUserDAO;
import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

public class ChangePasswordActivity extends AppCompatActivity {
    private final String CLASS_NAME = "ChangePasswordActivity";
    private String myOldPassword;
    private String myNewPassword;
    private String myConfirmPassword;
    private EditText theOldPasswordField;
    private EditText theNewPasswordField;
    private EditText theConfirmPasswordField;
    private Button theSubmitButton;
    private boolean isOldPasswordValidated = false;
    private boolean isNewPasswordValidated = false;
    private boolean isConfirmPasswordValidated = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        theOldPasswordField = (EditText) findViewById(R.id.editText_oldPassword);
        theNewPasswordField = (EditText) findViewById(R.id.editText_newPassword);
        theConfirmPasswordField = (EditText) findViewById(R.id.editText_confirmPassword);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //to set back button in toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });
        RelativeLayout myChangePasswordLayout = (RelativeLayout) findViewById(R.id.content_change_password);
        myChangePasswordLayout.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View view, MotionEvent ev)
            {
                hideKeyboard(view);
                return false;
            }
        });
        theSubmitButton = (Button) findViewById(R.id.button_submit);
        theSubmitButton.setEnabled(false);
        theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
        theOldPasswordField.setHint("Old Password");
        theNewPasswordField.setHint("Password");
        theConfirmPasswordField.setHint("Password");
        theOldPasswordField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus)
                {
                    theOldPasswordField.setHint("Old Password");
                    validateOldPassword();
                }
                else
                {
                    theOldPasswordField.setHint("");
                }
            }
        });
        theOldPasswordField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                theOldPasswordField.setHint("Old Password");
                validateOldPassword();
                validateNewPassword();

            }
        });
        theNewPasswordField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus)
                {
                    theNewPasswordField.setHint(" Password");
                    validateNewPassword();
                }
                else
                {
                    theNewPasswordField.setHint("");
                }
            }
        });
        theNewPasswordField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                theNewPasswordField.setHint(" Password");
                validateNewPassword();
                validateConfirmPassword();
            }
        });
        theConfirmPasswordField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus)
                {
                    theConfirmPasswordField.setHint(" Password");
                    validateConfirmPassword();
                }
                else
                {
                    theConfirmPasswordField.setHint("");
                }
            }
        });
        theConfirmPasswordField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                theConfirmPasswordField.setHint(" Password");
                validateConfirmPassword();
            }
        });
    }
    private void validateOldPassword()
    {
        if(theOldPasswordField.length()==0 ) {
            theOldPasswordField.setError(null);
            isOldPasswordValidated = false;
            if(theSubmitButton.isEnabled()) {
                theSubmitButton.setEnabled(false);
                theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
            }
        }
        else {
            if(theOldPasswordField.length()>=6) {
                theOldPasswordField.setError(null);
                isOldPasswordValidated = true;
                if(isConfirmPasswordValidated && isNewPasswordValidated) {
                    theSubmitButton.setEnabled(true);
                    theSubmitButton.setTextColor(getResources().getColor(R.color.colorWhite));
                }
            }
            else {
                theOldPasswordField.setError("Password must have at least 6 characters");
                isOldPasswordValidated = false;
                if(theSubmitButton.isEnabled()) {
                    theSubmitButton.setEnabled(false);
                    theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
                }
            }
        }
    }
    private void validateNewPassword()
    {
        boolean isPatternMatched = Pattern.matches("^\\p{Graph}*$",theNewPasswordField.getText().toString());
        boolean isPasswordSame = theNewPasswordField.getText().toString().equals(theOldPasswordField.getText().toString());
        if(theNewPasswordField.length()==0)
        {
            theNewPasswordField.setError(null);
            isNewPasswordValidated = false;
            if(theSubmitButton.isEnabled()) {
                theSubmitButton.setEnabled(false);
                theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
            }
        }
        else{
            if( isPatternMatched && theNewPasswordField.length()>=6 && !isPasswordSame) {
                theNewPasswordField.setError(null);
                isNewPasswordValidated = true;
                if(isOldPasswordValidated && isConfirmPasswordValidated) {
                    theSubmitButton.setEnabled(true);
                    theSubmitButton.setTextColor(getResources().getColor(R.color.colorWhite));
                }
            }
            else {
                theNewPasswordField.setError("1. Passwords may contain letters (A-Z, a-z), numbers (0-9) and punctuation marks ( !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~). 2. The new password cannot be the same as the old password.");
                isNewPasswordValidated = false;
                if(theSubmitButton.isEnabled()) {
                    theSubmitButton.setEnabled(false);
                    theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
                }
            }
        }
    }
    private void validateConfirmPassword()
    {
        if(theConfirmPasswordField.length()==0) {
            theConfirmPasswordField.setError(null);
            isConfirmPasswordValidated = false;
            if(theSubmitButton.isEnabled()) {
                theSubmitButton.setEnabled(false);
                theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
            }
        }
        else {
            if(theConfirmPasswordField.getText().toString().equals(theNewPasswordField.getText().toString())) {
                theConfirmPasswordField.setError(null);
                isConfirmPasswordValidated = true;
                if (isNewPasswordValidated && isOldPasswordValidated) {
                    theSubmitButton.setEnabled(true);
                    theSubmitButton.setTextColor(getResources().getColor(R.color.colorWhite));
                }
            }
            else {
                theConfirmPasswordField.setError("Must be the same as the new password.");
                isConfirmPasswordValidated = false;
                if (theSubmitButton.isEnabled()) {
                    theSubmitButton.setEnabled(false);
                    theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
                }
            }
        }
    }
    protected void hideKeyboard(View view)
    {
        InputMethodManager myInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        myInputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    @Override
    public void onBackPressed() {
        Intent myIntentToStartAlertListActivity = new Intent(ChangePasswordActivity.this, AlertListActivity.class);
        myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(myIntentToStartAlertListActivity);
        this.finish();
    }
    public void onChangePasswordSubmitClick(View view) {
        myOldPassword = theOldPasswordField.getText().toString();
        myNewPassword = theNewPasswordField.getText().toString();
        myConfirmPassword = theConfirmPasswordField.getText().toString();
        if(theOldPasswordField.getError() == null && theNewPasswordField.getError() == null && theConfirmPasswordField.getError() == null)
        {
            new ChangePasswordOperation().execute();
        }
    }
    private UserDTO getUserDetail(){
        UserDTO myUserProfile = new UserDTO();
        DAOFactory mySQLLiteDaoFactory;
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(this);
            IUserDAO myUserDao = mySQLLiteDaoFactory.getUserDAO();
            myUserProfile = myUserDao.getUserProfile();
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,myWeAlertException.getMessage());
        }
        return myUserProfile;
    }
    void updateUserPasswordInDatabase(String aPassword) throws WeAlertException {
        try {
            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IUserDAO myUserDao = mySqliteDaoFactory.getUserDAO();
            myUserDao.insertUserPassword(aPassword);
        }
        catch (WeAlertException myWeAlertException) {
            throw myWeAlertException;
        }
        catch (Exception e)
        {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            throw myWeAlertException;
        }
    }
    private class ChangePasswordOperation extends AsyncTask{
        ProgressDialog myChangePasswordProgressDialog =new ProgressDialog(ChangePasswordActivity.this, R.style.Mytheme);
        String myUsername;
        @Override
        protected void onPreExecute() {
            UserDTO myUser = getUserDetail();
            myUsername = myUser.getTheUserName();
            myChangePasswordProgressDialog.setMessage("Connecting with the backend service.");
            myChangePasswordProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            myChangePasswordProgressDialog.setIndeterminate(true);
            myChangePasswordProgressDialog.setCancelable(false);
            myChangePasswordProgressDialog.show();
        }
        @Override
        protected Object doInBackground(Object[] params) {
            IdentityAndAccessManagement myIAMApi = new IdentityAndAccessManagement();
            String myResponse = "false";
            try {
                myResponse = myIAMApi.sendChangePasswordRequest(Constant.CHANGE_PASSWORD_URL,myUsername,myOldPassword,myNewPassword);
            }
            catch (Exception e) {
                if(myResponse.equals("false")) {
                    WeAlertLogger myLogger = new WeAlertLogger();
                    myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Unable to change password. Please try again or contact your administrator.");
                    myLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                    myResponse = "false";
                }
                else if(myResponse.equals(null)){
                    WeAlertLogger myLogger = new WeAlertLogger();
                    myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Backend service is not responding at the moment. Please try again or contact your system administrator.");
                    myLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                    myResponse = null;
                }
            }
            return myResponse;
        }
        @Override
        protected void onPostExecute(Object o) {
            myChangePasswordProgressDialog.dismiss();
            String myResponse = o.toString();
            try {
                if (myResponse.equals("true")){
                    updateUserPasswordInDatabase(myNewPassword);
                    onBackPressed();
                    Toast.makeText(ChangePasswordActivity.this,"Password changed successfully.",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(ChangePasswordActivity.this,"Unable to change password. Please try again or contact your administrator.",Toast.LENGTH_SHORT).show();
                }
            }
            catch (Exception e) {
                if(myResponse.equals("false")) {
                    Toast.makeText(ChangePasswordActivity.this,"Unable to change password. Please try again or contact your administrator.",Toast.LENGTH_SHORT).show();
                }
                else if(myResponse.equals(null)){
                    Toast.makeText(ChangePasswordActivity.this,"Backend service is not responding at the moment. Please try again or contact your system administrator.",Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}
