package nl.weintegrate.wealert.app.dto;
/*
 *	@Author: Maira Tul Islam
 *
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *			01.002 Added attribute for alert status
 *
 */
import java.util.Date;


public class AlertDTO {
	
	// attributes
	
	private String theAlertId;
	private Date theTimestamp;
	private String theSeverity; // Critical, Major, Minor
	private String theAlertType; // Error, Warning, Info
	private String theAlertTitle;
	private String theAlertMessage;
	private String theHost;
	private String theEnvironmentName;
	private String theComponentName;
	private boolean theUnreadStatus;
	
	public String getTheAlertId() {
		return theAlertId;
	}
	public void setTheAlertId(String theAlertId) {
		this.theAlertId = theAlertId;
	}
	public Date getTheTimestamp() {
		return theTimestamp;
	}
	public void setTheTimestamp(Date theTimestamp) {
		this.theTimestamp = theTimestamp;
	}
	public String getTheSeverity() {
		return theSeverity;
	}
	public void setTheSeverity(String theSeverity) {
		this.theSeverity = theSeverity;
	}
	public String getTheAlertType() {
		return theAlertType;
	}
	public void setTheAlertType(String theAlertType) {
		this.theAlertType = theAlertType;
	}
	public String getTheAlertTitle() {
		return theAlertTitle;
	}
	public void setTheAlertTitle(String theAlertTitle) {
		this.theAlertTitle = theAlertTitle;
	}
	public String getTheAlertMessage() {
		return theAlertMessage;
	}
	public void setTheAlertMessage(String theAlertMessage) {
		this.theAlertMessage = theAlertMessage;
	}
	public String getTheHost() {
		return theHost;
	}
	public void setTheHost(String theHost) {
		this.theHost = theHost;
	}
	public String getTheComponentName() {
		return theComponentName;
	}
	public void setTheComponentName(String theComponentName) {
		this.theComponentName = theComponentName;
	}
	public boolean getTheUnreadStatus() {
		return theUnreadStatus;
	}
	public void setTheUnreadStatus(boolean theUnreadStatus) {
		this.theUnreadStatus = theUnreadStatus;
	}
	public void setTheEnvironmentName(String theEnvironmentName) { this.theEnvironmentName = theEnvironmentName; }
	public String getTheEnvironmentName() { return theEnvironmentName;}
	
}
