package nl.weintegrate.wealert.app.ui;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.regex.Pattern;

import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.api.ClientManagement;
import nl.weintegrate.wealert.app.dto.UserDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.IUserDAO;
import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

public class UserProfileActivity extends AppCompatActivity {
    private final String CLASS_NAME="UserProfileActivity";
    private EditText theUsername;
    private EditText theFirstName;
    private EditText theLastName;
    private EditText theEmail;
    boolean theEditProfileViewEnabled = false;
    private String theUserEmail;
    private String theUserLastName;
    private String theUserFirstName;
    private ImageButton theEditProfileButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //to set back button in toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        theUsername = (EditText) findViewById(R.id.editText_username);
        theFirstName = (EditText) findViewById(R.id.editText_firstName);
        theLastName = (EditText) findViewById(R.id.editText_lastName);
        theEmail = (EditText) findViewById(R.id.editText_email);
        theEditProfileButton = (ImageButton) findViewById(R.id.imageButton_editProfile);

        theUsername.setText(null);
        theFirstName.setText(null);
        theLastName.setText(null);
        theEmail.setText(null);

        //keyboard settings
        LinearLayout myProfileLayout = (LinearLayout) findViewById(R.id.content_user_profile);
        myProfileLayout.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View view, MotionEvent ev)
            {
                hideKeyboard(view);
                return false;
            }
        });

        //get user profile
        new GetUserOperation().execute();


        //set validations for text fields
        theFirstName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    theFirstName.setHint("Enter your first name");
                    validateFirstName();
                }
                else {
                    theFirstName.setHint("");
                }
            }
        });
        theFirstName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                theFirstName.setHint("Enter your first name");
                validateFirstName();
            }
        });
        theLastName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    theLastName.setHint("Enter your last name");
                    validateLastName();
                }
                else {
                    theLastName.setHint("");
                }
            }
        });
        theLastName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                theLastName.setHint("Enter your last name");
                validateLastName();
            }
        });
        theEmail.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    theEmail.setHint("Enter your email");
                    validateEmail();
                }
                else {
                    theEmail.setHint("");
                }
            }
        });
        theEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                theEmail.setHint("Enter your email");
                validateEmail();
            }
        });
    }
    /*
     *
     * Hides virtual keyboard
     *
     */
    protected void hideKeyboard(View view)
    {
        InputMethodManager myInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        myInputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
    /*
    *
    *  to validate first name field
    *
     */
    private void validateFirstName(){
        boolean isNamePatternMatched = Pattern.matches("^[\\p{Alpha}][\\p{Alpha}- ]*$",theFirstName.getText().toString());
        if(theFirstName.length()==0){
            theFirstName.setError(null);
        }
        else{
            if(isNamePatternMatched){
                theFirstName.setError(null);
            }
            else{
                theFirstName.setError("It must only consist of alphabets. Only hyphens are allowed, no other special characters are allowed.");
            }
        }
    }
    /*
    *
    *  to validate last name field
    *
     */
    private  void validateLastName(){
        boolean isNamePatternMatched = Pattern.matches("^[\\p{Alpha}][\\p{Alpha}- ]*$",theLastName.getText().toString());
        if(theLastName.length()==0){
            theLastName.setError(null);
        }
        else{
            if(isNamePatternMatched){
                theLastName.setError(null);
            }
            else{
                theLastName.setError("It must only consist of alphabets. Only hyphens are allowed, no other special characters are allowed.");
            }
        }
    }
    /*
    *
    *  to validate email field
    *
     */
    private void validateEmail(){
        boolean isEmailPatternMatched = Patterns.EMAIL_ADDRESS.matcher(theEmail.getText().toString()).matches();
        if(theEmail.length()==0){
            theEmail.setError(null);
        }
        else{
            if(isEmailPatternMatched){
                theEmail.setError(null);
            }
            else{
                theEmail.setError("1. It can be alpha numeric data. 2. Only full stops, hyphens ,underscores & one \"@\" must be allowed, no other special characters are allowed.");
            }
        }
    }
    @Override
    public void onBackPressed() {
        if(!theEditProfileViewEnabled) {
            Intent myIntentToStartAlertListActivity = new Intent(UserProfileActivity.this, AlertListActivity.class);
            myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(myIntentToStartAlertListActivity);
            this.finish();
        }
        else{
            theEditProfileViewEnabled = false;
            //set text in fields
            theFirstName.setText(theUserFirstName);
            theFirstName.setEnabled(false);
            theLastName.setText(theUserLastName);
            theLastName.setEnabled(false);
            theEmail.setText(theUserEmail);
            theEmail.setEnabled(false);
            //set edit profile button
            theEditProfileButton.setImageResource(android.R.drawable.ic_menu_edit);
        }
    }
    /*
   *
   *  to get user profile
   *
    */
    private UserDTO getUserDetail(){
        UserDTO myUserProfile = new UserDTO();
        DAOFactory mySQLLiteDaoFactory;
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(this);
            IUserDAO myUserDao = mySQLLiteDaoFactory.getUserDAO();
            myUserProfile = myUserDao.getUserProfile();
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,myWeAlertException.getMessage());
        }
        return myUserProfile;
    }
    /*
    *
    *  the on click handler for edit profile button
    *
     */
    public void onEditButtonClick(View view) {
        if(!theEditProfileViewEnabled) {
            theEditProfileButton.setImageResource(R.drawable.ic_done_white);
            theEditProfileViewEnabled = true;
            theFirstName.setEnabled(true);
            theLastName.setEnabled(true);
            theEmail.setEnabled(true);
            theFirstName.setHint("Enter your first name");
            theLastName.setHint("Enter your last name");
            theEmail.setHint("Enter your email");
        }
        else {
            if(theFirstName.getError()==null && theLastName.getError()==null && theEmail.getError()==null ){
                if(theLastName.length()>=1 && theEmail.length()!=0){
                    new UpdateUserOperation().execute();
                }
                else{
                    Toast.makeText(this,"Please enter required fields",Toast.LENGTH_SHORT).show();
                }
            }
            else
            {
                Toast.makeText(this,"Please enter valid data",Toast.LENGTH_SHORT).show();
            }
        }
    }


    private class GetUserOperation extends AsyncTask{
        ProgressDialog myGetUserProgressDialog =new ProgressDialog(UserProfileActivity.this, R.style.Mytheme);
        String myUsername;
        @Override
        protected void onPreExecute() {
            UserDTO myUser = getUserDetail();
            myUsername = myUser.getTheUserName();
            myGetUserProgressDialog.setMessage("Connecting with the backend service.");
            myGetUserProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            myGetUserProgressDialog.setIndeterminate(true);
            myGetUserProgressDialog.setCancelable(false);
            myGetUserProgressDialog.show();
        }

        @Override
        protected Object doInBackground(Object[] params) {
            ClientManagement myCMApi = new ClientManagement();
            JSONObject myGetUserJSONResponse = new JSONObject();
            try {
                myGetUserJSONResponse = myCMApi.sendGetUserRequest(Constant.GET_USER_URL, myUsername);


            }
            catch (Exception e) {
                WeAlertLogger myLogger = new WeAlertLogger();
                    myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Unable to connect to backend Service. Please try again or contact your administrator.");
                    myLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                myGetUserJSONResponse = null;
            }
            return myGetUserJSONResponse;
        }

        @Override
        protected void onPostExecute(Object aResultObject) {
            myGetUserProgressDialog.dismiss();
            try {
                JSONObject myResponse = (JSONObject) aResultObject;
                String myGetUserResponse = myResponse.getJSONObject("GetUserResponse").getJSONObject("Result").getString("ResponseCode");
                if (myGetUserResponse.equals("CM-N-0000")) {
                    JSONObject myJSONUser = myResponse.getJSONObject("GetUserResponse").getJSONObject("User");
                    JSONObject myUserEmail = (JSONObject)myJSONUser.getJSONArray("ContactDetail").get(1);
                    //make the user dto from json response payload
                    String myUsername = myJSONUser.getString("UserName");
                    theUserFirstName = myJSONUser.getJSONObject("PersonalDetail").getString("FirstName");
                    theUserLastName = myJSONUser.getJSONObject("PersonalDetail").getString("LastName");
                    theUserEmail = myUserEmail.getString("ChannelCode");
                    //set text in fields
                    theUsername.setText(myUsername);
                    theFirstName.setText(theUserFirstName);
                    theLastName.setText(theUserLastName);
                    theEmail.setText(theUserEmail);
                }
                else {
                    onBackPressed();
                    Toast.makeText(UserProfileActivity.this,"Unable to connect to backend Service. Please try again or contact your administrator.",Toast.LENGTH_SHORT).show();
                }
            }
            catch (Exception e){
                onBackPressed();
                Toast.makeText(UserProfileActivity.this,"Unable to connect to backend Service. Please try again or contact your administrator.",Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class UpdateUserOperation extends AsyncTask
    {
        ProgressDialog myGetUserProgressDialog =new ProgressDialog(UserProfileActivity.this, R.style.Mytheme);
        String myUserId;
        String myOrganizationId;
        String myUserFirstName;
        String myUserLastName;
        String myEmail;
        @Override
        protected void onPreExecute() {
            UserDTO myUser = getUserDetail();
            myUserId = myUser.getTheUserId();
            myOrganizationId = myUser.getTheOrganizationId();
            myUserFirstName = theFirstName.getText().toString();
            myUserLastName = theLastName.getText().toString();
            myEmail = theEmail.getText().toString();
            myGetUserProgressDialog.setMessage("Connecting with the backend service.");
            myGetUserProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            myGetUserProgressDialog.setIndeterminate(true);
            myGetUserProgressDialog.setCancelable(false);
            myGetUserProgressDialog.show();
        }

        @Override
        protected Object doInBackground(Object[] params) {
            ClientManagement myCMApi = new ClientManagement();
            boolean myUpdateUserJSONResponse = false;
            try {
                myUpdateUserJSONResponse = myCMApi.sendUpdateUserRequest(Constant.UPDATE_USER_URL, myUserId,myUserFirstName,myUserLastName,myEmail,myOrganizationId);
            }
            catch (Exception e) {
                WeAlertLogger myLogger = new WeAlertLogger();
                myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Unable to update profile. Please try again or contact your administrator.");
                myLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            }
            return myUpdateUserJSONResponse;
        }

        @Override
        protected void onPostExecute(Object aResultObject) {
            myGetUserProgressDialog.dismiss();
            try {
                boolean myResponse = (boolean)aResultObject;
                if(myResponse) {
                    theUserFirstName = myUserFirstName;
                    theUserLastName = myUserLastName;
                    theUserEmail = myEmail;
                    onBackPressed();
                    Toast.makeText(UserProfileActivity.this, "Profile updated successfully.", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(UserProfileActivity.this, "Unable to update profile. Please try again or contact your administrator.", Toast.LENGTH_SHORT).show();
                }
            }
            catch (Exception e){
                Toast.makeText(UserProfileActivity.this,"Unable to update profile. Please try again or contact your administrator.",Toast.LENGTH_SHORT).show();
            }
        }
    }
}
