package nl.weintegrate.wealert.app.persistence.Sqlite;
/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. Creating and Managing Sqlite Database
 *
 *	@Known Issues:
 *          1. ://TODO Implement Exception handling
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *		    01.002 Added create table query for user
 */
import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class SqliteDB {
    private static final String CLASS_NAME = "SqliteDB";
    private final Context theDBContext;
    private DatabaseHelper theDBHelper;
    private SQLiteDatabase theDB;

    private static final String DATABASE_NAME = "D_W_ALERT.db";
    private static final int DATABASE_VERSION = 1;

    private static final String CREATE_ALERT_TABLE =
            "CREATE TABLE IF NOT EXISTS T_ALERT (C_ALERT_ID text PRIMARY KEY, C_TIME_STAMP text, C_SEVERITY text, C_ALERT_TYPE text, C_ALERT_TITLE text, C_ALERT_MESSAGE text, C_HOST_NAME text, C_COMPONENT_NAME text, C_UNREAD numeric, C_ENVIRONMENT_NAME)";
    private static final String CREATE_USER_TABLE =
            "CREATE TABLE IF NOT EXISTS T_USER (C_USER_ID text PRIMARY KEY,C_USER_NAME text, C_USER_PASSWORD text, C_USER_STATUS text, C_USER_FIRST_NAME text, C_USER_LAST_NAME text, C_USER_MOBILE_NO text, C_USER_EMAIL text, C_USER_ROLE_ID text, C_ORGANIZATION_ID text, C_ORGANIZATION_NAME text, C_ORGANIZATION_DOMAIN text)";
    private static final String CREATE_SUBSCRIPTION_TABLE =
            "CREATE TABLE IF NOT EXISTS T_SUBSCRIPTION (C_SUBSCRIPTION_ID text,C_SUBSCRIPTION_NAME text, C_TOPIC_NAME text, C_USER_NAME text, C_PASSWORD text, C_BROKER_URL text, C_ENCRYPTION_KEY text)";


    public SqliteDB(Context aCurrentContext) {
        this.theDBContext = aCurrentContext;
        theDBHelper = new DatabaseHelper(theDBContext);
    }
    /*
     * Opens the database
     *
     */
    public SQLiteDatabase OpenDatabase() throws SQLException {
        theDB = theDBHelper.getWritableDatabase();

        return theDB;
    }

    /*
     * Closes the database
     *
     */
    public void CloseDatabase() {
        theDB.close();
        theDBHelper.close();
    }

    /*
    * Create Database Helper for managing SQLite Database
    *
    */
    private static class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(Context aDBContext) {
            super(aDBContext, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase aDB) {
            aDB.execSQL(CREATE_ALERT_TABLE);
            aDB.execSQL(CREATE_USER_TABLE);
            aDB.execSQL(CREATE_SUBSCRIPTION_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            //TODO:
        }

    }
}
