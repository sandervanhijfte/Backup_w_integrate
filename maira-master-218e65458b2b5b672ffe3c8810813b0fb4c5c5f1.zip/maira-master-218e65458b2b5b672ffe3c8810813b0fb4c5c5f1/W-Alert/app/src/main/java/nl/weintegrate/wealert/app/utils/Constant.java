package nl.weintegrate.wealert.app.utils;

/*
 *	@Author: Maham Hassan
 *	
 *	@Usage:  This class contains all the constants used for the app. 
 *	
 *	@KnownIssues: 
 *
 *
 *	@VersionHistory: 
 *
 *					01.001 (Initial Implementation)
 */

public class Constant 
{
    public static final int CONNECTION_TIMEOUT = 30000;
    public static final int ALERT_LIST_PAGE_SIZE = 20;
	public static final String WE_ALERT_LOG = "weAlertLog.txt";
	//public static final String AUTHENTICATE_USER_URL = "http://213.187.243.177:8293/identityandaccessmanagement_01/users/authenticate";
	public static final String AUTHENTICATE_USER_URL = "http://213.187.243.177:8283/identityandaccessmanagement_01/users/authenticate";
	public static final String ALERT_TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
    //public static final String UPDATE_USER_URL = "http://213.187.243.177:8293/clientmanagement_01/users";
    public static final String UPDATE_USER_URL = "http://213.187.243.177:8283/clientmanagement_01/users";
	//public static final String GET_USER_URL = "http://213.187.243.177:8293/clientmanagement_01/users";
	public static final String GET_USER_URL = "http://213.187.243.177:8283/clientmanagement_01/users";
    //public static final String REGISTER_DEVICE_URL = "http://213.187.243.177:8293/identityandaccessmanagement_01/users/registerdevice";
	public static final String REGISTER_DEVICE_URL = "http://213.187.243.177:8283/identityandaccessmanagement_01/users/registerdevice";
    //public static final String CHANGE_PASSWORD_URL = "http://213.187.243.177:8293/identityandaccessmanagement_01/users/changepassword";
    public static final String CHANGE_PASSWORD_URL = "http://213.187.243.177:8283/identityandaccessmanagement_01/users/changepassword";
	//Required for Alert Limit
	public static final long CLEANUP_INTERVAL = 30* 60 * 1000; // 30 minutes
	public static final int ALERT_LIMIT = 500; // 10 seconds
}