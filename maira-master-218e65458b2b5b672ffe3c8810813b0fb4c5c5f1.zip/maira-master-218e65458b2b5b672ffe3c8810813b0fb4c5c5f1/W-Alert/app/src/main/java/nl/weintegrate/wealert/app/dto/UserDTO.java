package nl.weintegrate.wealert.app.dto;
/*
 *	@Author: Maira Tul Islam
 *
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *
 */
public class UserDTO {

    // attributes
    private String theUserId;
    private String theUserName;
    private String theUserPassword;
    private String theUserStatus;
    private String theUserFirstName;
    private String theUserLastName;
    private String theUserMobileNo;
    private String theUserEmail;
    private String theUserRoleId;
    private String theOrganizationId;
    private String theOrganizationName;
    private String theOrganizationDomain;

    public String getTheUserId() {  return theUserId;   }
    public void setTheUserId(String theUserId) {    this.theUserId = theUserId; }
    public String getTheUserStatus() {  return theUserStatus;   }
    public void setTheUserStatus(String theUserStatus) {    this.theUserStatus = theUserStatus; }
    public String getTheUserName() {    return theUserName; }
    public void setTheUserName(String theUserName) {    this.theUserName = theUserName; }
    public String getTheUserPassword() {    return theUserPassword; }
    public void setTheUserPassword(String theUserPassword) {    this.theUserPassword = theUserPassword; }
    public String getTheUserFirstName() {   return theUserFirstName;    }
    public void setTheUserFirstName(String theUserFirstName) {  this.theUserFirstName = theUserFirstName;   }
    public String getTheUserLastName() {    return theUserLastName; }
    public void setTheUserLastName(String theUserLastName) { this.theUserLastName = theUserLastName; }
    public String getTheUserMobileNo() { return theUserMobileNo;    }
    public void setTheUserMobileNo(String theUserMobileNo) {    this.theUserMobileNo = theUserMobileNo; }
    public String getTheUserEmail() {   return theUserEmail;    }
    public void setTheUserEmail(String theUserEmail) {  this.theUserEmail = theUserEmail;   }
    public String getTheOrganizationId() {  return theOrganizationId;   }
    public void setTheOrganizationId(String theOrganizationId) {    this.theOrganizationId = theOrganizationId; }
    public String getTheOrganizationName() {    return theOrganizationName; }
    public void setTheOrganizationName(String theOrganizationName) {    this.theOrganizationName = theOrganizationName; }
    public String getTheOrganizationDomain() {  return theOrganizationDomain;   }
    public void setTheOrganizationDomain(String theOrganizationDomain) {    this.theOrganizationDomain = theOrganizationDomain; }
    public String getTheUserRoleId() {  return theUserRoleId;   }
    public void setTheUserRoleId(String theUserRoleId) {    this.theUserRoleId = theUserRoleId; }
}
