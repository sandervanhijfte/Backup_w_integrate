package nl.weintegrate.wealert.app.ui;
/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. Custom adapter for alerts to use in alert list
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *		    01.002 added addMoreItems function
 *
 *
 */

import android.app.Activity;
import android.content.Context;
import android.support.v7.app.AlertDialog;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.R.drawable;
import nl.weintegrate.wealert.app.dto.AlertDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.IAlertDAO;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;


public class AlertListAdapter extends BaseAdapter {
    private final String CLASS_NAME= "AlertListAdapter";
    private ArrayList<AlertDTO> theAlertList;
    private Context theCurrentContext;
    private boolean theCheckboxVisibility, theSelectionForAllCheckboxes;
    ArrayList<String> theSelectedItemsList = new ArrayList<String>();
    ArrayList<Integer> theUncheckedItemPositionList = new ArrayList<Integer>();
    ArrayList<Integer> theCheckedItemPositionList = new ArrayList<Integer>();
    public AlertListAdapter(Context aCurrentContext, ArrayList<AlertDTO> anAlertList, boolean anAlertCheckboxVisibility)
    {
        this.theCurrentContext = aCurrentContext;
        this.theAlertList = anAlertList;
        this.theCheckboxVisibility = anAlertCheckboxVisibility;
        updateSelectedAlertCount(theSelectedItemsList.size());
    }
    /*
    *
    *  to select all loaded alerts
    *
     */
    public void selectAllLoadedAlerts(boolean selectAllCheckboxes)
    {
        theSelectionForAllCheckboxes = selectAllCheckboxes;
        if(selectAllCheckboxes) {
            theCheckedItemPositionList.clear();
            theUncheckedItemPositionList.clear();
            theSelectedItemsList.clear();
            for(int i=0 ; i<getCount() ; i++)
            {
                theSelectedItemsList.add(theAlertList.get(i).getTheAlertId());
                updateSelectedAlertCount(theSelectedItemsList.size());
            }
        }
        else {
            theCheckedItemPositionList.clear();
            theSelectedItemsList.clear();
            updateSelectedAlertCount(theSelectedItemsList.size());
        }
        notifyDataSetChanged();
    }
    public void updateSelectedAlertCount(int aNumberOfSelectedAlerts)
    {
        TextView mySelectedAlertCountTextView = (TextView) ((Activity)theCurrentContext).findViewById(R.id.textView_selectedAlertCount);
        mySelectedAlertCountTextView.setText(Integer.toString(aNumberOfSelectedAlerts));
    }
    /*
    *
    *  to update status of alert
    *
     */
    public void updateAlertStatus(String anAlertId)
    {
        for(int i=0 ; i<getCount() ; i++)
        {
            AlertDTO myAlertToUpdate = theAlertList.get(i);
            if(myAlertToUpdate.getTheAlertId().equals(anAlertId)) {
                myAlertToUpdate.setTheUnreadStatus(false);
                theAlertList.set(i, myAlertToUpdate);
                notifyDataSetChanged();
            }
        }
    }
    /*
    *
    *  to add alert at top of list
    *
     */
    public void addNewAlerts(AlertDTO anAlertDTO)
    {
            theAlertList.add(0, anAlertDTO);
            notifyDataSetChanged();
    }
    /*
    *
    *  to add more items in the list retrieved from database after scrolling down
    *
     */
    public void addMoreItems(ArrayList<AlertDTO> anAlertDTOList) {
        for (int i = 0; i <= anAlertDTOList.size()-1; i++) {
            theAlertList.add(anAlertDTOList.get(i));
            if(theSelectionForAllCheckboxes) {
                theSelectedItemsList.add(anAlertDTOList.get(i).getTheAlertId());
                updateSelectedAlertCount(theSelectedItemsList.size());
            }
        }
        notifyDataSetChanged();
    }
    @Override
    public int getCount() {
        return theAlertList.size();
    }
    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View view, ViewGroup viewGroup) {
        String myAlertTitle;
        String myTimestamp;
        String mySeverity;
        String myComponent;
        final String myAlertID;
        boolean myAlertUnreadStatus;
        AlertDTO myAlertDTO;
        LinearLayout myAlertItem;
        ImageView mySeverityImageView;
        final TextView myAlertIdTextView;
        TextView myAlertTextView;
        TextView myAlertTimestampView;
        LayoutInflater myListItemLayoutInflater;
        ImageButton myDeleteAlertButton;
        final CheckBox myAlertSelectionCheckbox;
        String myAlertDate;
        String myAlertTime;


        // inflate the layout for each item of listView
        myListItemLayoutInflater = (LayoutInflater) theCurrentContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = myListItemLayoutInflater.inflate(R.layout.listview_each_item, null);
        //to get element at current position
        myAlertDTO = theAlertList.get(position);

        myAlertID = myAlertDTO.getTheAlertId();
        //setting checkbox for alert selection

        myAlertSelectionCheckbox = (CheckBox) view.findViewById(R.id.checkBox_alertItem);
        if(theCheckboxVisibility == true && theSelectionForAllCheckboxes == false)
        {
            myAlertSelectionCheckbox.setVisibility(View.VISIBLE);
            myAlertSelectionCheckbox.setClickable(true);
            myAlertSelectionCheckbox.isFocusable();

            if(theCheckedItemPositionList.size()!=0)
            {
                if(theCheckedItemPositionList.contains(position))
                {
                    myAlertSelectionCheckbox.setChecked(true);
                }
                else
                {
                    myAlertSelectionCheckbox.setChecked(false);
                }
            }
            else
            {
                myAlertSelectionCheckbox.setChecked(false);
            }


        }
        else if(theSelectionForAllCheckboxes == true && theCheckboxVisibility == true)
        {
            myAlertSelectionCheckbox.setVisibility(View.VISIBLE);
            myAlertSelectionCheckbox.setClickable(true);
            myAlertSelectionCheckbox.isFocusable();
            if(theUncheckedItemPositionList.size()!=0)
            {
                if(theUncheckedItemPositionList.contains(position))
                {
                    myAlertSelectionCheckbox.setChecked(false);
                }
                else
                {
                    myAlertSelectionCheckbox.setChecked(true);
                }
            }
            else {
                myAlertSelectionCheckbox.setChecked(true);
            }
        }
        else
        {
            myAlertSelectionCheckbox.setVisibility(View.GONE);
            myAlertSelectionCheckbox.setClickable(false);
        }
        //setting color for the unread/read alerts
        myAlertUnreadStatus = myAlertDTO.getTheUnreadStatus();
        myAlertItem = (LinearLayout) view.findViewById(R.id.content_alert_item);
        if(myAlertUnreadStatus == true)
        {
            myAlertItem.setBackgroundColor( theCurrentContext.getResources().getColor(R.color.colorWhite));
        }
        else if(myAlertUnreadStatus == false)
        {
            myAlertItem.setBackgroundColor( theCurrentContext.getResources().getColor(R.color.colorLightGrey));
        }

        //setting the image for severity
        if(myAlertDTO.getTheSeverity()!=null) {

            mySeverity = myAlertDTO.getTheSeverity();
            mySeverityImageView = (ImageView) view.findViewById(R.id.imageView_severity);
            if (mySeverity.contains("Low")) {
                mySeverityImageView.setImageDrawable(theCurrentContext.getResources().getDrawable(drawable.low));
            } else if (mySeverity.contains("High")) {
                mySeverityImageView.setImageDrawable(theCurrentContext.getResources().getDrawable(drawable.high));
            } else {
                mySeverityImageView.setImageDrawable(theCurrentContext.getResources().getDrawable(drawable.medium));
            }
        }
        //setting alert detail which will appear in the list
        //assigning alert detail values
            myAlertIdTextView = (TextView) view.findViewById(R.id.textView_alertId);
            myAlertIdTextView.setText(myAlertID);
        if(myAlertDTO.getTheAlertTitle()!=null && myAlertDTO.getTheAlertTitle()!=null) {
            myAlertTitle = myAlertDTO.getTheAlertTitle();
            myComponent = myAlertDTO.getTheComponentName();
            myAlertTextView = (TextView) view.findViewById(R.id.textView_alert);
            myAlertTextView.setText(Html.fromHtml("<br/><b>" + myAlertTitle + "</b><br/>" + "Component Name: " + myComponent + "<br/>"));
        }
        if(myAlertDTO.getTheTimestamp()!=null) {
            myTimestamp = new SimpleDateFormat("yyy-MM-dd HH:mm").format(myAlertDTO.getTheTimestamp());
            myAlertTimestampView = (TextView) view.findViewById(R.id.textView_timestamp);
            String[] myTempDateTime = myTimestamp.split("\\s");
            myAlertDate = myTempDateTime[0];
            myAlertTime = myTempDateTime[1];
            myAlertTimestampView.setText(myAlertTime + "\n" + myAlertDate);
        }

        //setting the delete button for each list item
        myDeleteAlertButton = (ImageButton) view.findViewById(R.id.imageButton_delete);
        final View finalView = view;
        //on click listener of delete button
        myDeleteAlertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog myDeleteConfirmationDialog = new AlertDialog.Builder(theCurrentContext, R.style.Mytheme).create();
                LayoutInflater myLayoutInflater = (LayoutInflater) theCurrentContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View myDeleteDialogView = myLayoutInflater.inflate(R.layout.layout_delete_dialog,null);
                myDeleteConfirmationDialog.setView(myDeleteDialogView);
                myDeleteConfirmationDialog.setCancelable(true);
                Button myPositiveButton = (Button) myDeleteDialogView.findViewById(R.id.dialog_btn_yes);
                Button myNegativeButton = (Button) myDeleteDialogView.findViewById(R.id.dialog_btn_cancel_delete);


                myPositiveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        TextView myAlertId = (TextView) finalView.findViewById(R.id.textView_alertId);
                        deleteAlertFromDatabase(myAlertId.getText().toString());
                        theAlertList.remove(position);
                        notifyDataSetChanged();
                        myDeleteConfirmationDialog.dismiss();
                    }
                });
                myNegativeButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myDeleteConfirmationDialog.dismiss();
                    }
                });
                myDeleteConfirmationDialog.setMessage("Are you sure want to delete?");
                myDeleteConfirmationDialog.show();
            }
        });

        //on click listener for getting the selected alerts
        myAlertSelectionCheckbox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String myAlertId = myAlertIdTextView.getText().toString();
                if(myAlertSelectionCheckbox.isChecked())
                {

                    theSelectedItemsList.add(myAlertId);
                    updateSelectedAlertCount(theSelectedItemsList.size());
                    theCheckedItemPositionList.add(position);
                }
                else
                {
                    theSelectedItemsList.remove(myAlertId);
                    updateSelectedAlertCount(theSelectedItemsList.size());
                    theUncheckedItemPositionList.add(position);
                }
            }
        });
        return view;
    }
    /*
    *
    * to delete an alert from database
    *
    */
    private void deleteAlertFromDatabase(String anAlertId)
    {
        try {

            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(theCurrentContext);
            IAlertDAO mySqliteAlertDao = mySqliteDaoFactory.getAlertDAO();
            mySqliteAlertDao.deleteAlert(anAlertId);
        }
        catch (WeAlertException e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,e);
            Toast.makeText(theCurrentContext,"Unable to delete the alert. Please try again.",Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,e);
            Toast.makeText(theCurrentContext,"Unable to delete the alert. Please try again.",Toast.LENGTH_LONG).show();
        }
    }
    /*
    *
    * to get selected alerts
    *
     */
    public ArrayList<String> getTheSelectedItemsList() {

        return theSelectedItemsList;
    }
}
