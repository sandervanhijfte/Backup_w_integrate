package nl.weintegrate.wealert.app.persistence;

/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. Interface for all functions used for managing alerts database

 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *			01.002 Added getTotalNumberOfAlerts function
 *		    01.003 Added updateAlertStatusToRead and searchAlert function
 */


//TODO: Review naming and commenting

import java.util.ArrayList;

import nl.weintegrate.wealert.app.dto.AlertDTO;
import nl.weintegrate.wealert.app.utils.WeAlertException;

public interface IAlertDAO {
	
	public void insertAlert(AlertDTO anAlertDTO) throws WeAlertException;
	public AlertDTO getAlert(String anAlertId) throws WeAlertException;
	public ArrayList<AlertDTO> listAlert() throws WeAlertException;
	public void deleteAlert(String anAlertId) throws WeAlertException;
	public void cleanupDatabase(int aNumberOfAlertsToDelete) throws WeAlertException;
	public int getTotalNumberOfAlerts() throws WeAlertException;
	public void updateAlertStatusToRead(String anAlertId) throws WeAlertException;
    public ArrayList<AlertDTO> searchAlert(String aSearchValue) throws WeAlertException;
	public ArrayList<AlertDTO> searchAlertToGetFirstPageResult(String aSearchValue) throws WeAlertException;
	public ArrayList<AlertDTO> searchAlertToGetCurrentPageResult(String aSearchValue , int aStartIndex) throws WeAlertException;
	public int getUnreadMessageCount() throws WeAlertException;
	public ArrayList<AlertDTO> listAlertForOnePage(int aStartIndex) throws WeAlertException;
    public ArrayList<AlertDTO> listAlertForFirstPage() throws WeAlertException;
    public int getRowId(String anAlertId) throws WeAlertException;
	public boolean checkIfAlertExists(String anAlertId) throws WeAlertException;
	public AlertDTO getNewAlert() throws WeAlertException;

}
