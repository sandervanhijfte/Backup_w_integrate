package nl.weintegrate.wealert.app.utils;

import android.util.Log;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

/*
 *	@Author: Maham Hassan
 *
 *	@Usage:  This is a logger template class
 *
 *	@KnownIssues:
 *
 *	@VersionHistory:
 *
 *					01.001 (Initial Implementation)
 	*				01.002 (Added logStackTrace function)
 */

public class WeAlertLogger {
	
	public void logMessage(Long aThreadId, String aTag,String aLogMessage) {

		FileOutputStream myOutputStreamForLogging = null;
		PrintWriter myLogPrintWriter = null;
		BufferedWriter myLogBufferedWriter = null;
		
	    try {

			File myAndroidRoot = android.os.Environment.getExternalStorageDirectory(); 
			File myLogDir = new File (myAndroidRoot.getAbsolutePath() + "/download");
		    myLogDir.mkdirs();
		    File myLogFile = new File(myLogDir, Constant.WE_ALERT_LOG);
		    
		    // Current Time
		    
			SimpleDateFormat myLogDateFormat = new SimpleDateFormat(Constant.ALERT_TIMESTAMP_FORMAT);
			String myCurrentTime = myLogDateFormat.format(new Date(System.currentTimeMillis())); 
			String myFormattedLogMessage = aThreadId + " , " + myCurrentTime+" , " + aTag + " , "+aLogMessage;
	    
		    if (myLogFile.exists()) {
		    	
		    	myLogBufferedWriter = new BufferedWriter(new FileWriter(myLogFile, true)); 
		        myLogBufferedWriter.append(myFormattedLogMessage);
		        myLogBufferedWriter.newLine();
		        
		    } 
		    else {
		        
		    	myOutputStreamForLogging = new FileOutputStream(myLogFile);
		        myLogPrintWriter = new PrintWriter(myOutputStreamForLogging);
		        myLogPrintWriter.println(myFormattedLogMessage);
		        
		    }
		} 
	    catch (FileNotFoundException e) {
	        e.printStackTrace();
	        Log.i("WeAlertLogger", "******* File not found. Did you" +
	                " add a WRITE_EXTERNAL_STORAGE permission to the   manifest?");
		} 
	    catch (Exception e) {
		
	    	e.printStackTrace();
		    
	    }  
	    finally {
		    	
	        try {
				if (myLogPrintWriter != null) myLogPrintWriter.flush();
				if (myLogPrintWriter != null) myLogPrintWriter.close();
				if (myOutputStreamForLogging != null) myOutputStreamForLogging.close();
				if (myLogBufferedWriter != null) myLogBufferedWriter.close();
			} 
	        catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    	
	    } 
	}
    public void logStackTrace(Long aThreadId, String aTag,Exception e) {

        FileOutputStream myOutputStreamForLogging = null;
        PrintWriter myLogPrintWriter = null;
        BufferedWriter myLogBufferedWriter = null;

        try {

            File myAndroidRoot = android.os.Environment.getExternalStorageDirectory();
            File myLogDir = new File (myAndroidRoot.getAbsolutePath() + "/download");
            myLogDir.mkdirs();
            File myLogFile = new File(myLogDir, Constant.WE_ALERT_LOG);

            // Current Time

            SimpleDateFormat myLogDateFormat = new SimpleDateFormat(Constant.ALERT_TIMESTAMP_FORMAT);
            String myCurrentTime = myLogDateFormat.format(new Date(System.currentTimeMillis()));
            String myFormattedLogMessage = aThreadId + " , " + myCurrentTime+" , " + aTag + " , " ;

            if (myLogFile.exists()) {
                myLogPrintWriter = new PrintWriter(new FileWriter(myLogFile,true));
                myLogPrintWriter.append(myFormattedLogMessage);
                e.printStackTrace(myLogPrintWriter);

            }
            else {

                myOutputStreamForLogging = new FileOutputStream(myLogFile);
                myLogPrintWriter = new PrintWriter(myOutputStreamForLogging);
                myLogPrintWriter.println(myFormattedLogMessage);
                e.printStackTrace(myLogPrintWriter);

            }
        }
        catch (FileNotFoundException ex) {
            ex.printStackTrace();
            Log.i("WeAlertLogger", "******* File not found. Did you" +
                    " add a WRITE_EXTERNAL_STORAGE permission to the   manifest?");
        }
        catch (Exception ex) {

            ex.printStackTrace();

        }
        finally {

            try {
                if (myLogPrintWriter != null) myLogPrintWriter.flush();
                if (myLogPrintWriter != null) myLogPrintWriter.close();
                if (myOutputStreamForLogging != null) myOutputStreamForLogging.close();
                if (myLogBufferedWriter != null) myLogBufferedWriter.close();
            }
            catch (Exception ex) {
                // TODO Auto-generated catch block
                ex.printStackTrace();
            }

        }
    }


}
