package nl.weintegrate.wealert.app.api;
/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. To make the the identity and access management api requests
 *  @Known Issues:
 *          1. ://TODO add change password operation
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *
 *
 */

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.UUID;

import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

public class IdentityAndAccessManagement{
    private final String CLASS_NAME = "IdentityAndAccessMangement";
    /*
    *
    * to make the register device json request payload
    *
     */
    private String makeRegisterDeviceJSONRequestPayload(String aDomain, String aUsernameWithoutDomain){
        String myRegisterDeviceRequest = "{\n" +
                "  \"RegisterDeviceRequest\": {\n" +
                "    \"Header\": {\n" +
                "      \"CMMHeader\": { \"CorrelationId\": \""+UUID.randomUUID().toString()+"\" }\n" +
                "    },\n" +
                "    \"ClientContext\": { \"UserName\": \"admin@"+aDomain+"\" },\n" +
                "    \"UserName\": \""+aUsernameWithoutDomain+"\"\n" +
                "  }\n" +
                "}";
        return  myRegisterDeviceRequest;
    }
    /*
    *
    * to make the user authentication json request payload
    *
     */
    private String makeUserAuthenticationJSONRequestPayload(String aUsername, String aUsernameWithoutDomain, String aPassword) {

        String myUserAuthenticationRequest = "{\"AuthenticateRequest\": {\n" +
                "   \"Header\": {\"CMMHeader\": {\"CorrelationId\": \""+UUID.randomUUID().toString()+"\"}},\n" +
                "   \"ClientContext\": {\"UserName\": \""+aUsername+"\"},\n" +
                "   \"UserName\": \""+aUsernameWithoutDomain+"\",\n" +
                "   \"UserPassword\": \""+aPassword+"\"\n" +
                "}}";
        return myUserAuthenticationRequest;
    }
    private String makeChangePasswordJSONRequestPayload(String aUsername,String aUsernameWithoutDomain, String anOldPassword, String aNewPassword)
    {
        String myChangePasswordRequest = "{\n" +
                "  \"ChangePasswordRequest\": {\n" +
                "    \"Header\": {\n" +
                "      \"CMMHeader\": { \"CorrelationId\": \""+ UUID.randomUUID().toString()+"\" }\n" +
                "    },\n" +
                "    \"ClientContext\": { \"UserName\": \""+aUsername +"\" },\n" +
                "    \"UserName\": \""+aUsernameWithoutDomain+"\",\n" +
                "    \"UserOldPassword\": \""+anOldPassword+"\",\n" +
                "    \"UserPassword\": \""+ aNewPassword+"\"\n" +
                "  }\n" +
                "}";
        return myChangePasswordRequest;
    }
    /*
    *
    *  to send api call for user authentication and get response
    *
     */

    public String sendAuthenticateRequest(String aPath, String aUsername, String aPassword) throws WeAlertException {
        String myUsername = aUsername;
        String myAuthentication = "false";
        HttpURLConnection myConnection = null;
        try {
            //get JSON payload
            //split username
            String[] myTempUsernameArray = myUsername.split("[@]");
            String myUsernameWithoutDomain = myTempUsernameArray[0];
            //making the JSON request payload
            String myUserAuthenticationPayload = makeUserAuthenticationJSONRequestPayload(myUsername,myUsernameWithoutDomain,aPassword);
            // Initialisation of connection to the API
            URL myUrl = new URL(aPath);
            myConnection = (HttpURLConnection) myUrl.openConnection();
            //Setting Connection request parameters
            myConnection.setConnectTimeout(Constant.CONNECTION_TIMEOUT);
            myConnection.setRequestMethod("POST");
            myConnection.setRequestProperty("Content-Type", "application/json");
            myConnection.setRequestProperty("Accept", "application/json");
            myConnection.setRequestProperty("Content-Length", Integer.toString(myUserAuthenticationPayload.getBytes().length));


            myConnection.setUseCaches(false);
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            // Writing the request to the stream writer
            DataOutputStream myStreamWriter = new DataOutputStream(myConnection.getOutputStream());
            myStreamWriter.writeBytes(myUserAuthenticationPayload);
            myStreamWriter.flush();
            myStreamWriter.close();

            // Check if the API returns HTTP code 200 OK
            if (myConnection.getResponseCode() == 200) {

                // Read the response payload returned from the API
                InputStream myInputStreamWriter = myConnection.getInputStream();
                BufferedReader myResponseReader = new BufferedReader(new InputStreamReader(myInputStreamWriter));
                String myResponseLine;
                StringBuffer myResponse = new StringBuffer();

                while ((myResponseLine = myResponseReader.readLine()) != null) {
                    myResponse.append(myResponseLine);
                    myResponse.append('\r');
                }

                myResponseReader.close();
                myInputStreamWriter.close();

                JSONObject myResponseJsonObject = new JSONObject(myResponse.toString());

                // Get the authentication status from the response
                String myResponseCode = myResponseJsonObject.getJSONObject("AuthenticateResponse").getJSONObject("Result").getString("ResponseCode");
                if(myResponseCode.equals("IAM-N-0000"))
                {
                    myAuthentication =  myResponseJsonObject.getJSONObject("AuthenticateResponse").getString("AuthenticationStatus");
                }
                else if(myResponseCode.equals("IAM-E-9999"))
                {
                    myAuthentication = "false";
                }
                else
                {
                    myAuthentication = "false";
                }
            }
        }
        catch(java.net.SocketTimeoutException e)
        {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myAuthentication = null;
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Connection timeout while making authenticate user call");
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myAuthentication = null;
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Error while making AuthenticateUser call");
            throw myWeAlertException;
        } finally {
            // clean up initialised resources
            if (myConnection != null) {
                myConnection.disconnect();
            }
        }

        return myAuthentication;

    }

    public String sendRegisterDeviceRequest(String aPath,String aUsername) throws WeAlertException
    {
        String myRegistration = "false";
        HttpURLConnection myConnection = null;
        try {
            //get JSON payload
            //split username
            String[] myTempUsernameArray = aUsername.split("[@]");
            String myUsernameWithoutDomain = myTempUsernameArray[0];
            String myDomain = myTempUsernameArray[1];
            //making the JSON request payload
            String myRegisterDevicePayload = makeRegisterDeviceJSONRequestPayload(myDomain,myUsernameWithoutDomain);
            // Initialisation of connection to the API
            URL myUrl = new URL(aPath);
            myConnection = (HttpURLConnection) myUrl.openConnection();
            //Setting Connection request parameters
            myConnection.setConnectTimeout(Constant.CONNECTION_TIMEOUT);
            myConnection.setRequestMethod("POST");
            myConnection.setRequestProperty("Content-Type", "application/json");
            myConnection.setRequestProperty("Accept", "application/json");
            myConnection.setRequestProperty("Content-Length", Integer.toString(myRegisterDevicePayload.getBytes().length));


            myConnection.setUseCaches(false);
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            // Writing the request to the stream writer
            DataOutputStream myStreamWriter = new DataOutputStream(myConnection.getOutputStream());
            myStreamWriter.writeBytes(myRegisterDevicePayload);
            myStreamWriter.flush();
            myStreamWriter.close();

            // Check if the API returns HTTP code 200 OK
            if (myConnection.getResponseCode() == 200) {

                // Read the response payload returned from the API
                InputStream myInputStreamWriter = myConnection.getInputStream();
                BufferedReader myResponseReader = new BufferedReader(new InputStreamReader(myInputStreamWriter));
                String myResponseLine;
                StringBuffer myResponse = new StringBuffer();

                while ((myResponseLine = myResponseReader.readLine()) != null) {
                    myResponse.append(myResponseLine);
                    myResponse.append('\r');
                }

                myResponseReader.close();
                myInputStreamWriter.close();

                JSONObject myResponseJsonObject = new JSONObject(myResponse.toString());

                // Get the registration status from the response
                String myResponseCode = myResponseJsonObject.getJSONObject("RegisterDeviceResponse").getJSONObject("Result").getString("ResponseCode");
                if(myResponseCode.equals("IAM-N-0000"))
                {
                    myRegistration =  myResponseJsonObject.getJSONObject("RegisterDeviceResponse").getString("RegistrationStatus");
                }
                else if(myResponseCode.equals("IAM-E-9999"))
                {
                    myRegistration = "false";
                }
                else
                {
                    myRegistration = "false";
                }
            }
        }
        catch(java.net.SocketTimeoutException e)
        {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myRegistration = null;
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Connection Timeout while making Register Device call");
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myRegistration = null;
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Error while making RegisterDevice call");
            throw myWeAlertException;
        } finally {
            // clean up initialised resources
            if (myConnection != null) {
                myConnection.disconnect();
            }
        }

        return myRegistration;

    }
    public String sendChangePasswordRequest(String aPath, String aUsername, String anOldPassword, String aNewPassword) throws WeAlertException
    {
        String myPasswordChangeResponse = "false";
        HttpURLConnection myConnection = null;
        try {
            String[] myTempUsernameArray = aUsername.split("[@]");
            String myUsernameWithoutDomain = myTempUsernameArray[0];
            String myChangePasswordPayload = makeChangePasswordJSONRequestPayload(aUsername,myUsernameWithoutDomain,anOldPassword,aNewPassword);
            URL myUrl = new URL(aPath);
            myConnection = (HttpURLConnection) myUrl.openConnection();
            myConnection.setConnectTimeout(Constant.CONNECTION_TIMEOUT);
            myConnection.setRequestMethod("PUT");
            myConnection.setRequestProperty("Content-Type", "application/json");
            myConnection.setRequestProperty("Accept", "application/json");
            myConnection.setRequestProperty("Content-Length", Integer.toString(myChangePasswordPayload.getBytes().length));


            myConnection.setUseCaches(false);
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            DataOutputStream myStreamWriter = new DataOutputStream(myConnection.getOutputStream());
            myStreamWriter.writeBytes(myChangePasswordPayload);
            myStreamWriter.flush();
            myStreamWriter.close();
            int myhttpresponse = myConnection.getResponseCode();
            if (myConnection.getResponseCode() == 200) {
                InputStream myInputStreamWriter = myConnection.getInputStream();
                BufferedReader myResponseReader = new BufferedReader(new InputStreamReader(myInputStreamWriter));
                String myResponseLine;
                StringBuffer myResponse = new StringBuffer();
                while ((myResponseLine = myResponseReader.readLine()) != null) {
                    myResponse.append(myResponseLine);
                    myResponse.append('\r');
                }
                myResponseReader.close();
                myInputStreamWriter.close();
                JSONObject myResponseJsonObject = new JSONObject(myResponse.toString());
                String myResponseCode = myResponseJsonObject.getJSONObject("ChangePasswordResponse").getJSONObject("Result").getString("ResponseCode");
                if(myResponseCode.equals("IAM-N-0000"))
                {
                    myPasswordChangeResponse =  "true";
                }
                else if(myResponseCode.equals("IAM-E-9999"))
                {
                    myPasswordChangeResponse = "false";
                }
                else
                {
                    myPasswordChangeResponse = "false";
                }
            }
        }
        catch(SocketTimeoutException e)
        {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myPasswordChangeResponse = "null";
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Connection Timeout while making Change Password call");
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myPasswordChangeResponse = "false";
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Error while making Change Password call");
            throw myWeAlertException;
        } finally {
            if (myConnection != null) {
                myConnection.disconnect();
            }
        }
        return myPasswordChangeResponse;
    }
}
