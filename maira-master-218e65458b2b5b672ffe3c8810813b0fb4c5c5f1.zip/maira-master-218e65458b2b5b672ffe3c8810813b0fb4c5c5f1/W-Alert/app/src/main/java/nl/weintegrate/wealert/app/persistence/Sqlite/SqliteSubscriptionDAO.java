package nl.weintegrate.wealert.app.persistence.Sqlite;




import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import nl.weintegrate.wealert.app.dto.SubscriptionDTO;
import nl.weintegrate.wealert.app.persistence.ISubscriptionDAO;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

public class SqliteSubscriptionDAO implements ISubscriptionDAO {
    private String CLASS_NAME = "SqliteSubscriptionDAO";
	private static final String DATABASE_TABLE = "T_SUBSCRIPTION";
	private SqliteDB theSqliteDB;

    public SqliteSubscriptionDAO(SqliteDB aSqliteDB){
        this.theSqliteDB = aSqliteDB;
    }

    /*
     *
     * @Usage:
     *      1. To save the user profile in the user table of database
     * @params:
     *      1. SubscriptionDTO : the SubscriptionDTO which is saved to the database
     *
     */
    @Override
    public boolean insertSubscriptionDetail(SubscriptionDTO aSubscriptionDto) throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        ContentValues myNewSubscriptionValues = null;
        try {
            myWeAlertDB = theSqliteDB.OpenDatabase();

            myNewSubscriptionValues = new ContentValues();

                if (aSubscriptionDto.getSubscriptionId() != null) {
                    myNewSubscriptionValues.put("C_SUBSCRIPTION_ID", aSubscriptionDto.getSubscriptionId());
                }
                if (aSubscriptionDto.getSubscriptionName() != null) {
                    myNewSubscriptionValues.put("C_SUBSCRIPTION_NAME", aSubscriptionDto.getSubscriptionName());
                }
                if (aSubscriptionDto.getTopicName() != null) {
                    myNewSubscriptionValues.put("C_TOPIC_NAME", aSubscriptionDto.getTopicName());
                }
                if (aSubscriptionDto.getBrokerUrl() != null) {
                    myNewSubscriptionValues.put("C_BROKER_URL", aSubscriptionDto.getBrokerUrl());
                }
                if (aSubscriptionDto.getUserName() != null) {
                    myNewSubscriptionValues.put("C_USER_NAME", aSubscriptionDto.getUserName());
                }
            if (aSubscriptionDto.getPassword() != null) {
                myNewSubscriptionValues.put("C_PASSWORD", aSubscriptionDto.getPassword());
            }
            if (aSubscriptionDto.getEncryptionKey() != null) {
                myNewSubscriptionValues.put("C_ENCRYPTION_KEY", aSubscriptionDto.getEncryptionKey());
            }
            Long myRowCount=myWeAlertDB.insertOrThrow(DATABASE_TABLE, null, myNewSubscriptionValues);
            return myRowCount != -1;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Error while adding the user profile because a user profile already exists in the database");
            throw myWeAlertException;
        }
        finally {
            myNewSubscriptionValues.clear();
            theSqliteDB.CloseDatabase();
        }
    }

    @Override
    public SubscriptionDTO getSubscriptionDetail() throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        SubscriptionDTO mySubscription = new SubscriptionDTO();
        try {
            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT * FROM T_SUBSCRIPTION",null);
            myCursor.moveToFirst();
            mySubscription.setTopicName(myCursor.getString(2));
            mySubscription.setUserName(myCursor.getString(3));
            mySubscription.setPassword(myCursor.getString(4));
            mySubscription.setBrokerUrl(myCursor.getString(5));
            mySubscription.setEncryptionKey(myCursor.getString(6));

        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "No Subscription Found in Database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
            return mySubscription;
        }
    }

    @Override
    public ArrayList<SubscriptionDTO> getSubscriptionList() throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        ArrayList<SubscriptionDTO> mySubscriptionList = new ArrayList<SubscriptionDTO>();
        Cursor myCursor = null;
        try {

            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT * FROM T_SUBSCRIPTION",null);
            for(myCursor.moveToFirst(); !myCursor.isAfterLast(); myCursor.moveToNext()){
                    SubscriptionDTO mySubscription = getSubscriptionDTOFromCursor(myCursor);
                    mySubscriptionList.add(mySubscription);
            }
        }
        catch (WeAlertException e){
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while searching Subscriptions from sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }
        return mySubscriptionList;
    }

    private SubscriptionDTO getSubscriptionDTOFromCursor(Cursor aDatabaseCursor) throws WeAlertException {
        SubscriptionDTO myTemporarySubscriptionDTO = new SubscriptionDTO();
        try {
            myTemporarySubscriptionDTO.setTopicName(aDatabaseCursor.getString(2));
            myTemporarySubscriptionDTO.setUserName(aDatabaseCursor.getString(3));
            myTemporarySubscriptionDTO.setPassword(aDatabaseCursor.getString(4));
            myTemporarySubscriptionDTO.setBrokerUrl(aDatabaseCursor.getString(5));
            myTemporarySubscriptionDTO.setEncryptionKey(aDatabaseCursor.getString(6));
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Error while preparing SubscriptionDTO from retrieve database cursor");
            throw myWeAlertException;
        }
        return myTemporarySubscriptionDTO;
    }
    @Override
    public void deleteSubscriptionDetail() throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        WeAlertLogger myLogger = new WeAlertLogger();
        try {
            myWeAlertDB = theSqliteDB.OpenDatabase();
            if(myWeAlertDB.delete("T_SUBSCRIPTION",null,null)>0) {

                myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Subscriptions are cleared from SQLite");
            }
            else {
                myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Subscriptions are not cleared from SQLite");
            }
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while getting subscription details from sqlite database");
            throw myWeAlertException;
        }
        finally {
            theSqliteDB.CloseDatabase();
        }
    }
}
