/*
 *	@Author: Waqas Ali Razzzaq
 *
 *  @Usage:
 *			1. Connection and subscription to MQTT Server
 *		    2. Receive new alerts
 *  		3. Close connection
 *
 *	@Known Issues:
 *	        1. Put callback methods in separate class for mqtt
 *
 *	@VersionHistory:
 *			01.001 (Initial Implementation)
 *		    01.002 Generate notification on new alert function added
 *		    01.003 check duplicate alert function added
 *
 *
 */
package nl.weintegrate.wealert.app.messaging;

/* Android Imports */

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.dto.SubscriptionDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.IAlertDAO;
import nl.weintegrate.wealert.app.persistence.ISubscriptionDAO;
import nl.weintegrate.wealert.app.ui.LoginActivity;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

/* Eclipse Paho Imports */
/* WeIntegrate Imports */

/* Class Declarations start*/
public class AlertMqttSubscriber{

    /***************************************************************
                                 VARIABLES
     ****************************************************************/

    private static final String CLASS_NAME = "AlertMqttSubscriber";
    private Context theContext;
    private MqttAndroidClient theMQTTClient;
    private static Uri theNotificationType;
    private static long theTimeOfLastAlert = 0;
    private Ringtone theRingtone;
    private final static String GROUP_KEY_ALERTS = "group_key_alert";

    public AlertMqttSubscriber (Context aContext) {
        this.theContext = aContext;
    }

    /***************************************************************
                        PUBLIC - METHOD
     ****************************************************************/
    /*
    * Usage:
    *       close the messaging server connection on sigout/disconnect
    * Params:
    *       none
    * */

    public void closeConnection(){
        theMQTTClient.unregisterResources();
        theMQTTClient.close();
    }
    /*
    * Usage:
    *       Create connection with server to receive new alerts.
    * Params:
    *       aContext: the current context of application
    *       aDeviceId: the unique device number
    *       aBrokerUrl: messaging server Url
    *       aUserName: the messaging server username
    *      aPassword: the password for messaging server username
    * */

    public void makeConnection(final Context aContext, String aDeviceId, String aBrokerUrl, String aUserName, String aPassword) throws WeAlertException  {

        MqttConnectOptions myOptions = new MqttConnectOptions();
        myOptions.setCleanSession(false);
        myOptions.setAutomaticReconnect(true);
        myOptions.setKeepAliveInterval(Constant.KEEP_ALIVE_INTERVAL);
//      myOptions.setPassword(aPassword.toCharArray());
//      myOptions.setUserName(aUserName);
        try {
            theMQTTClient = new MqttAndroidClient(this.theContext,aBrokerUrl,aDeviceId);
            IMqttToken token = theMQTTClient.connect(myOptions);

            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    try {
                        WeAlertLogger myWeAlertLogger = new WeAlertLogger();
                        myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Connection status is: "+String.valueOf(theMQTTClient.isConnected()));
                        ArrayList<String> myTopicName = getTopicName(aContext);
                        for (int topicName=0;topicName<myTopicName.size();topicName++) {
                            theMQTTClient.subscribe(myTopicName.get(topicName), 1);
                        }
                    } catch (MqttException exception) {
                        WeAlertLogger myWeAlertLogger = new WeAlertLogger();
                        myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,exception);
                    }
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {

                }
            });
            theMQTTClient.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {

                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    JSONObject myAlertJsonObject = new JSONObject(message.toString());
                    if(!message.isDuplicate() && !isDuplicateMessage(myAlertJsonObject.getJSONObject("Alert").get("AlertId").toString())) {

                        generateNotification(AlertMqttSubscriber.this.theContext,myAlertJsonObject);
                        theNotificationType = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                        theRingtone = RingtoneManager.getRingtone(theContext, theNotificationType);
                        long myCurrentTimeInSeconds =  System.currentTimeMillis();

                        if ((myCurrentTimeInSeconds-theTimeOfLastAlert)>2000) {
                            theRingtone.play();
                            theTimeOfLastAlert = myCurrentTimeInSeconds;
                        }

                        theMQTTClient.acknowledgeMessage(String.valueOf(message.getId()));
                        AlertProcessor myAlertProcessor = new AlertProcessor();
                        myAlertProcessor.processAlert(myAlertJsonObject,theContext);
                    }
                }
                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {

                }
            });
        } catch (MqttException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,exception);
            throw myWeAlertException;
        }
    }

    /***************************************************************
                        PRIVATE - METHOD
     ****************************************************************/
    /*
    * Usage:
    *       Retrieve topic names from storage.
    * Params:
    *       aContext: the current context of application
    * */

    private ArrayList<String> getTopicName(Context aContext) {
        ArrayList<SubscriptionDTO> mySubscription;
        ArrayList<String> myTopicList =  new ArrayList<>();
        DAOFactory mySQLLiteDaoFactory;
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(aContext);
            ISubscriptionDAO mySubscriptionDao = mySQLLiteDaoFactory.getSubscriptionDAO();
            mySubscription = mySubscriptionDao.getSubscriptionList();
            for (int i=0;i<mySubscription.size();i++){
                if(mySubscription.get(i).getTopicName()!=null) {
                    myTopicList.add(mySubscription.get(i).getTopicName());
                }
            }
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,myWeAlertException.getMessage());
        }
        return myTopicList;
    }
    /*
    * Usage:
    *       Generate a android pop up notification on new alert.
    * Params:
    *       aContext: the current context of application
    *       aJsonObject: incoming Json message payload
    * */

    private void generateNotification(Context aContext,JSONObject aJsonObject) throws JSONException {
        DAOFactory mySQLLiteDaoFactory;
        NotificationCompat.Builder mBuilder = null;
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(aContext);
            IAlertDAO myAlertDao = mySQLLiteDaoFactory.getAlertDAO();
            Bitmap largeIcon = BitmapFactory.decodeResource(aContext.getResources(), R.drawable.logo_walert);
            mBuilder = new NotificationCompat.Builder(aContext).setLargeIcon(largeIcon).setSmallIcon(R.drawable.logo_walert).setNumber(myAlertDao.getUnreadMessageCount()+1)
                    .setContentTitle(aJsonObject.getJSONObject("Alert").get("AlertTitle").toString())
                    .setContentText("Severity: " + aJsonObject.getJSONObject("Alert").get("Severity").toString() + ", Type: " + aJsonObject.getJSONObject("Alert").get("AlertType").toString())
                    .setGroup(GROUP_KEY_ALERTS).setGroupSummary(true);
            mBuilder.setAutoCancel(true);
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, myWeAlertException.getMessage());
        }
        Intent resultIntent = new Intent(aContext, LoginActivity.class);
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(aContext);
        stackBuilder.addParentStack(LoginActivity.class);
        stackBuilder.addNextIntent(resultIntent);
        PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);
        mBuilder.setContentIntent(resultPendingIntent);
        NotificationManager mNotificationManager = (NotificationManager) aContext.getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.notify(1, mBuilder.build());
    }
    /*
    * Usage:
    *       check if newly received message is duplicate.
    * params:
    *       aAlertId: alertId of incoming message
    * */

    private boolean isDuplicateMessage(String aAlertId) {
        DAOFactory mySQLLiteDaoFactory;

        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(theContext);
            IAlertDAO myAlertDao = mySQLLiteDaoFactory.getAlertDAO();
            if(myAlertDao.checkIfAlertExists(aAlertId))
                return true;
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, myWeAlertException.getMessage());
        }
        return false;
    }
}// End Of Class
