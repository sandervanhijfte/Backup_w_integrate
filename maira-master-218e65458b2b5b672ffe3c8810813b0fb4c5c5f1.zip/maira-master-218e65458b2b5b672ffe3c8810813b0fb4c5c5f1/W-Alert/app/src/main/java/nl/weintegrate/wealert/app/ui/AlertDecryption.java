/*
 *	@Author: Waqas Ali Razzzaq
 *
 *  @Usage:
 *			1.
 *
 *	@Known Issues:
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *
 *
 */
package nl.weintegrate.wealert.app.ui;

/* Security Imports*/

import android.content.Context;

import org.bouncycastle.crypto.engines.BlowfishEngine;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Base64;

import java.util.Properties;

import nl.weintegrate.wealert.app.dto.SubscriptionDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.ISubscriptionDAO;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

/* Java Imports*/
/* WeIntegrate Imports */

/* Class Deceleration */
public class AlertDecryption extends Properties {

    public String decryptAlertMessage(String aAlertMessage, Context aContext) throws Exception {
        BlowfishEngine myEngine = new BlowfishEngine();
        PaddedBufferedBlockCipher myCipher = new PaddedBufferedBlockCipher(myEngine);
        StringBuffer myResult = new StringBuffer();
        KeyParameter key = new KeyParameter(getKey(aContext).getBytes());
        myCipher.init(false, key);
        byte myBase64Decode[] = Base64.decode(aAlertMessage);
        byte myOutputStream[] = new byte[myCipher.getOutputSize(myBase64Decode.length)];
        int myLength = myCipher.processBytes(myBase64Decode, 0, myBase64Decode.length, myOutputStream, 0);
        myCipher.doFinal(myOutputStream, myLength);
        String myString = new String(myOutputStream);
        for (int i = 0; i < myString.length(); i++) {
            char c = myString.charAt(i);
            if (c != 0) {
                myResult.append(c);
            }
        }
        return myResult.toString();
    }
    private static String getKey(Context aContext) {
        SubscriptionDTO mySubscription = null;
        DAOFactory mySQLLiteDaoFactory;
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(aContext);
            ISubscriptionDAO mySubscriptionDao = mySQLLiteDaoFactory.getSubscriptionDAO();
            mySubscription = mySubscriptionDao.getSubscriptionDetail();

        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),"",myWeAlertException.getMessage());
        }
        return mySubscription.getEncryptionKey();
    }
}
