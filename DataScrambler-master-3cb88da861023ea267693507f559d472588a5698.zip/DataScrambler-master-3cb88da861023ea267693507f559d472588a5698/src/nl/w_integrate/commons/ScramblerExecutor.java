package nl.w_integrate.commons;


/**
 * @author YASIR JANJUA
 * @usage This class is responsible for running the File Scrambler
 * 
 * KnownIssues:
 * 
 * Version History:
 * @version 01.001 (initial Implementation)
 */

public class ScramblerExecutor {
	
	/**
	 * This method instantiate the File Scrambler and Execute it.
	 *  
	 * @param args
	 */
	public static void main(String[] args) {
		
		String myInputFile = args[0];
		String myOutputFilePath = args[1];
		
		try{
			int[] mySelectedColumns = stringArrayToIntArray(args[2].split(" "));
		
		FileScrambler myScrambler;
		
		if(args.length > 3){
			char myDelimiter = args[3].charAt(0);

			myScrambler = new FileScrambler(mySelectedColumns, myInputFile, myOutputFilePath, myDelimiter);
		} else {
			
			myScrambler = new FileScrambler(mySelectedColumns, myInputFile, myOutputFilePath);
		}
			myScrambler.generateScrambledFile();
		} catch(NumberFormatException myException) {
			myException.printStackTrace();
		}
	}
	
	/**
	 * This method converts String array into char array 
	 * 
	 * @param anArray - Takes columns as String array
	 * @return int[] returns integer array
	 * @throws NumberFormatException 
	 */
	private static int[] stringArrayToIntArray(String[] anArray) throws NumberFormatException {
	   int[] result = new int[anArray.length];
	   for (int index = 0; index < anArray.length; index++) {
		   if(Integer.parseInt(anArray[index]) < 1){
			   NumberFormatException myException = new NumberFormatException("Column can't be zero, please use a number greater than 1");
			   			    
			  throw myException; 
		   }
	      result[index] = Integer.parseInt(anArray[index])-1;
	   }
	   return result;
	}
	
}
