/**
 * 
 */
package nl.w_integrate.commons;
/**
 * @author YASIR JANJUA
 * @usage This class is responsible for scrambling a input file
 * 
 * KnownIssues:
 * 1. Original data can't be retrieved once it's scrambled
 * 2. Unit Tests are not done
 * 
 * Version History:
 * @version 01.001 (initial Implementation)
 */

/*JAVA Packages*/
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;

/* Univocity Packages */
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;
import com.univocity.parsers.csv.CsvWriter;
import com.univocity.parsers.csv.CsvWriterSettings;

public class FileScrambler {

/***************************************************************
							VARIABLES
****************************************************************/
	private int[] theInputString;
	private String theInputFilePath;
	private String theOutputFilePath;
	private char theDelimiter;

/***************************************************************
						PUBLIC - METHODS
****************************************************************/
	public FileScrambler(int[] aInputString, String aInputFilePath, String aOutputFilePath) {
		
		this(aInputString, aInputFilePath, aOutputFilePath, ';');
	}
	
	public FileScrambler(int[] aInputString, String aInputFilePath, String aOutputFilePath, char aDelimiter) {
		
		theInputString = aInputString;
		theInputFilePath = aInputFilePath;
		theOutputFilePath = aOutputFilePath+getFileName();
		theDelimiter = aDelimiter;
		
	}
	
	/**
	 * This method uses the other methods of class to parse and scramble the
	 * data and then generate a CSV file
	 * 
	 * @see getScrambleData(aFilePath), writeFile(aScrambledDataArray, aFilePath)
	 */
	public void generateScrambledFile() {
		
		ArrayList<String[]> myScrambledData;
		try {
			myScrambledData = getScrambledData(theInputFilePath);
			writeFile(myScrambledData, theOutputFilePath);
		
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		
		
		System.out.println("Scrambling is done!");
	}

/***************************************************************
						PRIVATE - METHODS
****************************************************************/
	
	/**
	 * This method takes scrambled rows and path of output file then generates
	 * a CSV file of scrambled data
	 * 
	 * @param aScrambledDataArray - The scrambled Rows
	 * @param aFilePath - The path of output file
	 */
	private void writeFile(ArrayList<String[]> aScrambledDataArray, String aFilePath) {
		File myFile =  new File(aFilePath);
		CsvWriter myWriter = new CsvWriter(myFile,getWriterSettings());
		
		myWriter.writeStringRowsAndClose(aScrambledDataArray);
	}
	
	/**
	 * This method takes a file path, scramble the file and returns
	 * scrambled rows
	 * 
	 * @param aFilePath - the path of input file
	 * @return ArrayList<String[]> - Scrambled Rows
	 * @throws FileNotFoundException 
	 */
	private ArrayList<String[]> getScrambledData(String aFilePath) throws FileNotFoundException {
		CsvParser myParser = getParser();
		List<String[]> myParsedRows = myParser.parseAll(getReader(aFilePath));
		ArrayList<String[]> myScrambledRows = new ArrayList<String[]>();
		
		String[] headers = myParsedRows.remove(0);

		for (String[] column : myParsedRows) {
			int noOfColumns = column.length;
			String[] row = new String[noOfColumns];
			
			for (int index = 0; index < noOfColumns; index++) {

				if (isColumnSelected(index)) {
					row[index] = (scrambler(column[index]));
				} else {
					row[index] = (column[index]);
				}
			}
			myScrambledRows.add(row);
		}
		myScrambledRows.add(0, headers);
		return myScrambledRows;
	}
	
	/**
	 * This method generates CsvParser
	 * 
	 * @return CsvParser
	 */
	private CsvParser getParser() {

		CsvParserSettings mySettings = new CsvParserSettings();
		mySettings.getFormat().setDelimiter(getDelimiter());
		mySettings.getFormat().setLineSeparator("\n");

		return new CsvParser(mySettings);
	}
	
	/**
	 * This method generates settings for CscWriter
	 * 
	 * @return CsvWritterSettings
	 */
	private CsvWriterSettings getWriterSettings() {
		
		CsvWriterSettings mySettings = new CsvWriterSettings();
		mySettings.setNullValue(" ");
		mySettings.setEmptyValue(" ");
		mySettings.getFormat().setDelimiter(getDelimiter());
		mySettings.setQuoteAllFields(false);
		
		return mySettings;
	}
	
	/**
	 * This method takes column no. and returns true or false if column is selected
	 * or not selected respectively
	 * 
	 * @param aColumnId - Index of column
	 * @return Boolean - true/false
	 */
	private Boolean isColumnSelected(int aColumnId) {
		 Arrays.sort(theInputString);
		
		for (int index = 0; index < theInputString.length; index++) {
			if (aColumnId == theInputString[index]) {

				return true;
			}
		}

		return false;
	}
	
	/**
	 * This method takes input file path and return a InputStreamReader
	 * 
	 * @param aFilePath - Takes input file path
	 * @return Reader  - Returns InputStreamReader
	 * @throws FileNotFoundException 
	 */
	private Reader getReader(String aFilePath) throws FileNotFoundException {

		return new FileReader(aFilePath);
	}

	/**
	 * @return the theDelimiter
	 */
	private char getDelimiter() {
		return theDelimiter;
	}

	/**
	 * @param aDelimiter to set
	 */
	private void setDelimiter(char aDelimiter) {
		this.theDelimiter = aDelimiter;
	}

	/**
	 * This method scrambles the input string randomly using a custom
	 * Algorithm
	 * 
	 * @param aInputString
	 * @return String
	 */
	private String scrambler(String aInputString) {
		if (aInputString == null) {
			return " ";
		}

		char myInputCharacters[] = aInputString.toCharArray();

		for (int index = 0; index < myInputCharacters.length; index++) {
			
			if(Character.isLetter(myInputCharacters[index])) {
				
				myInputCharacters[index] = getRandomAlphabet();
			} else if(Character.isDigit(myInputCharacters[index])) {
				
				myInputCharacters[index] = getRandomDigit();
			}
		}

		return new String(myInputCharacters);
	}
	
	/**
	 * This method returns a random digit between 1-9 
	 * 
	 * @return char - A random digit 
	 */
	private char getRandomDigit() {
		
		Random myRandomNumber =  new Random();
		
		return (char)(myRandomNumber.nextInt(9)+49);
	}
	
	/**
	 * This method returns a random alphabet between a-z
	 * 
	 * @return char - A random alphabet
	 */
	private char getRandomAlphabet() {
		
		Random myRandomNumber =  new Random();
		
		return (char)(myRandomNumber.nextInt(26)+'a');
	}
	
	private String getFileName() {
		
		Date myDate =  new Date();
		DateFormat myDateFormat = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss");
		String myCurrentDate = myDateFormat.format(myDate);
		String myOutputFile = "scrambledfile-"+ myCurrentDate +".csv";
		
		return myOutputFile;
	}
}
