MC_20.1 Manager can change his password.        = MC_18.3_SD_ChangePassword_SF_01
MC-20.2 Manager can view his profile.           = MC_14_SD_GetManager_SF_01
MC-20.3 Client admin can update his profile.    = MC_15_SD_UpdateManager_SF_01
