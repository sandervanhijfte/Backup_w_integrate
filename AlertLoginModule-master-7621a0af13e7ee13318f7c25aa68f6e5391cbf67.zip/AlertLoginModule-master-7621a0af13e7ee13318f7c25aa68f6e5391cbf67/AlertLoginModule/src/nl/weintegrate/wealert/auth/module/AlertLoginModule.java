/*
 *  Author: Maham Hassan
 *  Usage:  
 *      1. Implements customised login handler for connection with the Kaazing Gateway.
 *      2. Calls the Configuration Management API for authentication purposes.
 *
 *  Known Issues:
 *      None discovered so far.
 *
 *  VersionHistory: 
 *      01.001 (Initial Implementation) - MH
 *      01.002 (Calling Configuration Management API for authentication) - AT
 *
 */

package nl.weintegrate.wealert.auth.module;

/*  JAVA Packages  */
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.Principal;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.LoginException;
import javax.security.auth.Subject;
import javax.security.auth.spi.LoginModule;

import java.util.Map;
import java.util.Set;

/*  JSON packages  */
import org.json.*;

/* Kaazing Custom Login Module Packages  */
import com.kaazing.gateway.server.spi.security.LoginResult;
import com.kaazing.gateway.server.spi.security.LoginResultCallback;

/* Class Declaration start*/

public class AlertLoginModule implements LoginModule {

    /***************************************************************
                             VARIABLES
     ****************************************************************/

	public static final String CLASS_NAME = AlertLoginModule.class.getName();

    public static final String LOG_PREFIX = "nl.weintegrate.wealert.auth.module.AlertLoginModule";   // The prefix that appears on all log output making it easier to identify.

    private static final String NAME = "javax.security.auth.login.name";
    private static final String PWD = "javax.security.auth.login.password";
    
    private Map theSharedState;
    
    // The parameters that are to be used for authentication purposes.
    private String theUsername;
    private char[] thePassword;
    private String theDeviceId;
    private String theTopicName;

    // The back end API URL that needs to be invoked for authentication.
    private String theAuthenticationApiUrl = "http://213.187.243.177:8283/ConfigurationManagementAPI/authenticateusers";

    private Subject theSubject;    //the subject to be authenticated
    private CallbackHandler theHandler; // The callback handler to retrieve inputs from the login context
    private Map<String, ?> theOptions; // Options specified from the Gateway configuration
    private Principal thePrincipal; // The principal that will be attached the LoginResult upon a successful authentication

    /***************************************************************
                            PUBLIC - METHODS
    ****************************************************************/

    @Override
    public void initialize(Subject aSubject, CallbackHandler aCallbackHandler, Map<String, ?> aSharedState, Map<String, ?> aOptions) {

        theSubject = aSubject;
        theHandler = aCallbackHandler;
        theOptions = aOptions;
        theSharedState = aSharedState;
        
        Set<?> myKeys = theOptions.keySet();
        if ( myKeys.size() > 0 ) {
        	String myKeyLogStatement;
        	myKeyLogStatement = LOG_PREFIX+" --- "+"Options: \n";
            	for (Object myKey : myKeys) {
            		myKeyLogStatement = myKeyLogStatement+" 	" + myKey + " = " + theOptions.get(myKey) + "\n";
            	}
            System.out.println(myKeyLogStatement);
        }
    }

    @Override
    public boolean login() throws LoginException {
        
      System.out.println(LOG_PREFIX+" --- "+"Attempt for Login");
      LoginResult loginResult = getLoginResultFromCallback();

        if ( loginResult == null ) {
        	System.out.println(LOG_PREFIX+" --- "+"No Login Result ");
            return false;
        }

        attemptAuthenticate(true);

        thePrincipal = new Principal() {
            @Override
            public String getName() {
                return "AUTHORIZED";
            }
        };

        return true;

    }

    @Override
    public boolean commit() throws LoginException {
    	System.out.print(LOG_PREFIX+" --- "+" Calling Commit");

        // Commit can be invoked even if login() didn't fully complete. So in
        // order to know if login() fully completed
        // or not, check whether the principal is set.
        if ( thePrincipal == null ) {
        	System.out.print(LOG_PREFIX+" --- "+"No role granted ");
            return false;
        }

        theSubject.getPrincipals().add(thePrincipal);

        System.out.print(LOG_PREFIX+" --- "+"User granted role: " + thePrincipal.getName());

        // Print out all Principals on the Subject. Useful for debugging.
        Set<Principal> principals = theSubject.getPrincipals();
        
        	for (Principal principal : principals) {
        		System.out.print("Principal: " + principal.getName() + " [ " + principal.getClass().getName() + " ] ");
        	}
        	
        return true;
    }

    @Override
    public boolean abort() throws LoginException {

        // abort() is called when login() and/or commit() fail.
        // Contract is to return false if login failed. Otherwise
        // clean up the principal and return true. If any error
        // happens during cleanup, throw an exception.

    	System.out.print(LOG_PREFIX+" --- "+" Calling Abort");

        // If login failed, returned false to indicate
        // we should ignore this abort() because there is
        // no state to clean up.
        if ( thePrincipal == null ) {
        	System.out.print(LOG_PREFIX+" --- "+" No role granted");
            return false;
        }

        try {
            clearRole();

            // Abort Success: state is cleaned, return true.
            return true;
        }
        catch (Exception ex) {
            // Abort failure: throw Login Exception
            LoginException e = new LoginException("Unexpected error during abort().");
            e.initCause(ex);
            System.out.print(e.getMessage()+e);
            throw e;
        }
    }

    @Override
    public boolean logout() throws LoginException {

        // The logout() contract is to clean up the credentials if
        // we can, then return true, otherwise throw an exception.
        // No real provision in JaaS for returning false here.

    	System.out.println(LOG_PREFIX+" --- "+"Calling Logout");

        try {
            clearRole();
            // Logout Success: state is cleaned, return true.
            return true;
        }
        catch (Exception ex) {
            LoginException e = new LoginException("Unexpected error during logout().");
            e.initCause(ex);
            System.out.println(LOG_PREFIX+" --- "+e.getMessage());
            throw e;
        }
    }

    /***************************************************************
                            PRIVATE - METHODS
    ****************************************************************/

    /**
     * Retrieve the LoginResult from the Login Context.
     * 
     * @return the LoginResult for this Login Module chain
     */
    private LoginResult getLoginResultFromCallback() {
        final LoginResultCallback myLoginResultCallback = new LoginResultCallback();
        try {
            theHandler.handle(new Callback[]{myLoginResultCallback});
        }
        catch (IOException ioe) {
        	System.out.println(LOG_PREFIX+" --- "+"Encountered exception occured while handling loginResultCallback: "+ioe.getMessage());
            return null;
        }
        catch (UnsupportedCallbackException uce) {
        	System.out.println(LOG_PREFIX+" --- "+"UnsupportedCallback Exception occured while handling loginResultCallback"+uce.getMessage());
            return null;
        }

        return myLoginResultCallback.getLoginResult();
    }

    /*
     *  Set username and password to class instance variables after
     *  retrieving the username and password from the shared state
     * 
    */
    private void getUsernamePassword(boolean aUsedSharedState) throws LoginException
    {
    	if(aUsedSharedState)
    	{
    		theUsername = (String)theSharedState.get(NAME);
    		thePassword = (char[])theSharedState.get(PWD);
    		return;
    	}
    	NameCallback myNameCallback = new NameCallback("username");
    	PasswordCallback myPasswordCallback = new PasswordCallback("password", false);
    	
    	try
    	{
    		theHandler.handle(new Callback[] {myNameCallback, myPasswordCallback});
    	}
    	catch (IOException e)
    	{
    		return;
    	}
    	catch (UnsupportedCallbackException e)
    	{
    		System.out.println(LOG_PREFIX+" --- "+"UnsupportedCallbackException occured while handling authenticationTokenCallback: "+e.getMessage());
    		return;
    	}
    	
    	theUsername = myNameCallback.getName();
    	thePassword = myPasswordCallback.getPassword();
    }
    
    /*
     *  From the username and password retrieved from the shared state, it calls the backend 
     *  method for authentication 
     *  @return true/false
    */
    private boolean attemptAuthenticate(boolean aUseSharedState) throws LoginException {

  		getUsernamePassword(aUseSharedState);
  		
  		// getting and setting the device id and topic name which is encoded in the password as deviceId@topicName
  		String thePasswordString = String.valueOf(thePassword);
  		String[] passwordTokens = thePasswordString.split("@");
  		theDeviceId = passwordTokens[0];
        theTopicName = passwordTokens[1];

		System.out.println(LOG_PREFIX+" --- "+" Login Attempt "+"	Username: "+ theUsername
                                +"\n 	Device ID: "+ theDeviceId +"\n 		Topic Name: "+ theTopicName);
        
        // call the backend service for authentication and return it's results.
		return callAuthenaticationApi();
    }
    
    /*
    * calls the backend API with the username, device id and topic name in the request message as payload, for authentication purposes.
    * 
    * @return true/false 
    */
    private boolean callAuthenaticationApi(){

        HttpURLConnection myConnection = null; 
        boolean myAuthorisation = false;

          try {
            // Formation of JSON request payload
            JSONObject myRequestPayload = new JSONObject();
            JSONObject myCredentials = new JSONObject();

            myCredentials.put("UserName", theUsername);
            myCredentials.put("TopicName", theTopicName);
            myCredentials.put("DeviceId", theDeviceId);
            myRequestPayload.put("AuthorizeMemberUserRequest", myCredentials);

            // Initialisation of connection to the API
            URL myUrl = new URL(theAuthenticationApiUrl);
            myConnection = (HttpURLConnection)myUrl.openConnection();

            // Setting connection request parameters
            myConnection.setRequestMethod("POST");
            myConnection.setRequestProperty("Content-Type", "application/json");
            myConnection.setRequestProperty("Accept", "application/json");
            myConnection.setRequestProperty("Accept-Encoding", "gzip,deflate");
            myConnection.setRequestProperty("Content-Length", Integer.toString(myRequestPayload.toString().getBytes().length));

            myConnection.setUseCaches (false);
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);

            // Writing the request to the stream writer 
            DataOutputStream myStreamWriter = new DataOutputStream(myConnection.getOutputStream());
            myStreamWriter.write(myRequestPayload.toString().getBytes());
            myStreamWriter.flush();
            myStreamWriter.close();
            
            // Check if the API returns HTTP code 200 OK
              if(myConnection.getResponseCode()==200){

                // Read the response payload returned from the API 
                InputStream myInputStreamWriter = myConnection.getInputStream();
                BufferedReader myResponseReader = new BufferedReader(new InputStreamReader(myInputStreamWriter));
                String line;
                StringBuffer myResponse = new StringBuffer(); 

                  while((line = myResponseReader.readLine()) != null) {
                    myResponse.append(line);
                    myResponse.append('\r');
                  }

                 myResponseReader.close();
                 myInputStreamWriter.close();

                JSONObject myResponseJsonObject = new JSONObject(myResponse.toString());
                System.out.println(myResponseJsonObject.toString());

                // Check the response code to decide whether to allow authorisation or not
                  if(myResponseJsonObject.getJSONObject("AuthorizeMemberUserResponse").get("ResponseCode").equals("N-0000")){
                	  myAuthorisation = true;   // allow authorisation if the response code returned is "N-0000"
                  }else{
                    if(myResponseJsonObject.getJSONObject("AuthorizeMemberUserResponse").get("ResponseCode").equals("W-0001")){
                    	System.out.println(LOG_PREFIX+" --- "+"Wrong Credentials");
                    }else if(myResponseJsonObject.getJSONObject("AuthorizeMemberUserResponse").get("ResponseCode").equals("E-0001")){
                    	System.out.println(LOG_PREFIX+" --- "+myResponseJsonObject.getJSONObject("AuthorizeMemberUserResponse").get("ResponseMessage"));
                    }
                  }
              }else{
                System.out.println(LOG_PREFIX+" --- "+"API returned HTTP Error. Response Code: " + myConnection.getResponseCode());
              }

            } catch (Exception e) {
              e.printStackTrace();
            }
            finally {
              // clean up initialised resources 
              if(myConnection != null) {
              	myConnection.disconnect(); 
              }
          }
        return myAuthorisation;
    }
    
    /**
    * Clean up the Subject state to ensure that the principal is not added to prevent accidental login.
    */
    private void clearRole() {
    	theSubject.getPrincipals().remove(thePrincipal);
    }
}
