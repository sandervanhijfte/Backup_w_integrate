from flask import Flask, request, jsonify
from apns import APNsClient, exceptions

app = Flask(__name__)

use_company = True

config = {
    'company': {
        'team_id': 'HZZQJW9578',
        'bundle_id': 'nl.weintegrate.wealert.ios.wealert',
        'auth_key_id': 'S4X88EPXAN',
        'auth_key_filepath': 'certificates/company/AuthKey_S4X88EPXAN.p8'
    },
    'enterprise': {
        'team_id': '9MT9MVY956',
        'bundle_id': 'nl.weintegrate.wealert.ios',
        'auth_key_id': 'GYANRG7P66',
        'auth_key_filepath': 'certificates/enterprise/AuthKey_GYANRG7P66.p8'
    }
}

env_config = config['company'] if use_company else config['enterprise']

client = APNsClient(team_id=env_config['team_id'], bundle_id=env_config['bundle_id'],
                    auth_key_id=env_config['auth_key_id'],
                    auth_key_filepath=env_config['auth_key_filepath'], use_sandbox=True, test_mode=False)


@app.errorhandler(Exception)
def handle_error(error):
    status_code = 400
    response_message = "Error Message"
    response_code = 'APS-E-0000'
    error_message = type(error).__name__
    bad_tokens = None
    response = {
        "APNSProviderServiceResponse": {
            "ResponseCode": response_code,
            "ResponseMessage": response_message
        }
    }
    if isinstance(error, exceptions.BadCollapseId) or isinstance(error, exceptions.BadExpirationDate) \
            or isinstance(error, exceptions.BadMessageId) or isinstance(error, exceptions.BadPriority) \
            or isinstance(error, exceptions.PayloadEmpty) or isinstance(error, exceptions.PayloadTooLarge):
        status_code = 413
        response_code = 'APS-E-0001'
        response_message = "APNS notification payload does not fulfill the requirement. An error occurred due to: {0}.".format(
            error_message)

    elif isinstance(error, exceptions.ImproperlyConfigured) or isinstance(error, exceptions.TopicDisallowed) \
            or isinstance(error, exceptions.BadCertificate) or isinstance(error, exceptions.BadCertificateEnvironment) \
            or isinstance(error, exceptions.InvalidProviderToken) or isinstance(error, exceptions.MissingProviderToken):
        status_code = 403
        response_code = 'APS-E-0002'
        response_message = "Failed to send notification. An error occurred due to: {0}.".format(error_message)

    elif isinstance(error, exceptions.DeviceTokenNotForTopic) or isinstance(error, exceptions.DuplicateHeaders) \
            or isinstance(error, exceptions.IdleTimeout) or isinstance(error, exceptions.MissingDeviceToken) \
            or isinstance(error, exceptions.MissingTopic) or isinstance(error, exceptions.ExpiredProviderToken) \
            or isinstance(error, exceptions.Forbidden) or isinstance(error, exceptions.BadPath) \
            or isinstance(error, exceptions.MethodNotAllowed) or isinstance(error,
                                                                            exceptions.TooManyProviderTokenUpdates) \
            or isinstance(error, exceptions.TooManyRequests):
        status_code = 405
        response_code = 'APS-E-0003'
        response_message = "Failed to send notification. An error occurred due to: {0}.".format(error_message)

    elif isinstance(error, exceptions.BadDeviceToken) or isinstance(error, exceptions.Unregistered) or isinstance(error,
                                                                                                                  exceptions.PartialBulkMessage):
        status_code = 410
        response_code = 'APS-W-0001'
        response_message = "Unable to send notification as device token is invalid or expired. An error occurred due " \
                           "to: {0}.".format(error_message)
        if isinstance(error, exceptions.PartialBulkMessage):
            bad_tokens = error.bad_registration_ids
            response["APNSProviderServiceResponse"]["BadTokens"] = bad_tokens

    elif isinstance(error, exceptions.InternalServerError) or isinstance(error, exceptions.ServiceUnavailable) \
            or isinstance(error, exceptions.Shutdown):
        status_code = 500
        response_code = 'APS-E-0004'
        response_message = "Due to server error, failed to send notification. Error occured due to: {0}.".format(
            error_message)

    else:
        status_code = 503
        response_code = 'APS-E-0005'
        response_message = "Unexpected error occurred: {0}.".format(error_message)

    response["APNSProviderServiceResponse"]["ResponseCode"] = response_code
    response["APNSProviderServiceResponse"]["ResponseMessage"] = response_message
    return jsonify(response), 200


@app.route('/aps', methods=['POST'])
def post_method():
    if request.method == 'POST':
        client.send_bulk_message(request.json['device_ids'], request.json['notification'])

        response = {
            "APNSProviderServiceResponse": {
                "ResponseCode": "APS-N-0000",
                "ResponseMessage": "Successfully sent notification."
            }
        }
        return jsonify(response), 200


if __name__ == '__main__':
    print("APNS Provider run")
    app.run(host='localhost', port=8765, debug=False)
