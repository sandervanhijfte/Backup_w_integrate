import asyncio
import io
import json
import ssl
from typing import List, Tuple

import collections
import h2
from h2.connection import H2Connection
from h2.errors import ErrorCodes
from h2.events import (
    ConnectionTerminated, DataReceived, RequestReceived, StreamEnded
)
from h2.exceptions import ProtocolError

RequestData = collections.namedtuple('RequestData', ['headers', 'data'])


class H2Protocol(asyncio.Protocol):
    def __init__(self):
        self.conn = H2Connection(client_side=False)
        self.transport = None
        self.stream_data = {}

    def connection_made(self, transport: asyncio.Transport):
        self.transport = transport
        self.conn.initiate_connection()
        self.transport.write(self.conn.data_to_send())

    def data_received(self, data: bytes):

        try:
            events = self.conn.receive_data(data)
        except ProtocolError as e:
            self.transport.write(self.conn.data_to_send())
            self.transport.close()
        else:
            print("data_received")
            self.transport.write(self.conn.data_to_send())
            for event in events:
                print("processing event {}", event)

                if isinstance(event, RequestReceived):
                    print("\nRequestReceived\n")
                    self.request_received(event.headers, event.stream_id)

                elif isinstance(event, DataReceived):
                    print("\nDataReceived\n")
                    self.receive_data(event.data, event.stream_id)

                elif isinstance(event, StreamEnded):
                    print("\nStream ended\n")
                    self.stream_complete(event.stream_id)

                elif isinstance(event, ConnectionTerminated):
                    print("\nConnectionTerminated\n")
                    self.transport.close()

                self.transport.write(self.conn.data_to_send())

    #####################################################################################

    def request_received(self, headers: List[Tuple[str, str]], stream_id: int):
        headers = collections.OrderedDict(headers)
        method = headers[':method']

        if method not in ('POST'):
            self.return_405(headers, stream_id)
            return

        request_data = RequestData(headers, io.BytesIO())
        self.stream_data[stream_id] = request_data

    def return_405(self, headers: List[Tuple[str, str]], stream_id: int):

        response_headers = (
            (':status', '405'),
            ('content-length', '0'),
            ('server', 'asyncio-h2'),
        )
        self.conn.send_headers(stream_id, response_headers, end_stream=True)

    #####################################################################################

    def receive_data(self, data: bytes, stream_id: int):

        try:
            stream_data = self.stream_data[stream_id]
        except KeyError:
            self.conn.reset_stream(
                stream_id, error_code=ErrorCodes.PROTOCOL_ERROR
            )
        else:
            stream_data.data.write(data)

    #####################################################################################

    def stream_complete(self, stream_id: int):

        try:
            request_data = self.stream_data[stream_id]
        except KeyError:
            return

        headers = request_data.headers
        body = request_data.data.getvalue().decode('utf-8')
        mock_apns_request_json = json.loads(body)
        try:
            mock_apns_response = mock_apns_request_json["mock_data"] if 'mock_data' in mock_apns_request_json else None
        except:
            mock_apns_response = None

        if mock_apns_response is not None:
            data = json.dumps(mock_apns_response).encode("utf8")
        else:
            data = json.dumps({}).encode("utf8")

        response_headers = (
            (':status', '400'),
            ('content-type', 'application/json'),
            ('apns-id', '9a378767-f2ba-4cee-b5c7-918b6aad3540')
        )
        self.conn.send_headers(stream_id, response_headers)
        self.conn.send_data(stream_id, data, end_stream=True)


h2.settings.HEADER_TABLE_SIZE = 1

cert = 'cert.pem'
key = 'key.pem'
password = '6414'
port = '8443'

ssl_context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
ssl_context.options |= (
        ssl.OP_NO_SSLv2 | ssl.OP_NO_SSLv3
)
ssl_context.set_ciphers("ECDHE+AESGCM")
ssl_context.load_cert_chain(certfile=cert, keyfile=key, password=password)
ssl_context.set_alpn_protocols(["h2"])

loop = asyncio.get_event_loop()

core = loop.create_server(H2Protocol, '0.0.0.0', port, ssl=ssl_context)
server = loop.run_until_complete(core)

print('Serving on {}. Hit ctrl+c to stop'.format(server.sockets[0].getsockname()))
try:
    loop.run_forever()
except KeyboardInterrupt:
    pass

server.close()
loop.run_until_complete(server.wait_closed())
loop.close()
