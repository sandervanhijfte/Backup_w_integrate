/*
* Author: Yasir Janjua
* Usage: Scramble the GGMD.contract records.
* 		 First 3 characters of each field for the selected columns 
		 are replaced with 101
* Known Issues:
*
*
* Version History:
*
* 01.001 (Initial Implementation)
*/

-- Turn off the safe mode flag
SET SQL_SAFE_UPDATES=0;

UPDATE GGMD.contract 
SET CustomerLastName = concat('101', substr(CustomerLastName,3, char_length(CustomerLastName)-3)) 
WHERE char_length(CustomerLastName)>1;

UPDATE GGMD.contract 
SET CustomerName = concat('101', substr(CustomerName,3, char_length(CustomerName)-3)) 
WHERE char_length(CustomerName)>1;

UPDATE GGMD.contract 
SET CustomerTitle = concat('101', substr(CustomerTitle,3, char_length(CustomerTitle)-3)) 
WHERE char_length(CustomerTitle)>1;

UPDATE GGMD.contract 
SET CustomerInitials = concat('101', substr(CustomerInitials,3, char_length(CustomerInitials)-3)) 
WHERE char_length(CustomerInitials)>1;

UPDATE GGMD.contract 
SET CustomerFirstName = concat('101', substr(CustomerFirstName,3, char_length(CustomerFirstName)-3)) 
WHERE char_length(CustomerFirstName)>1;

UPDATE GGMD.contract 
SET CustomerInfix = concat('101', substr(CustomerInfix,3, char_length(CustomerInfix)-3)) 
WHERE char_length(CustomerInfix)>1;

UPDATE GGMD.contract 
SET CustomerNameAtBirth = concat('101', substr(CustomerNameAtBirth,3, char_length(CustomerNameAtBirth)-3)) 
WHERE char_length(CustomerNameAtBirth)>1;

UPDATE GGMD.contract 
SET CustomerLastNameAtBirth = concat('101', substr(CustomerLastNameAtBirth,3, char_length(CustomerLastNameAtBirth)-3)) 
WHERE char_length(CustomerLastNameAtBirth)>1;

UPDATE GGMD.contract 
SET CustomerInfixAtBirth = concat('101', substr(CustomerInfixAtBirth,3, char_length(CustomerInfixAtBirth)-3)) 
WHERE char_length(CustomerInfixAtBirth)>1;

UPDATE GGMD.contract 
SET CustomerStreet = concat('101', substr(CustomerStreet,3, char_length(CustomerStreet)-3)) 
WHERE char_length(CustomerStreet)>1;

UPDATE GGMD.contract 
SET CustomerHouseNumber = concat('101', substr(CustomerHouseNumber,3, char_length(CustomerHouseNumber)-3)) 
WHERE char_length(CustomerHouseNumber)>1;

UPDATE GGMD.contract 
SET CustomerHouseNumberAddition = concat('101', substr(CustomerHouseNumberAddition,3, char_length(CustomerHouseNumberAddition)-3)) 
WHERE char_length(CustomerHouseNumberAddition)>1;

UPDATE GGMD.contract 
SET CustomerZipCode = concat('101', substr(CustomerZipCode,3, char_length(CustomerZipCode)-3)) 
WHERE char_length(CustomerZipCode)>1;

UPDATE GGMD.contract 
SET CustomerCity = concat('101', substr(CustomerCity,3, char_length(CustomerCity)-3)) 
WHERE char_length(CustomerCity)>1;

UPDATE GGMD.contract 
SET CustomerSocialSecurityNumber = concat('101', substr(CustomerSocialSecurityNumber,3, char_length(CustomerSocialSecurityNumber)-3)) 
WHERE char_length(CustomerSocialSecurityNumber)>1;

UPDATE GGMD.contract 
SET CustomerMobilePhone = concat('101', substr(CustomerMobilePhone,3, char_length(CustomerMobilePhone)-3)) 
WHERE char_length(CustomerMobilePhone)>1;

UPDATE GGMD.contract 
SET CustomerEmailAddress = concat('101', substr(CustomerEmailAddress,3, char_length(CustomerEmailAddress)-3)) 
WHERE char_length(CustomerEmailAddress)>1;

