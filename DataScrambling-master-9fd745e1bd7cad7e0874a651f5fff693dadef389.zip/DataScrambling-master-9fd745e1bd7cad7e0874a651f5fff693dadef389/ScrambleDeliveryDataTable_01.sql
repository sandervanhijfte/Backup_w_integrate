/*
* Author: Yasir Janjua
* Usage: Scramble the GGMD.delivery records.
* 		 First 3 characters of each field for the selected columns 
		 are replaced with 101
* Known Issues:
*
*
* Version History:
*
* 01.001 (Initial Implementation)
*/

-- Turn off the safe mode flag
SET SQL_SAFE_UPDATES=0;

UPDATE GGMD.delivery 
SET OrganizationId = concat('101', substr(OrganizationId,3, char_length(OrganizationId)-3)) 
WHERE char_length(OrganizationId)>1;

UPDATE GGMD.delivery 
SET OrganizationName = concat('101', substr(OrganizationName,3, char_length(OrganizationName)-3)) 
WHERE char_length(OrganizationName)>1;

UPDATE GGMD.delivery 
SET EmployeeLastName = concat('101', substr(EmployeeLastName,3, char_length(EmployeeLastName)-3)) 
WHERE char_length(EmployeeLastName)>1;

UPDATE GGMD.delivery 
SET EmployeeInitials = concat('101', substr(EmployeeInitials,3, char_length(EmployeeInitials)-3)) 
WHERE char_length(EmployeeInitials)>1;

UPDATE GGMD.delivery 
SET EmployeeInfix = concat('101', substr(EmployeeInfix,3, char_length(EmployeeInfix)-3)) 
WHERE char_length(EmployeeInfix)>1;

UPDATE GGMD.delivery 
SET DeliveredByOtherEmployees = concat('101', substr(DeliveredByOtherEmployees,3, char_length(DeliveredByOtherEmployees)-3)) 
WHERE char_length(DeliveredByOtherEmployees)>1;

UPDATE GGMD.delivery 
SET CustomerLastName = concat('101', substr(CustomerLastName,3, char_length(CustomerLastName)-3)) 
WHERE char_length(CustomerLastName)>1;

UPDATE GGMD.delivery 
SET CustomerInitials = concat('101', substr(CustomerInitials,3, char_length(CustomerInitials)-3)) 
WHERE char_length(CustomerInitials)>1;

UPDATE GGMD.delivery 
SET CustomerInfix = concat('101', substr(CustomerInfix,3, char_length(CustomerInfix)-3)) 
WHERE char_length(CustomerInfix)>1;

UPDATE GGMD.delivery 
SET CustomerYearOfBirth = concat('101', substr(CustomerYearOfBirth,3, char_length(CustomerYearOfBirth)-3)) 
WHERE char_length(CustomerYearOfBirth)>1;

UPDATE GGMD.delivery 
SET CustomerMonthOfBirth = concat('101', substr(CustomerMonthOfBirth,3, char_length(CustomerMonthOfBirth)-3)) 
WHERE char_length(CustomerMonthOfBirth)>1;

UPDATE GGMD.delivery 
SET CustomerZipCode = concat('101', substr(CustomerZipCode,3, char_length(CustomerZipCode)-3)) 
WHERE char_length(CustomerZipCode)>1;
